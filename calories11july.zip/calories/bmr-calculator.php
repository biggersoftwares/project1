<?php
include("config/db_connection.php");
include("includes/functions.php");
?>

<!doctype html>
<html lang="en-US">
<head>
		<?php include("includes/metatags.php"); ?>

	</head>
	<body data-spy="scroll">
		<div id="preloader">
			<img class="preloader__logo" src="<?php echo SITE_URL;?>images/logo.png" alt="" width="100" height="100"/>
			<div class="preloader__progress">
				<svg width="60px" height="60px" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
					<path class="preloader__progress-circlebg" fill="none" stroke="#dddddd" stroke-width="4" stroke-linecap="round" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					<path id='preloader__progress-circle' fill="none" stroke="#fe6367" stroke-width="4" stroke-linecap="round" stroke-dashoffset="192.61" stroke-dasharray="192.61 192.61" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
				</svg>
			</div>
		</div>
		<div id="wrapper" class="wide-wrap">
			<?php	include("includes/header.php");?>
			<?php	include("includes/video.php");?>
			<?php	include("includes/search.php");?>			
			<?php	include("includes/menubar.php");?>
<section class="facts_table">
			<div class="content-container">
				
    		<div class="container">
    			<div class="row">
    			<h1 class="searched_">BMR Calculator</h1>
          <br clear="all">
          <div class="col-md-6">
          <form action="#" method="post" class="form my_account" role="form" >
                                                    <label>Height (in CM)</label>
                    <!--<div class="row">
                        <div class="col-xs-6 col-md-6">
                            <input class="form-control" name="firstname" placeholder="feet" type="text" required="" autofocus="">
                        </div>
                        <div class="col-xs-6 col-md-6">
                            <input class="form-control" name="lastname" placeholder="inches" type="text" required="">
                        </div>
                    </div>-->
					   <input class="form-control" name="height" id="height" placeholder="Height" type="text" required="" autofocus="" onKeyUp="checkNumber(this);">
                    <label>Current Weight (in KGs)</label>
                    <input class="form-control" name="weight" id="weight" placeholder="Weight" type="text" required="" onKeyUp="checkNumber(this);">
                    <label>Current Age (in Years)</label>
                    <input class="form-control" name="age" id="age" placeholder="Age" type="text" required="" onKeyUp="checkNumber(this);">
                    <label>Gender</label>
					
                    <div class="row">
                        <div class="col-xs-6 col-md-6">
                            <label  class="inline form-flat-radio">
												<input name="gender" type="radio" id="gender" value="1" checked="checked">
												<i></i>Male
											</label>
                        </div>
                        <div class="col-xs-6 col-md-6">
                            <label class="inline form-flat-radio">
												<input name="gender" type="radio" id="gender" value="2">
												<i></i>FeMale
											</label>
                        </div>
                    </div>
                    <br>
                    <br>
                    <button class="btn btn-lg btn-primary btn-block" type="button" id="calculate">Calcuate</button>
                   
                </form>

              </div>
    					<div class="col-md-6">
              <h2 class="searched_">Result : <span style="font-weight:bold;color:#2cabbf"><span id="calculatordiv">0</span> Calories/day</span></h2>
			   <!--<h6>This is the World Health Organization's (WHO) recommended body weight based on BMI values for adults. It is used for both men and women, age 18 or older.</h6>
			  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        
        <th>Category</th>
        <th>BMI range - kg/m2</th>
      </tr>
    </thead>
    <tbody>

        <tr><td>Severe Thinness</td>
        <td>< 16</td>      </tr>
		
		<tr><td>Mild Thinness</td>
        <td>17 - 18.5</td>      </tr>
		
		<tr><td>Overweight</td>
        <td>25 - 30</td>      </tr>
		
		
		
		<tr><td>Obese Class I</td>
        <td>30 - 35</td>      </tr>
		
		<tr><td>Obese Class II</td>
        <td>35 - 40</td>      </tr>
		
		<tr><td>Obese Class III</td>
        <td>> 40</td>      </tr>
    </tbody>
  </table>
  </div>-->
</div>
              <br clear="all">
              

              </div>
    				
    			</div>
    			</div>
    		</div>
    </section>
			</div>
			<?php include("includes/footer1.php");?>
			<?php include("includes/footer.php");?>
		</div>
		<a href="#" class="go-to-top"><i class="fa fa-angle-up"></i></a>
		<div class="sitesao-preview__loading">
			<div class="sitesao-preview__loading__animation"><i></i><i></i><i></i><i></i></div>
		</div>
		<?php include("includes/js.php");?>
		<script language="javascript" type="text/javascript">
function checkNumber(textBox)

{

	while (textBox.value.length > 0 && isNaN(textBox.value)) {

		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	}

	

	textBox.value = textBox.value;

/*	if (textBox.value.length == 0) {

		textBox.value = 0;		

	} else {

		textBox.value = parseInt(textBox.value);

	}*/

}
	function AlphaNumeric_space(textBox)
{

	
	var regEx = new RegExp("^[a-zA-Z0-9 ]+$");
	 if (!$("#user_name").val().match(regEx))
	 {
		
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	 }

textBox.value = textBox.value;
}
function AlphaNumeric_special(textBox)
{
	
	
	var regEx = new RegExp("^[a-zA-Z0-9._@]+$");
	 if (!$("#remail_id").val().match(regEx))
	 {
		
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	 }

textBox.value = textBox.value;
}
</script>
<script type="text/javascript"  language="javascript">

$( document ).ready(function() {
$("#calculate").click(function(){

var height = $('#height').val();

        if ($.trim(height).length == 0) {

		$("#height").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }


var weight = $('#weight').val();



        if ($.trim(weight).length == 0) {

		$("#weight").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }
				
		
var age = $('#age').val();

        if ($.trim(age).length == 0) {

		$("#age").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }
	
	var radioValue = $("input[name='gender']:checked").val()
	var dataString = "height="+$("#height").val()+"&weight="+$("#weight").val()+"&age="+$("#age").val()+"&gender="+radioValue;  
			$.ajax({
				  type: "POST",
				  url: "bmrcalculator_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				   $("#calculatordiv").html(data);
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});	
		
});

</script>

	</body>
</html>