<?php ?>
	<section>
	<div class="content-container" id="ourstory">
	<div  class="container">
	<h1>OUR STORY</h1>
	<?php
$homepage = file_get_contents(SITE_URL.'ourstory.txt');
echo $homepage;
?>
	</div>
	</div>
</section>
<?php ?>