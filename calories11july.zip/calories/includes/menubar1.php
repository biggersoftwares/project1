<section class="tabs_section">
	<div class="container">
		<div class="row">
			<ul id="nav-menus">
<li class="page_item page-item-36"><a href="<?php echo SITE_URL;?>brunch.php?id=1" >Brunch</a></li>
<li class="page_item page-item-38"><a href="<?php echo SITE_URL;?>lunch.php?id=2"  >Lunch</a></li>
<li class="page_item page-item-40"><a href="<?php echo SITE_URL;?>dinner.php?id=3">Dinner</a></li>
<li class="page_item page-item-42"><a href="<?php echo SITE_URL;?>mrcaloriedelight.php?id=4">Wine List</a></li>
</ul>
		</div>
	</div>
</section>
