<nav class="navbar navbar-fixed-top"  >
  <div class="container-fluid">
    
	<div class="navbar-header page-scroll">
	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a style="margin-left: 15px;" href="index.php" class="navbar-brand">
            <img src="images/Fit_revolution.png">
      </a>
    </div>
	
	<div class="collapse navbar-collapse " id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav int">
	
			<li><a class="page-scroll" href="">HOME</a></li>
			<li><a class="page-scroll" href="#menu" >MENU</a></li>
			<li><a class="page-scroll" href="#call1">CACULATOR</a></li>
			<li><a class="page-scroll" href="#ourstory">OUR STORY</a></li>
		
			<li><a href="#" id="cart" data-toggle="modal" data-target="#myModal"><i class="fa fa-shopping-cart"></i> Cart <span class="badge cart_total"></span></a></li>
			<?php 
			if(empty($_SESSION['sessionuser_id'])){
			?>
			<li>
			<a class="minicart-link" data-toggle="modal" data-target="#myModal1" href="#">
			<img src="images/profile.png" />
			</a>
			</li>
			<?php }else{
				?>
				<li>
				<a class="minicart-link" data-toggle="modal" data-target="#myModal1" href="#"> <!-- href="myaccount.php" -->
				<img src="images/profile.png" />
				</a>
				</li>
				<?php 	
				}?>
	
		</ul>
		</div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>