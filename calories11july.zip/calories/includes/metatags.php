		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
		<title>Fit revolution</title>
		<link rel="shortcut icon" type="<?php echo SITE_URL;?>image/ico" href="images/favicon.ico" />

		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/bootstrap.min.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/jquery.selectBox.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/elegant-icon.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/font-awesome.min.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/style.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/commerce.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/form.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/custom.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/magnific-popup.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/preloader.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='<?php echo SITE_URL;?>css/skin-selector.css' type='text/css' media='all'/>
		
		
		<!-- Bootstrap Core CSS -->
  <!--   <link href="css/bootstrap.min.css" rel="stylesheet"> -->

    <!-- Custom CSS -->
    <link href="<?php echo SITE_URL;?>css/scrolling-nav.css" rel="stylesheet">
	
		<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans%3A400%2C700%7CDancing+Script%3A400%2C700%7CRoboto+Slab%3A400%2C700&amp;' type='text/css' media='all'/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
		<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>

<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/i18n/defaults-*.min.js"></script>
