		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.validate.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/easing.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/bootstrap.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.appear.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/script.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.blockUI.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.carouFredSel.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/isotope.pkgd.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.magnific-popup.min.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/jquery.parallax.js'></script>
		<script type='text/javascript' src='<?php echo SITE_URL;?>js/preloader.min.js'></script>
	    <!-- jQuery -->
	    
    <script src="<?php echo SITE_URL;?>js/jquery.js"></script>
    <script src="<?php echo SITE_URL;?>js/jquery-1.11.4.ui.mini.js"></script>


    <!-- Scrolling Nav JavaScript -->
    <script src="<?php echo SITE_URL;?>js/jquery.easing.min.js"></script>
    <script src="<?php echo SITE_URL;?>js/scrolling-nav.js"></script>
    <script src="<?php echo SITE_URL;?>js/userjs/script.js"></script>
    <script>
    $(document).ready(function(){
    	$.fn.cart_postLoad();
    });
    </script>