<section class="hero__content-footer hide-sm">
				<div class="container">
					<div class="row">
						
      <div class="col-md-2">
      	&nbsp;
      </div>
      <div class="col-md-8">
      	<input type="text" placeholder="lets Know what you ate?"><input type="button" value="search">
      </div>
      <div class="col-md-2">
      	&nbsp;
      </div>
					</div>
				</div>
			</section>