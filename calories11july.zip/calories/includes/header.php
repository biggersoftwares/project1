<?php
$sid=session_id();
$sql_cart_cnt="select * from temp_cart where sid='".$sid."'";
$res_cart_cnt=mysql_query($sql_cart_cnt);

$cnt_cart=mysql_num_rows($res_cart_cnt);
?>
<header class="header-container header-type-below header-navbar-below">
				<div class="navbar-header">
					<div class="container">
						<div class="navbar-header-left">
							<button data-target=".primary-navbar-collapse" data-toggle="collapse" type="button" class="navbar-toggle">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar bar-top"></span>
								<span class="icon-bar bar-middle"></span>
								<span class="icon-bar bar-bottom"></span>
							</button>
							<a class="cart-icon-mobile" href="#">
								<i class="minicart-icon-svg elegant_icon_cart_alt"></i>
							</a>
							<a class="navbar-brand" href="<?php echo SITE_URL;?>index.php">
								<img class="logo" alt="mr Calories" src="<?php echo SITE_URL;?>images/logo.png">
								<img class="logo-fixed" alt="mr Calories" src="<?php echo SITE_URL;?>images/logo.png">
								<img class="logo-mobile" alt="mr Calories" src="<?php echo SITE_URL;?>images/logo-mobile.png">
							</a>
							<div class="navsearch">
								<div class="navsearch-wrap">
									&nbsp;
								</div>
							</div>
						</div>
						<div class="navbar-header-center">
							<a class="navbar-brand" href="<?php echo SITE_URL;?>index.php">
								<img class="logo" alt="mr Calories" src="<?php echo SITE_URL;?>images/logo.png">
								<img class="logo-fixed" alt="mr Calories" src="<?php echo SITE_URL;?>images/logo.png">
								<img class="logo-mobile" alt="mr Calories" src="<?php echo SITE_URL;?>images/logo-mobile.png">
							</a>
						</div>
<?php
if($_SESSION['sessionuser_id']=="")
{
?>
						<div class="navbar-header-right" style="width:100px;">
							<div class="navcart">
								<div class="navcart-wrap">
									<a class="minicart-link" href="<?php echo SITE_URL;?>login.php" style="line-height:111px;">
											Login
											
										</a>
								</div>
							</div>
						</div>
						<?php
						}
						else
						{
						?>
						<div class="navbar-header-right" style="width:150px;">
							<div class="navcart">
								<div class="navcart-wrap"> 
									<a class="minicart-link" href="<?php echo SITE_URL;?>myaccount.php" style="line-height:111px;">
											My Account
											
										</a>&nbsp;<a class="minicart-link" href="<?php echo SITE_URL;?>logout.php" style="line-height:111px;">
											Logout
											
										</a>
								</div>
							</div>
						</div>
						<?php
						}
						?>
						<div class="navbar-header-right" style="width:150px;">
							<div class="navcart">
								<div class="navcart-wrap">
									<div class="navbar-minicart">
										<a class="minicart-link" href="#">
											Shopping cart 
											<span class="minicart-icon ">
												<i class="minicart-icon-svg elegant_icon_bag"></i> 
												<span><?php echo $cnt_cart;?></span>
											</span>
										</a>
										<div class="minicart">
										<?php
										if($cnt_cart==0)
										{
										?>
											<div class="minicart-header show">Your shopping bag is empty.</div>
											<?php
											}
											else
											{
											?>
											<div class="minicart-footer">
												<div class="minicart-actions clearfix">
													<a class="button" href="<?php echo SITE_URL;?>cart.php">
														<span class="text">Go to the Cart</span>
													</a>
												</div>
											</div>
											<?php
											}
											?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="navbar-container">
					<div class="navbar navbar-default navbar-scroll-fixed">
						
					</div>
				</div>
			</header>