<?php
date_default_timezone_set('Asia/Kolkata');


//  ****************************************     Regions  *************************

function view_products($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  ".DBEXT."products where status=1 order by product_name ASC";
	}
	else
	{
		$sql="select * from ".DBEXT."products where product_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_products_maincat($id)
{
		 $sql="select * from ".DBEXT."products where maincat_id=".$id." and status=1";
	
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_products_maincat_limit($id1,$id2)
{
		 $sql="select * from ".DBEXT."products where maincat_id=".$id1." and status=1 limit 0,".$id2;
	
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_product_desc($id)
{

	$sql="select * from ".DBEXT."product_desc where product_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}
function view_product_image_single($id)
{

	$sql="select * from ".DBEXT."product_images where product_id=".$id." order by prodimage_id ASC limit 0,1";
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}
function view_product_images($id)
{

	$sql="select * from ".DBEXT."product_images where product_id=".$id." order by prodimage_id ASC";
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_reviews($id)
{

	$sql="select * from ".DBEXT."reviews where product_id=".$id." order by review_id DESC";
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

//  ****************************************    Roles  *************************

function view_roles($id=0)
{
	
	if($id==0)
	{
		$sql="select * from ".DBEXT."roles where status=1 order by role_id ASC";
	}
	else
	{
		$sql="select * from ".DBEXT."roles where role_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
//  ****************************************     Sub Users  *************************

function view_subuser($id)
{

	$sql="select * from ".DBEXT."admin where  user_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}
//  ****************************************    Roles  *************************

function view_subusers($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from ".DBEXT."admin where status=1 order by user_name ASC";
	}
	else
	{
		$sql="select * from ".DBEXT."admin where user_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}



function forgot_pwd($datas)
{
		foreach($datas as $key => $value)
		$data[$key] = mysql_real_escape_string(trim($value));
		$res=query("select * from users where b_emailid='".$data['email']."'");
		$row=mysql_fetch_array($res);
		$num=mysql_num_rows($res);
		if($num==1)
		{
	     $subject = 'Andrew Wommack Ministries India';

// message

$message = '<div marginheight="0" marginwidth="0">
    	<div style="background-color:#f5f5f5;width:100%;margin:0;padding:70px 0 70px 0">
        	<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
            	<tbody>
                	<tr>
                    <td valign="top" align="center">
						<div></div>
                    	<span class="HOEnZb">
                        	<font color="#888888"></font>
                        </span>
                        <span class="HOEnZb">
                        	<font color="#888888"></font>
                        </span>
                        <table width="600" cellspacing="0" cellpadding="0" border="0" style="border-radius:6px!important;background-color:#fdfdfd;border:1px solid #dcdcdc;border-radius:6px!important">
                        	<tbody>
                            	<tr>
                                	<td valign="top" align="center">
                                		<table width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#557da1" style="background-color:#557da1;color:#ffffff;border-top-left-radius:6px!important;border-top-right-radius:6px!important;border-bottom:0;font-family:Arial;font-weight:bold;line-height:100%;vertical-align:middle">
                                        	<tbody>
                                            	<tr>
                                                	<td>
                                            			<h1 style="color:#ffffff;margin:0;padding:28px 24px;display:block;font-family:Arial;font-size:30px;font-weight:bold;text-align:left;line-height:150%">Welcome to Andrew Wommack Ministries India</h1>

                                            		</td>
                                        		</tr>
                                            </tbody>
                                        </table></td>
                            	</tr>
                                <tr>
                                	<td valign="top" align="center">
                                		<span class="HOEnZb">
                                        	<font color="#888888"></font>
                                        </span>
                                        	<table width="600" cellspacing="0" cellpadding="0" border="0">
                                            	<tbody>
                                                	<tr>
                                                    	<td valign="top" style="background-color:#fdfdfd;border-radius:6px!important">
                                                			<span class="HOEnZb">
                                                            	<font color="#888888"></font>
                                                            </span>
                                                            <table width="100%" cellspacing="0" cellpadding="20" border="0">
                                                            	<tbody>
                                                                	<tr>
                                                                    	<td valign="top">
                                                            				<div style="color:#737373;font-family:Arial;font-size:14px;line-height:150%;text-align:left">
																				<p>Your Password is <strong>'.base64_decode($row['pwd']).'</strong>.</p>
																				
																				<span class="HOEnZb">
                                                                                	<font color="#888888"></font>
                                                                                </span>
                                                                            </div>
                                                                            <span class="HOEnZb">
                                                                            	<font color="#888888"></font>
                                                                            </span>
                                                                        </td>
                                                                   </tr>
                                                                </tbody>
                                                           </table>
                                                      </td>
                                                  </tr>
                                              </tbody>
                                         </table>
                                   </td>
                               </tr>
                               <tr>
                               	<td valign="top" align="center">
                                	<table width="600" cellspacing="0" cellpadding="10" border="0" style="border-top:0">
                                    	<tbody>
                                        	<tr>
                                            	<td valign="top">
                                                	<table width="100%" cellspacing="0" cellpadding="10" border="0">
                                                    	<tbody>
                                                        	<tr>
                                                            	<td valign="middle" style="border:0;color:#99b1c7;font-family:Arial;font-size:12px;line-height:125%;text-align:center" colspan="2">
                                                        		<p>Andrew Wommack Ministries India</p>
                                                        		</td>
                                                    		</tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                        	</tr>
                                     	</tbody>
                                 	</table>
                             	</td>
                            </tr>
                       </tbody>
                   </table>
                </td>
              </tr>
           </tbody>
       </table>
   </div>
 <div class="yj6qo"></div>
 <div class="adL"></div>
</div>';


$to = $row['user_email'];
$headers .= 'From: '.FROM_NAME.' <'.FROM_MAIL.'>' . "\r\n";
//$headers .= "Reply-To: ". strip_tags($_POST['cemail']) . "\r\n";
//$headers .= "CC:".strip_tags($businessemail)."\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

// Mail it
mail($to, $subject, $message, $headers);
		
		return $num;
		}
		else
		{
		return 0;	
		}
	
	}


function view_maincategory($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  ".DBEXT."maincategory where status=1 order by maincat_id ASC";
		 }

	else
	{
		$sql="select * from ".DBEXT."maincategory where maincat_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_users($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  ".DBEXT."users where status=1 order by user_name ASC";
		 }

	else
	{
		$sql="select * from ".DBEXT."users where user_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_prod_reviews_count($id)
{
	$sql="select count(*) as cnt from ".DBEXT."reviews where product_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	return $row['cnt'];
	
}
function view_prod_reviews_total($id)
{
	$sql="select * from ".DBEXT."reviews where product_id=".$id;
	$res=mysql_query($sql);
	$total=0;
	while($row= mysql_fetch_array($res))
	{
		$total += $row['rating'];
	}
	return $total;
	
}
?>