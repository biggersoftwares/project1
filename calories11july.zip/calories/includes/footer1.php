<div class="footer-widget">
				<div class="container">
					<div class="footer-widget-wrap">
						<div class="row">
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget widget_text">
									<h3 class="widget-title">
										<span>Business Hours</span>
									</h3>
									<div class="textwidget">
										<p>
											mr Fit revolution opended in 1999 - We specialize in three course tasting menus, allowing the customer to select any three dishes from the menu for $52 per person.
										</p>
										<p>
											<strong>Mon - Fri: ---------- 8am - 5pm</strong><br/>
											<strong>Sat: ------------------ 8am - 11pm</strong><br/>
											<strong>Sun: ----------------- Closed</strong>
										</p>
									</div>
								</div>
							</div>
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget widget-post-thumbnail">
									<h3 class="widget-title">
										<span>Recent News</span>
									</h3>
									<ul class="posts-thumbnail-list">
										<li>
											<div class="posts-thumbnail-image">
												<a href="#">
													<img width="600" height="319" src="<?php echo SITE_URL;?>images/blog/blog-5.jpg" alt="blog-5" />
												</a>
											</div>
											<div class="posts-thumbnail-content">
												<h4><a href="#">Cheese Brie Sandwich</a></h4>
												<div class="posts-thumbnail-meta">
													<time datetime="2015-04-28T08:40:24+00:00">April 28, 2015</time>, 
													<span class="comment-count">
														<a href="#">0 Comments</a>
													</span>
												</div>
											</div>
										</li>
										<li>
											<div class="posts-thumbnail-image">
												<a href="#">
													<img width="600" height="319" src="<?php echo SITE_URL;?>images/blog/blog-2.jpg" alt="blog-2" />
												</a>
											</div>
											<div class="posts-thumbnail-content">
												<h4><a href="#">Fermentum Commodo Arcu</a></h4>
												<div class="posts-thumbnail-meta">
													<time datetime="2015-04-28T08:40:24+00:00">April 28, 2015</time>, 
													<span class="comment-count">
														<a href="#">0 Comments</a>
													</span>
												</div>
											</div>
										</li>
										<li>
											<div class="posts-thumbnail-image">
												<a href="#">
													<img width="600" height="319" src="<?php echo SITE_URL;?>images/blog/blog-3.jpg" alt="blog-3" />
												</a>
											</div>
											<div class="posts-thumbnail-content">
												<h4><a href="#">Cooking Lesson</a></h4>
												<div class="posts-thumbnail-meta">
													<time datetime="2015-04-28T08:40:24+00:00">April 28, 2015</time>, 
													<span class="comment-count">
														<a href="#">0 Comments</a>
													</span>
												</div>
											</div>
										</li>
									</ul>
								</div>
							</div>
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget tweets-widget">
									<h3 class="widget-title">
										<span>Latest Tweets</span>
									</h3>
									<div class="recent-tweets">
										<ul>
											<li>
												<span>
													Social Login for Magento allow users to log into your store through their social profiles <a href="#" target="_blank">http://t.co/H6b1SdBddu</a> <a href="#" target="_blank">http://t.co/cG9vSZoTjy</a>
												</span>
												<a class="twitter_time" target="_blank" href="#">223 days ago</a>
											</li>
											<li>
												<span>
													Copy VC shortcode for different purposes: in WP Widget Text, in do_shortcode function�. <a href="#" target="_blank">http://t.co/kgeZgVppr1</a> <a href="#" target="_blank">http://t.co/UT26ch7daD</a>
												</span>
												<a class="twitter_time" target="_blank" href="#">229 days ago</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget widget_nav_menu">
									<h3 class="widget-title">
										<span>Infomation</span>
									</h3>
									<div class="menu-infomation-container">
										<ul class="menu">
                                        <li><a href="calculator.php?is_ajax=1">Calculator</a></li>
                                        <li><a href="heartrate_calculator.php">Heart Rate Calculator</a></li>
                                          <li><a href="onerep_calculator.php">One Rep Calculator</a></li>
                                          <li><a href="calorie_target_calculator.php">Your Calorie Target</a></li>
                                            <li><a href="search_nutritionproducts.php">Nutrition Facts</a></li>
											<li><a href="#">Legal Notice</a></li>
											<li><a href="#">Terms of use</a></li>
											<li><a href="#">About us</a></li>
											<li><a href="#">Secure payment</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>