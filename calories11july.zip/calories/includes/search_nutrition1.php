<section class="hero__content-footer hide-sm">
				<div class="container">
					<div class="row">
						
      <div class="col-md-2">
      	&nbsp;
      </div>
      <div class="col-md-8">
	  <form name="frmsearch" method="post" action="search_nutritionproducts.php">
	  <input type="hidden" name="search" value="PRODSEARCH" />
      	<input type="text" name="prod_title" placeholder="Enter Item Name" value="<?php echo $row_main['name'];?>"><input type="button" onclick="funSearch()" name="srch" value="Search">
		</form>
      </div>
      <div class="col-md-2">
      	&nbsp;
      </div>
					</div>
				</div>
			</section>
			<script language="javascript" type="text/javascript">
			
			function funSearch()
			{
			if(document.frmsearch.prod_title.value=="")
			{
			alert("Enter Item ");
			document.frmsearch.prod_title.focus();
			return false;
			
			}
			document.frmsearch.submit();
			}
			</script>