<div align="center" style="width: 100%; overflow: hidden;">
				<video autoplay muted poster="<?php echo SITE_URL;?>images/videos/culinaria.jpg" id="bgvid" style="width:100%;">
					<source src="<?php echo SITE_URL;?>images/videos/video3.webm" type="video/webm">
					<source src="<?php echo SITE_URL;?>images/videos/video3.mp4" type="video/mp4">
					<source src="<?php echo SITE_URL;?>images/videos/video3.ogg" type="video/ogg">
				</video>
			</div>