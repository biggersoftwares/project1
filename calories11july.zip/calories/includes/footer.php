<footer class="footer">
				<div class="footer-info">
					<div class="container">
						<div class="footer-info-wrap">
							<div class="row">
								<div class="col-md-4 hidden-sm hidden-xs">
									<div class="copyright text-left">mr Fit revolution &copy; 2015</div>
								</div>
								<div class="col-md-4 col-sm-12 text-center">
									<div class="footer-info-logo">
										<a href="index.html">
											<img src="images/Fit_revolution.png" alt="mr Fit revolution">

										</a>
									</div>
									<br>
									<div class="footer-social">
										<a target="_blank" title="Facebook" href="#">
											<i class="fa fa-facebook facebook-bg-hover"></i>
										</a>
										<a target="_blank" title="Twitter" href="#">
											<i class="fa fa-twitter twitter-bg-hover"></i>
										</a>
										<a target="_blank" title="Google+" href="#">
											<i class="fa fa-google-plus google-plus-bg-hover"></i>
										</a>
										<a target="_blank" title="Pinterest" href="#">
											<i class="fa fa-pinterest pinterest-bg-hover"></i>
										</a>
										<a target="_blank" title="RSS" href="#">
											<i class="fa fa-rss rss-bg-hover"></i>
										</a>
										<a target="_blank" title="Instagram" href="#">
											<i class="fa fa-instagram instagram-bg-hover"></i>
										</a>
									</div>
								</div>
								<div class="col-md-4 hidden-sm hidden-xs">
									<div class="footer-info-text text-right">
										Designed by <a target="_blank" href="http://www.lptechlog.com">Lptechlog</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</footer>
				<script type="text/javascript">
			function goToByScroll(id){
          // Reove "link" from the ID
        id = id.replace("link", "");
          // Scroll
        $('html,body').animate({
            scrollTop: $("#"+id).offset().top},
            'slow');
    }

    $("#sidebbar > ul > li > a").click(function(e) { 
          // Prevent a page reload when a link is pressed
        e.preventDefault(); 
          // Call the scroll function
        goToByScroll($(this).attr("id"));           
    });

</script>
