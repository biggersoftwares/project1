$(document).ready(function(){
$.fn.cart_postLoad=function(i){
    	$discart=$("#display_cart");
        $($discart).find(".shopping_total").html("&#8360;"+$($discart).find(".total_amt").html());
       //$($discart).find(".shipg_amt").val();
        //alert($($discart).find(".numitems").html());
        //$(".cart_total").html($($discart).find(".numitems").html());
        
        $("span.cart_total").html($($discart).find(".numitems").html());
        
	
};


 $("#cart").on("click",function(){
	$("#display_cart").load("cartdisplay.php?is_ajax=1");
	$.fn.cart_postLoad();//here refress the cart.   
});
 
 
 $.fn.refresh_prodDiv=function(options){
	 var settings = $.extend({
		 "pname":""
         
     }, options );
	 
	 
	 //alert(JSON.stringify(settings));
	 
	 $.post('products.php?is_ajax=1',settings, function(data)
   		  {
		 	$("#products_display_div").html(data);
		 	$.fn.addtocart();
   		  });
 };
 
	 $(".gotoshoping").on("click",function(){
	 	 window.location.href='index.php#menu';
	 });

/*Script for add to cart animation cart start*/
	 
    $.fn.addImgtoCart = function( options ) {
        // This is the easiest way to have default options.
        var settings = $.extend({
            // These are the defaults.
            "cartCls":"fa-shopping-cart"
        }, options );

           	imgtodrag=$(this);
        var cart = $('.'+settings.cartCls);
        if (imgtodrag) {
            var imgclone = imgtodrag.clone()
                .offset({
                top: imgtodrag.offset().top,
                left: imgtodrag.offset().left
            })
                .css({
                'opacity': '0.5',
                    'position': 'absolute',
                    'height': '150px',
                    'width': '150px',
                    'z-index': '100'
            })
                .appendTo($('body'))
                .animate({
                'top': cart.offset().top + 10,
                    'left': cart.offset().left + 10,
                    'width': 75,//75
                    'height':75
            }, 1000, 'easeInOutExpo');
            
            setTimeout(function () {
                cart.effect("shake", {
                    times: 2
                }, 200);
            }, 1500);

            imgclone.animate({
                'width': 0,
                    'height': 0
            }, function () {
                $(this).detach()
            });
        } 
    };

    $.fn.addItemtoCart = function( options ) {
        // This is the easiest way to have default options.
        var settings = $.extend({
        	'act':'ADDTOCART'
        }, options );

        $.post('cart_functions.php',settings, function(data)
        		  { 
				 		 $("#display_cart").load("cartdisplay.php?is_ajax=1");
						//$.fn.cart_postLoad();//here refress the cart.     
        		  });
    };
    
    /******************************************************************/
    
    $.fn.addtocart=function(){
    	$('.add-to-cart').on('click', function () {

    		var cart = $('.fa-shopping-cart');
    		var pcontainer=$(this).closest("div.product-container");//parent div
            var imgtodrag = $(this).closest('.product').find(".product-image");//image data
            var psiz_slct=$(pcontainer).find("select.product_size");//select box data
            /**here gathering the required data*/
            $json_data={};
            $json_data.pid=$pid=$(pcontainer).attr("pid");
            $json_data.price=$(psiz_slct).find(":selected").attr("price");
            $json_data.psz_id=$(psiz_slct).find(":selected").val();
            $json_data.psz=$(psiz_slct).find(":selected").text();
            $json_data.qty=$(pcontainer).find(".quantity").val();
            //$json_data.shopping_cart="shopping-cart";
            //-------------------------------------------------------
          	 var numItems=$.trim($("span.cart_total").html());
       		   if(numItems==""){
       			   numItems=0;
       		 }
       		numItems=parseInt(numItems)+parseInt($json_data.qty);
       		$("span.cart_total").html(numItems);
       //-----------------------------------------------------------------------
            //alert(JSON.stringify($json_data));
            imgtodrag.addImgtoCart({"cartCls":"fa-shopping-cart"});
            imgtodrag.addItemtoCart($json_data);

           // jQuery.ajax({async:false});
        });
    };
    
    //$("#display_cart").load("cartdisplay.php?is_ajax=1");  
/*Script for add to cart animation cart start*/
/* Script for product_size change to change the price start */

$('.product_size').on('change', function () {
$this=$(this);
$parent_div=$($this).closest("div.product-container");
$price=$($this).find(":selected").attr("price");
$rprice=$($this).find(":selected").attr("rprice");
$($parent_div).find(".prodict_price").html($price);
$($parent_div).find(".reguler_price").html($rprice);
});
/* Script for product_size change to change the price end */

/*Script for social login*/
/*$.fn.social_login=function( options ) {
    // This is the easiest way to have default options.
    var settings = $.extend({
    	'act':'social_login'
    }, options );
    alert(JSON.stringify(settings));
    $.post('social/social_login.php',settings, function(data)
    		  { 
    			alert(data);
    		  });
};
$(".social").on("click",function(){
$this=$(this);
id=$.trim($($this).attr("id"));

json={"type":id};

$.fn.social_login(json);

});*/
/**script for social login end**/

$.fn.addtocart();
$.fn.cart_postLoad();

});    