$( document ).ready(function() {
$("#calculate").click(function(){

var weight_lifted = $('#weight_lifted').val();



        if ($.trim(weight_lifted).length == 0) {

		$("#weight_lifted").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }

var reps = $('#reps').val();
 var  maxhr = Math.round(parseInt(weight_lifted) / reps);

var one=Math.round(0.95*parseInt(maxhr));
var two=Math.round(0.90*parseInt(maxhr));
var three=Math.round(0.85*parseInt(maxhr));
var four=Math.round(0.80*parseInt(maxhr));
var five=Math.round(0.75*parseInt(maxhr));
var six=Math.round(0.70*parseInt(maxhr));
var seven=Math.round(0.65*parseInt(maxhr));
var eight=Math.round(0.60*parseInt(maxhr));
var nine=Math.round(0.55*parseInt(maxhr));
var ten=Math.round(0.50*parseInt(maxhr));

	$("#maxhrspan").html(maxhr);
	
	$("#one").val(one);
	$("#two").val(two);
	$("#three").val(three);
	$("#four").val(four);
	$("#five").val(five);
	
	$("#six").val(six);
	$("#seven").val(seven);
	$("#eight").val(eight);
	$("#nine").val(nine);
	$("#ten").val(ten);
	

        
	});	
});