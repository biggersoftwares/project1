$( document ).ready(function() {
$("#calculate").click(function(){

var height = $('#height').val();
        if ($.trim(height).length == 0) {
		$("#height").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
var weight = $('#weight').val();
        if ($.trim(weight).length == 0) {
		$("#weight").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
						
var age = $('#age').val();
        if ($.trim(age).length == 0) {
		$("#age").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
	
	var radioValue = $("input[name='gender']:checked").val();	
	
var activity_level = $('#activity_level').val();
        if ($.trim(activity_level).length == 0) {
		$("#activity_level").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
				

	
	var dataString = "height="+$("#height").val()+"&weight="+$("#weight").val()
	+"&age="+$("#age").val()+"&gender="+radioValue+"&activity_level="+$("#activity_level").val(); 
			$.ajax({
				  type: "POST",
				  url: "calorietarget_calculator_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				
				   $("#calorietargetdiv").html(data);
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});	
		
});