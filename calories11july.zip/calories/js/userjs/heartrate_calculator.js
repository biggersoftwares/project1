$( document ).ready(function() {
$("#calculate").click(function(){

var age = $('#age').val();

        if ($.trim(age).length == 0) {

		$("#age").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }


var maxhr = 220-parseInt(age);
var one=Math.round(0.95*parseInt(maxhr));
var two=Math.round(0.90*parseInt(maxhr));
var three=Math.round(0.85*parseInt(maxhr));
var four=Math.round(0.80*parseInt(maxhr));
var five=Math.round(0.75*parseInt(maxhr));
var six=Math.round(0.70*parseInt(maxhr));
var seven=Math.round(0.65*parseInt(maxhr));
var eight=Math.round(0.60*parseInt(maxhr));
var nine=Math.round(0.55*parseInt(maxhr));
var ten=Math.round(0.50*parseInt(maxhr));

	$("#maxhrspan").html(maxhr+' BPM');
	
	$("#one").val(one+' BPM');
	$("#two").val(two+' BPM');
	$("#three").val(three+' BPM');
	$("#four").val(four+' BPM');
	$("#five").val(five+' BPM');
	
	$("#six").val(six+' BPM');
	$("#seven").val(seven+' BPM');
	$("#eight").val(eight+' BPM');
	$("#nine").val(nine+' BPM');
	$("#ten").val(ten+' BPM');
	

        
	});	
});