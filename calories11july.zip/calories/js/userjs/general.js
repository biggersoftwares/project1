function checkNumber(textBox)

{

	while (textBox.value.length > 0 && isNaN(textBox.value)) {

		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	}

	

	textBox.value = textBox.value;

/*	if (textBox.value.length == 0) {

		textBox.value = 0;		

	} else {

		textBox.value = parseInt(textBox.value);

	}*/

}
	function AlphaNumeric_space(textBox)
{

	
	var regEx = new RegExp("^[a-zA-Z0-9 ]+$");
	 if (!$("#user_name").val().match(regEx))
	 {
		
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	 }

textBox.value = textBox.value;
}
function AlphaNumeric_special(textBox)
{
	
	
	var regEx = new RegExp("^[a-zA-Z0-9._@]+$");
	 if (!$("#remail_id").val().match(regEx))
	 {
		
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	 }

textBox.value = textBox.value;
}