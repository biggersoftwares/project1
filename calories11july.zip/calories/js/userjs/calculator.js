
/*Calculate the data*/
$( document ).ready(function() {
$("#calculate").click(function(){

var height = $('#height').val();
        if ($.trim(height).length == 0) {
		$("#height").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
var weight = $('#weight').val();
        if ($.trim(weight).length == 0) {
		$("#weight").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
						
var age = $('#age').val();
        if ($.trim(age).length == 0) {
		$("#age").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
	
	var radioValue = $("input[name='gender']:checked").val();	
	var waist_fullest = $('#waist_fullest').val();
        if ($.trim(waist_fullest).length == 0) {
		$("#waist_fullest").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
				
				var waist_naval = $('#waist_naval').val();
        if ($.trim(waist_naval).length == 0) {
		$("#waist_naval").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
				
			var hip_fullest = $('#hip_fullest').val();
	if ($.trim(hip_fullest).length == 0) {
	$("#hip_fullest").css({"border": "1px solid","color":"#F00"});	
		return false;
			}				
				var forearm_fullest = $('#forearm_fullest').val();
        if ($.trim(forearm_fullest).length == 0) {
		$("#forearm_fullest").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
	var weight_lifted = $('#weight_lifted').val();
        if ($.trim(weight_lifted).length == 0) {
		$("#weight_lifted").css({"border": "1px solid","color":"#F00"});
			return false;
		        }
var reps = $('#reps').val();
        if ($.trim(reps).length == 0) {
		$("#reps").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }		
var daily_workouttime = $('#daily_workouttime').val();
        if ($.trim(daily_workouttime).length == 0) {
		$("#daily_workouttime").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
				
var goal = $('#goal').val();
   if ($.trim(goal).length == 0) {
$("#goal").css({"border": "1px solid","color":"#F00"});	
return false;
		        }
var activity_level = $('#activity_level').val();
        if ($.trim(activity_level).length == 0) {
		$("#activity_level").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
				

	
	var dataString = "height="+$("#height").val()+"&weight="+$("#weight").val()
	+"&age="+$("#age").val()+"&gender="+radioValue+"&waist_fullest="+$("#waist_fullest").val()
	+"&waist_naval="+$("#waist_naval").val()
	+"&hip_fullest="+$("#hip_fullest").val()+"&forearm_fullest="+$("#forearm_fullest").val()	
	+"&weight_lifted="+$("#weight_lifted").val()+"&reps="+$("#reps").val()
	+"&daily_workouttime="+$("#daily_workouttime").val()+"&goal="+$("#goal").val()
	+"&activity_level="+$("#activity_level").val(); 
			$.ajax({
				  type: "POST",
				  url: "calculator_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				  var str=data.split("_");
				   $("#bmrdiv").html(str[0]);
				   $("#bmidiv").html(str[1]);
				    $("#leanbodymassdiv").html(str[2]);
					$("#bodyfatweightdiv").html(str[3]);
				   $("#bodyfatpercentagediv").html(str[4]);
				   $("#rdeediv").html(str[5]);
				   $("#heartratediv").html(str[6]);
				    $("#onerepmaxdiv").html(str[7]);
					$("#waterintakediv").html(str[8]);
				   $("#proteinintakediv").html(str[9]);
				    $("#fatintakediv").html(str[10]);
					$("#creatineintakediv").html(str[11]);
				   $("#carbohydratediv").html(str[12]);
		
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});	
		
});		
		