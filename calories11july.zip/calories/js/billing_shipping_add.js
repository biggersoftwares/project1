$( document ).ready(function() {
							 
function validateEmail(sEmail) {
var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
if (filter.test(sEmail)) {
return true;
}
else {
return false;
}
}
$("#sbtplaceorder").click(function(){
	
	if($("#b_firstname").val()=="")
	{
		$("#b_firstname").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	if($("#b_address").val()=="")
	{
		$("#b_address").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	if($("#b_city").val()=="")
	{
		$("#b_city").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	if($("#b_zipcode").val()=="")
	{
		$("#b_zipcode").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	//  Email Validation
	var sEmail = $('#b_emailid').val();
        if ($.trim(sEmail).length == 0) {
		$("#b_emailid").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
        if (!validateEmail(sEmail)) {
		$("#b_emailid").css({"border": "1px solid","color":"#F00"});	
			return false;
		}
	if($("#b_mobileno").val()=="")
	{
		$("#b_mobileno").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	//  Shipping address
	
	
	if($("#s_firstname").val()=="")
	{
		$("#s_firstname").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	
	if($("#s_address").val()=="")
	{
		$("#s_address").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	if($("#s_city").val()=="")
	{
		$("#s_city").css({"border": "1px solid","color":"#F00"});
		return false;
	}
		
	if($("#s_zipcode").val()=="")
	{
		$("#s_zipcode").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	//  Email Validation
	var sEmail = $('#s_emailid').val();
        if ($.trim(sEmail).length == 0) {
		$("#s_emailid").css({"border": "1px solid","color":"#F00"});	
			return false;
		        }
        if (!validateEmail(sEmail)) {
		$("#s_emailid").css({"border": "1px solid","color":"#F00"});	
			return false;
		}
	if($("#s_mobileno").val()=="")
	{
		$("#s_mobileno").css({"border": "1px solid","color":"#F00"});
		return false;
	}
if($("#product_specifications").val()=="")
	{
		$("#product_specifications").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	var dataString = "b_firstname="+$("#b_firstname").val()+"&b_lastname="+$("#b_lastname").val()
					+"&b_address="+$("#b_address").val()+"&b_address1="+$("#b_address1").val()
					+"&b_city="+$("#b_city").val()+"&b_zipcode="+$("#b_zipcode").val()
					+"&b_emailid="+$("#b_emailid").val()+"&b_mobileno="+$("#b_mobileno").val()
					+"&s_firstname="+$("#s_firstname").val()+"&s_lastname="+$("#s_lastname").val()
					+"&s_address="+$("#s_address").val()+"&s_address1="+$("#s_address1").val()
					+"&s_city="+$("#s_city").val()+"&s_zipcode="+$("#s_zipcode").val()
					+"&s_emailid="+$("#s_emailid").val()+"&s_mobileno="+$("#s_mobileno").val()+"&landmark="+$("#landmark").val()
					+"&username="+$("#username").val()+"&pwd="+$("#pwd").val()+"&user_email="+$("#user_email").val()
					+"&mobileno="+$("#mobileno").val();  
					
			$.ajax({
				  type: "POST",
				  url: "scripts/billing_shipping_add.php",
				  data: dataString,
				  success: function(data)
				  { 
				//document.write(data);
			if(data==2)
				  {				
				  $("#resultdiv").html('<div id="check_one"><div class="check_box"><strong>Already  Email Id Existed</strong></div></div>');
				  }
				else if(data==3)
				  {

					$(location).attr('href', 'your_order.php');
				  }
				  
				   else if(data==4)
				  {

				   $("#resultdiv").html('<div id="check_one"><div class="check_box"><strong>Not Inserted</strong></div></div>');
				  }
				   
				  else				   
				  {
				   $("#resultdiv").html('<div id="check_one"><div class="check_box"><strong>Fill all the fields</strong></div></div>');
				   
				  }
				   
				   
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
			});
			
			
			

});