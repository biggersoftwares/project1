<?php
include("config/db_connection.php");
include("includes/functions.php");
session_start();
$sid=session_id();
if($_SESSION['sessionuser_id']=="")
{
	$user_id=0;
}
else
{
	$user_id=$_SESSION['sessionuser_id'];
}
if($_POST['act']=='ADDTOCART')
{

	$pid=strip_tags(trim($_POST['pid']));
	$psz_id=strip_tags(trim($_POST['psz_id']));
	if(!empty($_POST['qty'])){
	$qty=strip_tags(trim($_POST['qty']));
	}else{
		$qty=1;
	}
	
	$post_date=date('Y-m-d');
	

	$sql_cart="select * from temp_cart where sid='".$sid."' and prod_id=".$pid. " and product_size_id=".$psz_id;
	$res_cart=mysql_query($sql_cart);
	if(mysql_num_rows($res_cart)==0)
	{
		$ins_temp="insert into temp_cart (
									prod_id,
									user_id,
									qty,
									product_size_id,
									sid,
									post_date
								)
								values

								(
									'".$pid."',
									'".$user_id."',
									'".$qty."',
									'".$psz_id."',
									'".$sid."',
									'".$post_date."'
								)";
		$res=mysql_query($ins_temp);
	}
	else
	{
		$row=mysql_fetch_array($res_cart);
		$qty=$row['qty']+1;
		$upd_cart="update temp_cart set user_id=".$user_id.",qty=".$qty." where sid='".$sid."' and prod_id=".$pid;
		$res=mysql_query($upd_cart);
	}
	/* if($res)
	{
		header("Location:cart.php");
		exit;
	} */
}
?>