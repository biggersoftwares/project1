<?php 
include("../config/db_connection.php");
include("../config/constants.php");
include("includes/functions.php");
include("includes/loginsession.php");


$msg="";
if($_POST['act']=='INSERT')
{
$maincat_id=addslashes(strip_tags(trim($_POST['maincat_id'])));

$food_type=addslashes(strip_tags(trim($_POST['food_type'])));
$product_name=addslashes(strip_tags(trim($_POST['product_name'])));
$calories=addslashes(trim($_POST['calories']));
$fat=addslashes(trim($_POST['fat']));
$proteins=addslashes(trim($_POST['proteins']));
$sugar=addslashes(trim($_POST['sugar']));
$regular_price=strip_tags(trim($_POST['small_regular_price']));
$sale_price=strip_tags(trim($_POST['small_sale_price']));
$regular_price1=strip_tags(trim($_POST['medium_regular_price']));
$sale_price1=strip_tags(trim($_POST['medium_sale_price']));
$regular_price2=strip_tags(trim($_POST['large_regular_price']));
$sale_price2=strip_tags(trim($_POST['large_sale_price']));

$post_date=date('Y-m-d');

  $ins1="insert into products ( 
                        product_name,
                        maincat_id,
                        food_type,
                        calories,
                        fat,
                        proteins,
                        sugar,
                        regular_price,
                        sale_price,
                        post_date
                )	
                values

                (
                        '".$product_name."',
                        '".$maincat_id."',
                        '".$food_type."',
                        '".$calories."',
                        '".$fat."',
                        '".$proteins."',
                        '".$sugar."',
                        '".$regular_price."',
                        '".$sale_price."',
                        '".$post_date."'
                )";
		$res1=mysql_query($ins1);
		$product_id=mysql_insert_id();	

//************************************************************************	
                $price_data = array();
                if($regular_price != "") {
                    $price_data[0]['product_size_id'] = 1;
                    $price_data[0]['regular_price'] = $regular_price;
                    $price_data[0]['sale_price'] = $sale_price;
                }
                if($regular_price1 != "") {
                    $price_data[1]['product_size_id'] = 2;
                    $price_data[1]['regular_price'] = $regular_price1;
                    $price_data[1]['sale_price'] = $sale_price1;
                }
                if($regular_price2 != "") {
                    $price_data[2]['product_size_id'] = 3;
                    $price_data[2]['regular_price'] = $regular_price2;
                    $price_data[2]['sale_price'] = $sale_price2;
                }
                $price_data = array_values($price_data);
                   for($i=0;$i<count($price_data);$i++) { 
                        $product_size_id = $price_data[$i]['product_size_id'];
                        $regular_price1 = $price_data[$i]['regular_price'];
                        $sale_price1 = $price_data[$i]['sale_price'];
                        $ins1="insert into product_prices ( 
                                            product_id,
                                            product_size_id,
                                            regular_price,
                                            sale_price
                                    )	
                                    values
                                    (
                                            '".$product_id."',
                                            '".$product_size_id."',
                                            '".$regular_price1."',
                                            '".$sale_price1."'
                                    )";
                        mysql_query($ins1);
                   }

// ******************** Product description ********************

$product_desc=addslashes(trim($_POST['product_desc']));
 $ins2="insert into product_desc ( 
									product_id,
									prod_desc
								)	
								values
								
								(
									'".$product_id."',
									'".$product_desc."'
								)";
		$res2=mysql_query($ins2);



//   *******************************  Product Images *****************************


for($k=0;$k<count($_FILES['file']['name']);$k++)
{

    
 	// some information about image we need later.
$ImageName 		= $_FILES["file"]["name"][$k];
$ImageSize 		= $_FILES["file"]["size"][$k];
$TempSrc	 	= $_FILES["file"]["tmp_name"][$k];
$ImageType	 	= $_FILES["file"]["type"][$k];


if ($ImageName) 
{
	

	
	
	//  ****************************************  Start Original Image  ******************************************
	//  To uploadd  ORIGINAL IMAGE
	
		///////////////////////////////////////////////////////////////////////////
		 // $imgname="../prod_images/original/".rand(10, 99)."_".$_FILES["file"]["name"][$k];// the path with the file name where the file will be stored, upload is the directory name. 
		  
		  $img_name=rand(10, 99)."_".$_FILES["file"]["name"][$k];
		 $imgname="../prod_images/".$img_name; // the path with the file name where the file will be stored, upload is the directory name. 
	//echo $_FILES['fleImage']['type'];
	if (!($_FILES["file"]["type"] [$k]=="image/jpeg" OR $_FILES["file"]["type"][$k]=="image/gif" 
	 OR $_FILES["file"]["type"][$k]=="image/jpg" OR $_FILES["file"]["type"][$k]=="image/png" OR $_FILES["file"]["type"][$k]=="image/pjpeg"))
	{
		echo "Your uploaded file must be of JPG or GIF or PNG. Other file types are not allowed<BR>";
		exit;
	}//if
	else
	{
			if(move_uploaded_file ($_FILES["file"]["tmp_name"][$k],$imgname))
			{
				
				$original_image=basename($imgname);
				//echo "Successfully uploaded the Image";
				chmod("$imgname",0777);
			}
			else
			{
				echo "Failed to upload file Contact Site admin to fix the problem";
				exit;
			}
	}//else
	
///////// Start the thumbnail generation//////////////
		$n_width=80;          // Fix the width of the thumb nail images
		$n_height=50;         // Fix the height of the thumb nail imaage
		////////////////////////////////////////////
		 $add=$imgname;
		$tsrc="../prod_images/thumb/".$img_name;   // Path where thumb nail image will be stored
		//echo $tsrc;
		if (!($_FILES['file']['type'][$k] =="image/jpeg" OR $_FILES['file']['type'][$k]=="image/gif" OR $_FILES['file']['type'][$k]=="image/png"))
		{
				echo "Your uploaded file must be of JPG or GIF or PNG. Other file types are not allowed<BR>";
				exit;
		}
				/////////////////////////////////////////////// Starting of GIF thumb nail creation///////////
				if (@$_FILES['file']['type'][$k]=="image/gif")
				{
					$im=imagecreatefromgif($add);
					$width=imagesx($im);              // Original picture width is stored
					$height=imagesy($im);                  // Original picture height is stored
					$n_height=($n_width/$width) * $height; // Add this line to maintain aspect ratio
					$newimage=imagecreatetruecolor($n_width,$n_height);
					imagecopyresized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
						if (function_exists("imagegif"))
						{
							header("Content-type: image/gif");
							imagegif($newimage,$tsrc);
						}
						elseif (function_exists("imagejpeg"))
						{
							header("Content-type: image/jpeg");
							imagejpeg($newimage,$tsrc);
						}
					chmod("$tsrc",0777);
				}////////// end of gif file thumb nail creation//////////
		
		////////////// starting of JPG thumb nail creation//////////
		if($_FILES['file']['type'][$k]=="image/jpeg")
		{
		$im=imagecreatefromjpeg($add); 
		$width=imagesx($im);              // Original picture width is stored
		$height=imagesy($im);             // Original picture height is stored
		$n_height=($n_width/$width) * $height; // Add this line to maintain aspect ratio
		$newimage=imagecreatetruecolor($n_width,$n_height);                 
		imagecopyresized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
		imagejpeg($newimage,$tsrc);
		chmod("$tsrc",0777);
		}
		
		if($_FILES['file']['type'][$k]=="image/png")
		{
		$im=imagecreatefrompng($add); 
		$width=imagesx($im);              // Original picture width is stored
		$height=imagesy($im);             // Original picture height is stored
		$n_height=($n_width/$width) * $height; // Add this line to maintain aspect ratio
		$newimage=imagecreatetruecolor($n_width,$n_height);                 
		imagecopyresized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
		imagepng($newimage,$tsrc);
		chmod("$tsrc",0777);
		}
	
// *******************************  End of Thumbnail Creation ****************************
	
	//  ****************************************  END OF Original Image  ******************************************
	 $ins6="insert into product_images ( 
										product_id,
										prodimage_original
									)	
									values
									
									(
										'".$product_id."',
										'".$original_image."'
									)";
			$res5=mysql_query($ins6);
	
		
}// if

}// for
if($res1)
{
header("Location:products.php");
}
}
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
                   	
   <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
 <!-- style added for image prview -->
 <style>
.imagePreview {
    width: 180px;
    height: 180px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
</style>

  <script language="javascript">
	$( document ).ready(function() {

$("#sbtbtn").click(function(){
        if($("#maincat_id").val()=="")
	{
		$("#maincat_id").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	if($("#product_name").val()=="")
	{
		$("#product_name").css({"border": "1px solid","color":"#F00"});
		return false;
	}
        if($("#small_regular_price").val()=="" && $("#medium_regular_price").val()=="" && $("#large_regular_price").val()=="")
	{
		$("#small_regular_price").css({"border": "1px solid","color":"#F00"});
		return false;
	}




$("#act").val('INSERT');
$("#frm").submit();
});
});
	</script>	
		<script type="text/javascript"> 
$(document).ready(function() { 
//elements
var progressbox 		= $('#progressbox'); //progress bar wrapper
var progressbar 		= $('#progressbar'); //progress bar element
var statustxt 			= $('#statustxt'); //status text element
var submitbutton 		= $("#SubmitButton"); //submit button
var myform 				= $("#UploadForm"); //upload form
var output 				= $("#output"); //ajax result output element
var completed 			= '0%'; //initial progressbar value
var FileInputsHolder 	= $('#AddFileInputBox'); //Element where additional file inputs are appended
var MaxFileInputs		= 10; //Maximum number of file input boxs

// adding and removing file input box
var i = $("#AddFileInputBox div").size() + 1;
$("#AddMoreFileBox").click(function () {
		//event.returnValue = false;
		if(i < MaxFileInputs)
		{
			
			$('<br/><span><input type="file" style="float:left; width:52% " id="fileInputBox" size="20" name="file[]" class="addedInput" value=""/>&nbsp;&nbsp;<a href="#" style="float:left" class="removeclass small2"><img src="images/delete.gif"  border="0" />&nbsp;Remove</a></span>').appendTo(FileInputsHolder);
			i++;
		}
		return false;
});

$("body").on("click",".removeclass", function(e){
		//event.returnValue = false;
		if( i > 1 ) {
				$(this).parents('span').remove();i--;
		}
		
}); 

$("#ShowForm").click(function () {
  $("#uploaderform").slideToggle(); //Slide Toggle upload form on click
});
	


}); 
</script> 
<script language="javascript" type="text/javascript">
    function checkNumber(textBox)

{

	while (textBox.value.length > 0 && isNaN(textBox.value)) {

		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	}

	

	textBox.value = textBox.value;

/*	if (textBox.value.length == 0) {

		textBox.value = 0;		

	} else {

		textBox.value = parseInt(textBox.value);

	}*/

}
	


</script>

    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
           <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Products
                       <small><?php
if($_REQUEST['act']=='UPDATE')
{ ?> Update <?php } else { ?> Add New <?php } ?> </small>
                    </h1><?php if($msg!="") { echo $msg; } ?>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="products.php">View All Products</a></li>
                       <!--<li class="active">Roles</li>-->
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<?php
if($_REQUEST['act']=='UPDATE')
{
$v=view_maincategory($_REQUEST['id']);


}
?>
				<form name="frm" method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'];?>">
				<input type="hidden" name="act" id="act" value="" />
            <input type="hidden" name="id"  id="id" value="<?php echo $_REQUEST['id'] ; ?>" />
			
                 <div class="row">
                        <div class="col-md-8">

                            <div class="box box-info">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
								
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          Main Category</div>
                                        <div class="col-xs-3">
            <select class="form-control" name="maincat_id">
			<option value=""> Select </option>
			<?php
$sql1="select * from  maincategory  where status=1 order by maincat_name ASC";
$res1=mysql_query($sql1);
while($row1=mysql_fetch_array($res1))
{

?>	
	<option value="<?php echo $row1['maincat_id'];?>"><?php echo $row1['maincat_name'];?></option>
                                             <?php
											 }
											 ?>
                                                
                                            </select>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								
								
								  <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Food Type                                       </div>
                                        <div class="col-xs-3">
             <select class="form-control" name="food_type" id="food_type">
											
				<option value="1">Veg</option>
				<option value="2">Non Veg</option>
				
											</select>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Product Name <font color="#FE5E0A">*</font>                                        </div>
                                        <div class="col-xs-9">
             <input type="text" class="form-control" name="product_name" id="product_name" value="" required>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								 
								   <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Actual Price <font color="#FE5E0A">*</font>                                      </div>
                                        <div class="col-xs-3">                                    
                                            <table width="100%">
                                                <tr>
                                                    <td>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control"  name="small_regular_price" id="small_regular_price" style="width:75px;" placeholder="Small" value="<?php echo stripslashes($v[0]['regular_price']); ?>" onKeyUp="checkNumber(this);" required>
                                                            <span class="input-group-addon">.00</span>
                                                        </div> 
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control"  name="medium_regular_price" id="medium_regular_price" style="width:75px;" placeholder="Medium" value="<?php echo stripslashes($v[0]['regular_price']); ?>" onKeyUp="checkNumber(this);" required>
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control"  name="large_regular_price" id="large_regular_price" style="width:75px;" placeholder="Large" value="<?php echo stripslashes($v[0]['regular_price']); ?>" onKeyUp="checkNumber(this);" required>
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Sale Price                                        </div>
                                        <div class="col-xs-3">
                                            <table width="100%">
                                                <tr>
                                                    <td>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control" style="width:75px;" placeholder="Small"  name="small_sale_price" id="small_sale_price" value="" onKeyUp="checkNumber(this);">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control" style="width:75px;" placeholder="Medium"  name="medium_sale_price" id="medium_sale_price" value="" onKeyUp="checkNumber(this);">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control" style="width:75px;" placeholder="Large"  name="large_sale_price" id="large_sale_price" value="" onKeyUp="checkNumber(this);">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>                                    
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          Calories                                        </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="calories" id="calories" value="">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Fat                                   </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="fat" id="fat" value="">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                         Proteins                                      </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="proteins" id="proteins" value="">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                         Sugar                                      </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="sugar" id="sugar" value="">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								
								
								 	  <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-12"><div class="form-group">
                                        <label><a href="#" id="AddMoreFileBox">Add More Product Images</a></label><strong><font color="#FE5E0A">(  Sizes width= 400 to 500px  and height= 300 to 400px )</font></strong>
                                        <div id="AddFileInputBox">
                                        <div class="col-xs-6">
                                        <input id="fileInputBox" style="margin-bottom: 5px;" type="file"  name="file[]"/>
                                        </div>
                                        <div class="imagePreview col-xs-6"></div>
                                        </div>
    <div class="sep_s"></div>
                                    </div>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								 
								  <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-12">
								    <div class='box box-info'>
								       <div class='box-header'>
                                    <h3 class='box-title'>Product Description</h3>
                                    <!-- tools box -->
                                    <div class="pull-right box-tools">
                                        <button class="btn btn-info btn-sm" data-widget='collapse' data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                                        <button class="btn btn-info btn-sm" data-widget='remove' data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                                    </div><!-- /. tools -->
                                </div><!-- /.box-header -->
                                <div class='box-body pad'>
                                    
                                        <textarea class="textarea"  name="product_desc"  id="product_desc" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                                    
                                </div>
								  
								  </div></div></div></div>
                            </div><!-- /.box -->

                        </div><!-- /.col (left) -->
                       
                    </div>
					
										<div class='row'>
                        <div class='col-md-12'>
                          
<div class="box-body">
                                    <div class="row">
									<div class="col-xs-6">&nbsp;</div>
                                        <div class="col-xs-2">
                                      
										  
                        <button id="sbtbtn" name="button1id" class="btn btn-primary">Add Product </button>
					  
                                        </div>
                                        
                                    </div>
                                </div>
                             
                        </div><!-- /.col-->
                    </div>
</form>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
        <!-- Bootstrap WYSIHTML5 -->
        <script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <script src="js/userjs/imageload.js"></script>
      

    </body>
</html>
