﻿<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");
include("../includes/mail_function.php");

if($_GET['paystatus']==1)
{
 $sql_pay="update invoice set payment_status='".$_GET['paystatus']."' where invoice_id ='".$_GET['invoice_id']."'";
mysql_query($sql_pay);

}

if($_POST['act']=='deleteall')
{
	$values=implode(",",$_REQUEST['id']);	 
	try
	{
	 $invoiceids=$_REQUEST['id'];	 
 for($x=0;$x<count($invoiceids);$x++)
 {
 
 $sel_invoice="select * from invoice where invoice_id='".$invoiceids[$x]."'";
$res_invoice=mysql_query($sel_invoice);
$row_invoice=mysql_fetch_array($res_invoice);
 
 
   $sql_mailuser="select * from bill_ship_address where user_id='".$row_invoice['user_id']."'";
$res_mailuser=mysql_query($sql_mailuser);
$row_mailuser=mysql_fetch_array($res_mailuser);

$subject = 'Your Mr Colorie order cancelled on '.date('F, d Y') ;

// message
  $msg1 = '<table cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="max-width:730px!important;width:100%">
       
      
      
        <tbody><tr>
          <td width="30" bgcolor="#f3f3f3" background="https://ci6.googleusercontent.com/proxy/IkNIBG8aK-8hAtYIXYMT69bTUagHzGjgVJYggOPjbs2uNDp3NAinMtvzW9sigSEHLvqZ_KBAdCgGzC1sZrgjzfOqhPBxstt8=s0-d-e1-ft#http://i4.sdlcdn.com/img/eventImage/10/pattern.png"><table width="80%" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:562px">
            
              <tbody><tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="88" bgcolor="#FFFFFF"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                  
                    <tbody><tr>
                      <td height="3" bgcolor="#313131"></td>
                    </tr>
                    <tr>
                      <td valign="middle" height="88"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                        
                          <tbody><tr>
                            <td width="943" height="88" align="left"><a href="'.SITE_URL.'"><img src="'.SITE_URL.'images/logo.png" alt="My Calorie" title="My Calorie" width="120" height="80"></a></td>
                          </tr>
                        
                      </tbody></table></td>
                    </tr>
                    <tr>
                      <td height="1" bgcolor="#f2f2f2"></td>
                    </tr><tr>
                      <td style="font-family:Calibri;font-size:14px;color:#757575;font-weight:normal"><table width="92%" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:507px">
                        
                          <tbody><tr>
                            <td height="65" align="center" style="font-family:Calibri;font-size:21px;color:#000000;font-weight:normal"><img width="20" height="16" style="margin:0 10px 0 0" alt="" src="https://ci3.googleusercontent.com/proxy/j6EIsXuHmNiyiF6-OauXvKitHQsLqHK8xHElYayK65JH_4LobX83EKSSE5UypD8Vm5AeA-KCZ_y66aOCHejMIRqgzzD7CQTpkd0=s0-d-e1-ft#http://i3.sdlcdn.com/img/eventImage/10/tick-icon.jpg" class="CToWUd">Your order has been received,We will be deliver soon.</td>
                          </tr>
                          <tr>
                          	<td><table width="500" cellspacing="0" cellpadding="0" border="0" align="left">
                          	  <tbody>
                          	    <tr>
                          	      <td><strong>Hi '.$row_mailuser['b_firstname']."  ".$row_mailuser['b_lastname'].'</strong>,
                                  	<p><strong>Email:&nbsp;&nbsp;&nbsp;</strong>'.$row_mailuser['s_emailid'].'<br/><strong>Tel:&nbsp;&nbsp;&nbsp;</strong>'.$row_mailuser['s_mobileno'].'</p>
                          	        <p>your order no.  : <a style="color:#009aca">#'.$transaction_id.'</a> </p>
                                   
                                    </td>
                        	      </tr>
                        	    </tbody>
                        	  </table></td>
                          </tr>
                          <tr>
                            <td><table width="210" cellspacing="0" cellpadding="0" border="0" align="left" style="margin-left:10px">
                              
                              <tbody><tr>
                                    <td align="right"><table width="210" cellspacing="0" cellpadding="20" border="0" align="center">
                                      
                                        <tbody><tr>
                                          <td bgcolor="#f6f6f6" style="color:#545454"><strong>Billing address</strong><br>
                                            '.$row_mailuser['b_firstname']."  ".$row_mailuser['b_lastname']."<br>".$row_mailuser['b_address']."<br>".$row_mailuser['b_city']."-".$row_mailuser['b_zipcode'].'</td>
                                          </tr>
                                        
                                      </tbody></table></td>
                                    </tr>
                                  
                              </tbody></table>
                              <table width="210" cellspacing="0" cellpadding="20" border="0" align="center">
                                <tbody>
                                  <tr>
                                    <td bgcolor="#f6f6f6" style="color:#545454"><strong>Shipping address</strong><br />
                                     '.$row_mailuser['s_firstname']."  ".$row_mailuser['s_lastname']."<br>".$row_mailuser['s_address']."<br>". $row_mailuser['s_city']."-".$row_mailuser['s_zipcode']."<br>".$row_mailuser['landmark'].'</td>
                                  </tr>
                                </tbody>
                              </table></td>
                          </tr>
                        
                          <tr>
                            <td>&nbsp;
    </td>
                          </tr>
                          <tr>
                            <td><table width="100%" cellspacing="0" cellpadding="0" border="0">
                              
                                <tbody><tr>
                                  <td valign="bottom" height="20" style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal"><span style="font-family:Calibri;font-size:16px;color:#000000;font-weight:normal">PRODUCT(S)</span></td>
                                  </tr>
                                                                                          <tr>
                                                                                            <td style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal">&nbsp;</td>
                                                                                          </tr>
                                                                                          <tr>
                                    <td style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                                      
                                        <tbody><tr>
                                          <td width="109" valign="middle" height="10" align="center">&nbsp;</td>
                                          <td width="343">&nbsp;</td>
                                          <td width="98">&nbsp;</td>
                                          <td width="191">&nbsp;</td>
                                          <td width="141">&nbsp;</td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="2" background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg" align="center"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="29" align="center"><strong>Image</strong></td>
                                          <td><strong>Item Name </strong></td>
                                        
                                          <td align="center"><strong>Quantity</strong></td>
                                          <td><strong>Price</strong></td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="2" bgcolor="#898989" align="center"></td>
                                          <td bgcolor="#898989"></td>
                                          <td bgcolor="#898989"></td>
                                         <td bgcolor="#898989"></td>
                                          <td bgcolor="#898989"></td>
                                          </tr>';
										
$cart_subtotal2=0;
$sel_cart="select * from orders where invoice_id='".$invoiceids[$x]."'";
$res_cart2=mysql_query($sel_cart);
while($cart_row2=mysql_fetch_array($res_cart2))
{
 $sql_prodimg1="select * from  product_images  where product_id=".$cart_row2['prod_id']." order by prodimage_id ASC limit 0,1";
$res_prodimg1=mysql_query($sql_prodimg1);
$row_prodimg1=mysql_fetch_array($res_prodimg1);

 $sql_prod2="select * from  products  where product_id=".$cart_row2['prod_id'];
$res_prod2=mysql_query($sql_prod2);
$row_prod2=mysql_fetch_array($res_prod2);

if($row_prod2['sale_price']!="")
{
$price=$row_prod2['sale_price'];
}
else
{
$price=$row_prod2['regular_price'];
}
$subtotal=$price*$cart_row2['qty'];




$msg1.='<tr>
                                          <td width="109" valign="middle" align="center"><span style="font-size:15px"><img src="'.SITE_URL.'prod_images/'.$row_prodimg1['prodimage_original'].' " width="70" height="50" /></span></td>
                                          <td valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;'.trim(stripslashes($row_prod2['product_name'])).'</td>
                                          
                                          <td align="center" valign="middle">'.$cart_row2['qty'].'</td>
                                          <td valign="middle">Rs.'.number_format($subtotal, 2, '.', '').'</td>
                                          </tr>';

$k++;
$cart_subtotal2 +=$subtotal;
}

             $msg1 .='</tbody></table></td>
                                    </tr>
                                                              <tr>
                                  <td valign="middle" height="2" background="https://ci3.googleusercontent.com/proxy/CEjYmBqEpsn-nuUjuuz32EUN-gDZuTjb76clMxOzF7-aSx5zdzK5pRLIg0LeMeg23fWQX2fXR86zOJPGVJzFYjtyqr30D_4Qcw=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/bg-light.jpg" align="center"></td>
                                </tr>
                                
                              </tbody></table>
                              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                  
                                    <tbody><tr>
                                      <td style="padding:10px;color:#5d5d5d"><table width="251" cellspacing="0" cellpadding="3" border="0" align="right">
                                        
                                          <tbody><tr>
                                            <td width="170" align="right"><strong>Cart Subtotal :
                                              </strong></td>
                                            <td align="left">Rs.'.number_format($cart_subtotal2, 2, '.', '').'</td>
                                            </tr>';  
												$shipping="";
												if($shipping=="")
												{
												$ship='Free ';
												
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal2*$shipping)/100;
												$cart_subtotal=$cart_subtotal2+$grandtotal;
												}
$msg1.='<tr>
                                              <td align="right"><strong>Shipping :</strong></td>
                                              <td >'.$ship.' </td>
                                            </tr>
                                            
                                            <tr>
                                            <td width="170" align="right"><strong>Order Total : </strong></td>
                                            <td align="left"> Rs.'.number_format($cart_subtotal, 2, '.', '').' </td>
                                        </tr>                                   
                                                                                    
                                        </tbody></table>
                                      </td>
                                    </tr>
                                    
                                  
                              </tbody></table>
                                                                                                              
                                </td>
                          </tr>
                          
                          <tr>
                            <td height="1" bgcolor="#f3f3f3"></td>
                          </tr>
                          <tr>
                            <td height="80" align="center" style="font-family:Calibri;font-size:12px;color:#636363;font-weight:normal"><p>MR Calorie</p></td>
                          </tr>
                        
                      </tbody></table></td>
                    </tr>
                  
                </tbody></table></td>            
              </tr>          
              <tr>
                <td>&nbsp;</td>
              </tr>
    
              
            
          </tbody></table></td>
        </tr>
      
    </tbody></table>';
	//echo  $msg1;
		






 $to = $row_account['s_emailid'];
$user_name=$row_account['s_firstname']." ".$row_account['s_lastname'];
$files = array();

$head = array(
       'to'      =>array($to=>$user_name),
       'from'    =>array('panthangibabu@gmail.com' =>'MR Calorie'),
       'cc'    =>array('panthangibabu@gmail.com' =>'MR Calorie'),
       
       );
mail::send($head,$subject,$msg1, $files);
}// for
	// to delete  orders
		$db->beginTransaction();
		  $sql1="delete from orders where  invoice_id IN ($values)";
		$stmt1=$db->prepare($sql1);
		$stmt1->execute();
		
	// to delete  invoice
	
		 $sql2="delete from invoice where  invoice_id IN ($values)";
		$stmt2=$db->prepare($sql2);
		$stmt2->execute();
	
	$msg="selected record(s) are deleted";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
}
if($_POST['act']=='completedall')
{
	$values=implode(",",$_REQUEST['id']);	 
	try
	{
	 $invoiceids=$_REQUEST['id'];	 
 for($x=0;$x<count($invoiceids);$x++)
 {
 
 $sel_invoice="select * from invoice where invoice_id='".$invoiceids[$x]."'";
$res_invoice=mysql_query($sel_invoice);
$row_invoice=mysql_fetch_array($res_invoice);
 
 
   $sql_mailuser="select * from bill_ship_address where user_id='".$row_invoice['user_id']."'";
$res_mailuser=mysql_query($sql_mailuser);
$row_mailuser=mysql_fetch_array($res_mailuser);

$subject = 'Your Mr Colorie order completed on '.date('F, d Y') ;

// message
  $msg1 = '<table cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="max-width:730px!important;width:100%">
       
      
      
        <tbody><tr>
          <td width="30" bgcolor="#f3f3f3" background="https://ci6.googleusercontent.com/proxy/IkNIBG8aK-8hAtYIXYMT69bTUagHzGjgVJYggOPjbs2uNDp3NAinMtvzW9sigSEHLvqZ_KBAdCgGzC1sZrgjzfOqhPBxstt8=s0-d-e1-ft#http://i4.sdlcdn.com/img/eventImage/10/pattern.png"><table width="80%" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:562px">
            
              <tbody><tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="88" bgcolor="#FFFFFF"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                  
                    <tbody><tr>
                      <td height="3" bgcolor="#313131"></td>
                    </tr>
                    <tr>
                      <td valign="middle" height="88"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                        
                          <tbody><tr>
                            <td width="943" height="88" align="left"><a href="'.SITE_URL.'"><img src="'.SITE_URL.'images/logo.png" alt="My Calorie" title="My Calorie" width="120" height="80"></a></td>
                          </tr>
                        
                      </tbody></table></td>
                    </tr>
                    <tr>
                      <td height="1" bgcolor="#f2f2f2"></td>
                    </tr><tr>
                      <td style="font-family:Calibri;font-size:14px;color:#757575;font-weight:normal"><table width="92%" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:507px">
                        
                          <tbody><tr>
                            <td height="65" align="center" style="font-family:Calibri;font-size:21px;color:#000000;font-weight:normal"><img width="20" height="16" style="margin:0 10px 0 0" alt="" src="https://ci3.googleusercontent.com/proxy/j6EIsXuHmNiyiF6-OauXvKitHQsLqHK8xHElYayK65JH_4LobX83EKSSE5UypD8Vm5AeA-KCZ_y66aOCHejMIRqgzzD7CQTpkd0=s0-d-e1-ft#http://i3.sdlcdn.com/img/eventImage/10/tick-icon.jpg" class="CToWUd">Your order has been received,We will be deliver soon.</td>
                          </tr>
                          <tr>
                          	<td><table width="500" cellspacing="0" cellpadding="0" border="0" align="left">
                          	  <tbody>
                          	    <tr>
                          	      <td><strong>Hi '.$row_mailuser['b_firstname']."  ".$row_mailuser['b_lastname'].'</strong>,
                                  	<p><strong>Email:&nbsp;&nbsp;&nbsp;</strong>'.$row_mailuser['s_emailid'].'<br/><strong>Tel:&nbsp;&nbsp;&nbsp;</strong>'.$row_mailuser['s_mobileno'].'</p>
                          	        <p>your order no.  : <a style="color:#009aca">#'.$transaction_id.'</a> </p>
                                   
                                    </td>
                        	      </tr>
                        	    </tbody>
                        	  </table></td>
                          </tr>
                          <tr>
                            <td><table width="210" cellspacing="0" cellpadding="0" border="0" align="left" style="margin-left:10px">
                              
                              <tbody><tr>
                                    <td align="right"><table width="210" cellspacing="0" cellpadding="20" border="0" align="center">
                                      
                                        <tbody><tr>
                                          <td bgcolor="#f6f6f6" style="color:#545454"><strong>Billing address</strong><br>
                                            '.$row_mailuser['b_firstname']."  ".$row_mailuser['b_lastname']."<br>".$row_mailuser['b_address']."<br>".$row_mailuser['b_city']."-".$row_mailuser['b_zipcode'].'</td>
                                          </tr>
                                        
                                      </tbody></table></td>
                                    </tr>
                                  
                              </tbody></table>
                              <table width="210" cellspacing="0" cellpadding="20" border="0" align="center">
                                <tbody>
                                  <tr>
                                    <td bgcolor="#f6f6f6" style="color:#545454"><strong>Shipping address</strong><br />
                                     '.$row_mailuser['s_firstname']."  ".$row_mailuser['s_lastname']."<br>".$row_mailuser['s_address']."<br>". $row_mailuser['s_city']."-".$row_mailuser['s_zipcode']."<br>".$row_mailuser['landmark'].'</td>
                                  </tr>
                                </tbody>
                              </table></td>
                          </tr>
                        
                          <tr>
                            <td>&nbsp;
    </td>
                          </tr>
                          <tr>
                            <td><table width="100%" cellspacing="0" cellpadding="0" border="0">
                              
                                <tbody><tr>
                                  <td valign="bottom" height="20" style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal"><span style="font-family:Calibri;font-size:16px;color:#000000;font-weight:normal">PRODUCT(S)</span></td>
                                  </tr>
                                                                                          <tr>
                                                                                            <td style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal">&nbsp;</td>
                                                                                          </tr>
                                                                                          <tr>
                                    <td style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                                      
                                        <tbody><tr>
                                          <td width="109" valign="middle" height="10" align="center">&nbsp;</td>
                                          <td width="343">&nbsp;</td>
                                          <td width="98">&nbsp;</td>
                                          <td width="191">&nbsp;</td>
                                          <td width="141">&nbsp;</td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="2" background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg" align="center"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="29" align="center"><strong>Image</strong></td>
                                          <td><strong>Item Name </strong></td>
                                        
                                          <td align="center"><strong>Quantity</strong></td>
                                          <td><strong>Price</strong></td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="2" bgcolor="#898989" align="center"></td>
                                          <td bgcolor="#898989"></td>
                                          <td bgcolor="#898989"></td>
                                         <td bgcolor="#898989"></td>
                                          <td bgcolor="#898989"></td>
                                          </tr>';
										
$cart_subtotal2=0;
$sel_cart="select * from orders where invoice_id='".$invoiceids[$x]."'";
$res_cart2=mysql_query($sel_cart);
while($cart_row2=mysql_fetch_array($res_cart2))
{
 $sql_prodimg1="select * from  product_images  where product_id=".$cart_row2['prod_id']." order by prodimage_id ASC limit 0,1";
$res_prodimg1=mysql_query($sql_prodimg1);
$row_prodimg1=mysql_fetch_array($res_prodimg1);

 $sql_prod2="select * from  products  where product_id=".$cart_row2['prod_id'];
$res_prod2=mysql_query($sql_prod2);
$row_prod2=mysql_fetch_array($res_prod2);

if($row_prod2['sale_price']!="")
{
$price=$row_prod2['sale_price'];
}
else
{
$price=$row_prod2['regular_price'];
}
$subtotal=$price*$cart_row2['qty'];




$msg1.='<tr>
                                          <td width="109" valign="middle" align="center"><span style="font-size:15px"><img src="'.SITE_URL.'prod_images/'.$row_prodimg1['prodimage_original'].' " width="70" height="50" /></span></td>
                                          <td valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;'.trim(stripslashes($row_prod2['product_name'])).'</td>
                                          
                                          <td align="center" valign="middle">'.$cart_row2['qty'].'</td>
                                          <td valign="middle">Rs.'.number_format($subtotal, 2, '.', '').'</td>
                                          </tr>';

$k++;
$cart_subtotal2 +=$subtotal;
}

             $msg1 .='</tbody></table></td>
                                    </tr>
                                                              <tr>
                                  <td valign="middle" height="2" background="https://ci3.googleusercontent.com/proxy/CEjYmBqEpsn-nuUjuuz32EUN-gDZuTjb76clMxOzF7-aSx5zdzK5pRLIg0LeMeg23fWQX2fXR86zOJPGVJzFYjtyqr30D_4Qcw=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/bg-light.jpg" align="center"></td>
                                </tr>
                                
                              </tbody></table>
                              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                  
                                    <tbody><tr>
                                      <td style="padding:10px;color:#5d5d5d"><table width="251" cellspacing="0" cellpadding="3" border="0" align="right">
                                        
                                          <tbody><tr>
                                            <td width="170" align="right"><strong>Cart Subtotal :
                                              </strong></td>
                                            <td align="left">Rs.'.number_format($cart_subtotal2, 2, '.', '').'</td>
                                            </tr>';  
												$shipping="";
												if($shipping=="")
												{
												$ship='Free ';
												
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal2*$shipping)/100;
												$cart_subtotal=$cart_subtotal2+$grandtotal;
												}
$msg1.='<tr>
                                              <td align="right"><strong>Shipping :</strong></td>
                                              <td >'.$ship.' </td>
                                            </tr>
                                            
                                            <tr>
                                            <td width="170" align="right"><strong>Order Total : </strong></td>
                                            <td align="left"> Rs.'.number_format($cart_subtotal, 2, '.', '').' </td>
                                        </tr>                                   
                                                                                    
                                        </tbody></table>
                                      </td>
                                    </tr>
                                    
                                  
                              </tbody></table>
                                                                                                              
                                </td>
                          </tr>
                          
                          <tr>
                            <td height="1" bgcolor="#f3f3f3"></td>
                          </tr>
                          <tr>
                            <td height="80" align="center" style="font-family:Calibri;font-size:12px;color:#636363;font-weight:normal"><p>MR Calorie</p></td>
                          </tr>
                        
                      </tbody></table></td>
                    </tr>
                  
                </tbody></table></td>            
              </tr>          
              <tr>
                <td>&nbsp;</td>
              </tr>
    
              
            
          </tbody></table></td>
        </tr>
      
    </tbody></table>';
	//echo  $msg1;
		






 $to = $row_account['s_emailid'];
$user_name=$row_account['s_firstname']." ".$row_account['s_lastname'];
$files = array();

$head = array(
       'to'      =>array($to=>$user_name),
       'from'    =>array('pavankumarraju.n@gmail.com' =>'MR Calorie'),
       'cc'    =>array('pavankumarraju.n@gmail.com' =>'MR Calorie'),
       
       );
mail::send($head,$subject,$msg1, $files);
}// for
	// to delete  orders
		$db->beginTransaction();
		  $sql="update invoice set order_status=3,ordercomplete_date='".date('Y-m-d')."' , payment_status=2 where invoice_id IN ($values)";
		$stmt=$db->prepare($sql);
		$stmt->execute();
	$db->commit();
	$msg="selected record(s) are completed";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
}


if($_POST['act']=='cancelledall')
{
 $values=implode(",",$_REQUEST['id']);	 
 $stat=4;
	
	try
	{
		$db->beginTransaction();
		  $sql="update invoice set order_status=? where invoice_id IN ($values)";
		$stmt=$db->prepare($sql);
		$stmt->bindValue(1,$stat,PDO::PARAM_INT);
		$stmt->execute();
	$db->commit();
	$msg="selected record(s) are cancelled.";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
	
}
if($_POST['act']=='inprocessall')
{
 $values=implode(",",$_REQUEST['id']);	 
 $stat=2;
	
	try
	{
		$db->beginTransaction();
		  $sql="update invoice set order_status=? where invoice_id IN ($values)";
		$stmt=$db->prepare($sql);
		$stmt->bindValue(1,$stat,PDO::PARAM_INT);
		$stmt->execute();
	$db->commit();
	$msg="selected record(s) are In Process.";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
	
}

    $sql="select * from invoice where  invoice_id!=0";
  
  if($_POST['act']=='SEARCH')
{
	$schedule_dates=strip_tags(trim($_POST['schedule_dates']));
	if($schedule_dates!="")
	{
	$dexp=explode("-",$schedule_dates);
	$from_date=trim($dexp[2])."-".$dexp[1]."-".trim($dexp[0]);
	$to_date=trim($dexp[5])."-".$dexp[4]."-".trim($dexp[3]);
	$sql .=" and invoice_date between '".trim($from_date)."' and '".trim($to_date)."'";
	}
		if($_REQUEST['payment_method']!="")
	{
	$sql .=" and payment_method='".$_REQUEST['payment_method']."'";
	}
	if($_REQUEST['order_status']!="")
	{
	$sql .=" and order_status=".$_REQUEST['order_status'];
	}
	if($_REQUEST['payment_status']!="")
	{
	$sql .=" and payment_status=".$_REQUEST['payment_status'];
	}
	
}
 $sql .=" order by invoice_id DESC";
$res_invoice=mysql_query($sql);

   

?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
		<script language="javascript" type="text/javascript">
function validateedit()
{
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("To Edit , Please select respective check box");
		return false;
	}
	else if(cnt > 1)
	{
		alert("Please select only one checkbox");
		return false;
	}
	
	var idval=get_editval();
	
	document.frmedit.id.value=+idval;
	document.frmedit.submit();
}

function completed_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Activeate!");
		return false;
	}
	frm.act.value="completedall";
	frm.submit();
}
function inprocess_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to InActivate!");
		return false;
	}
	frm.act.value="inprocessall";
	frm.submit();
}
function failed_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Activeate!");
		return false;
	}
	frm.act.value="failedall";
	frm.submit();
}
function cancelled_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to InActivate!");
		return false;
	}
	frm.act.value="cancelledall";
	frm.submit();
}
function catdelete_all()
{
frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Delete!");
		return false;
	}
	else
	{
	var retVal = confirm("Do you want to continue ?");
   if( retVal == true )
   {
     // alert("User wants to continue!");
	  //return true;
	  frm.act.value="deleteall";
	frm.submit();
   }
   else   
   {
      //alert("User does not want to continue!");
	  return false;
   }
   	}
	
}


function get_checked()
{
	frm=document.pform;
		var i=0;
		k=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					k++;
				}
			}
		}
		return k;
}

function get_editval()
{
	frm=document.pform;
		var i=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					{
					var edit=frm.elements[i].value;
					}
				}
			}
		}
		return edit;
}
function catAll(e1) 
 {
	 frm=document.pform;
 // alert(frm.elements.length);
	j=0	
  for (var i=0;i<frm.elements.length;i++) 
   {
    if (frm.elements[i].name.substring(0,2)=='id') 
     {
	 j++
     frm.elements[i].checked=e1.checked?true:j==0?true:false;
     //alert(i); 
     }
   }
}  
</script>
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        All Orders
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Orders</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<FORM name="pform1" method="post" action="#">
       <input type="hidden" name="act" value="SEARCH" />
							<div class="col-md-12">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
								<div class="box-body">

                                    <div class="row">

                                        <div class="col-xs-2">
                                          Order Status
                                        </div>

                                        <div class="col-xs-2">
                                             <select class="form-control" name="order_status">
                                                <option value=""> -Select - </option>
												<option value="1" <?php if($_REQUEST['order_status']==1) echo 'selected'; ?>> NEW </option>
												<option value="2" <?php if($_REQUEST['order_status']==2) echo 'selected'; ?>>In Process </option>
												<option value="3" <?php if($_REQUEST['order_status']==3) echo 'selected'; ?>> Completed </option>
												<option value="3" <?php if($_REQUEST['order_status']==4) echo 'selected'; ?>> Cancelled </option>
                                            </select>

                                        </div>
										<div class="col-xs-2">
                                          Payment Status
                                        </div>

                                        <div class="col-xs-2">
                                             <select class="form-control" name="payment_status">
                                                <option value=""> -Select - </option>
												<option value="1" <?php if($_REQUEST['payment_status']==1) echo 'selected'; ?>> No Payment </option>
												<option value="2" <?php if($_REQUEST['payment_status']==2) echo 'selected'; ?>>Success </option>
												<option value="3" <?php if($_REQUEST['payment_status']==3) echo 'selected'; ?>> Failed </option>
												<option value="3" <?php if($_REQUEST['payment_status']==4) echo 'selected'; ?>> Refund </option>
                                            </select>

                                        </div>
										<div class="col-xs-2">
                                          Payment Method
                                        </div>

                                        <div class="col-xs-2">
                                             <select class="form-control" name="payment_method">
                                                <option value=""> -Select - </option>
												<option value="EBS" <?php if($_REQUEST['payment_method']=='EBS') echo 'selected'; ?>> EBS </option>
												<option value="COD" <?php if($_REQUEST['payment_method']=='COD') echo 'selected'; ?>>COD</option>
												
                                            </select>

                                        </div>

                                    </div>

									</div>
                                <div class="box-body">
                                    <div class="row">
									 <div class="col-xs-2">
                                       Order Dates          </div>
                                        <div class="col-xs-8"><div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" id="reservation" name="schedule_dates" value="<?php echo $_POST['schedule_dates'];?>"/>
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
                                        </div>
                                         
										<div class="col-xs-2"> <button type="submit" name="button1id" class="btn btn-primary">Search </button>
                                    </div>
                                </div><!-- /.box-body -->
								 
								
                                </div>
								 
								  
                            </div><!-- /.box -->

                        </div>
						</FORM>

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
						
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									 <div class="con-rt-head"><strong><font color="#000000">For Orders</font> </strong><a href="#" onClick="return completed_all()"class="btn btn-xs btn-primary"  ><span class="glyphicon glyphicon-ok"></span> Completed</a>&nbsp;<a href="#" onClick="return inprocess_all()" class="btn btn-xs btn-info" > <i class="glyphicon glyphicon-ok"></i> In Process</a>	
				&nbsp;<a href="#" onClick="return cancelled_all()" class="btn btn-xs btn-warning" > <i class="glyphicon glyphicon-trash"></i> Cancelled</a>	
		<a href="#" onClick="return catdelete_all()" class="btn btn-xs btn-danger" > <i class="glyphicon glyphicon-trash"></i> Delete</a>	</div>
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
										    <th>Slno </th>
										   <th>Ord /Txn ID </th>
						<th> Full Name </th>
						<th> Order  Date </th>
						
						<th> Amount </th>
						<th>Pay Status</th>
						<th>Pay Method</th>			
						<th><INPUT type="checkbox" onClick="return catAll(this)" class="icheckbox_minimal"  id="checkall" name="checkall">&nbsp;
                        <i class="glyphicon glyphicon-check"></i></th>
						<td>View</td>
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					$sl=1; 
			  while($row= mysql_fetch_array($res_invoice))
			  {
				  extract($row);
				 $sql3="select * from bill_ship_address  where user_id=".$user_id;
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
	  
				  
				   
		$sql_orders="select * from orders where invoice_id=".$invoice_id;
$res_orders=mysql_query($sql_orders);
$items=mysql_num_rows($res_orders);		  
	
	 $sql_paystat="select * from  payment_status  where id=".$payment_status;
$res_paystat=mysql_query($sql_paystat);
$row_paystat=mysql_fetch_array($res_paystat);
	
	$sql_ord="select * from  order_status  where id=".$order_status;
	$res_ord=mysql_query($sql_ord);
$row_ordstat=mysql_fetch_array($res_ord);
	 ?>
	
					<tr>
                  
						<td><?php echo $sl;?></td>
						<td>#<?php echo $invoice_id;?><br>
						#<?php echo $transaction_id;?></td>
						<td><?php echo $row3['s_firstname']." ".$row3['s_lastname'];?></td>
						<td><?php echo date("jS F, Y", strtotime($invoice_date)); ?></td>
						
						<td><?php echo number_format($total_amount, 2, '.', '');?></span> for <?php echo $items;?> item(s)</td>					
						<td><?php echo $row_paystat['name'];?><br><?php echo $payment_method;?></td>
						<td><?php echo $row_ordstat['name'];?></td>
  <td > <input name="id[]" type="checkbox"  class="icheckbox_minimal"  value="<?php echo $invoice_id; ?>" /></td>
  <td><a href="order_details.php?id=<?php echo $invoice_id; ?>"  class="btn btn-xs btn-primary" target="_blank"> <i class="glyphicon glyphicon-eye-open"></i> Invoice</a></td>
					</tr>
				<?php
				$sl++;
			  }  
			  ?>
                                        </tbody>
                                    </table>
									</FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2,3,4,5,6,7,8] },{'bSortable': false, 'aTargets': [0, 7,8 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 50
    
 
} );
 } );

    
</script> 
  <script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
       
        <script type="text/javascript">
            $(function() {
			
			 //Date range picker
                $('#reservation').daterangepicker({format: 'DD-MM-YYYY'});
        
     
            });
        </script>
    </body>
</html>
