<?php 
include("../config/db_connection.php");
include("../config/constants.php");
include("includes/functions.php");
include("includes/loginsession_onlylogin.php");
$vRoles=view_roles();
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
				    <script type="text/javascript" src="validations/subusers.js"></script>

    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
           <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Office Staff
                       <small><?php
if($_REQUEST['act']=='UPDATE')
{ ?> Update <?php } else { ?> Add New <?php } ?> </small>
                    </h1><span id="resultdiv"></span>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="subusers.php">Office Staff List</a></li>
                       <!--<li class="active">Roles</li>-->
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<?php
if($_REQUEST['act']=='UPDATE')
{
$v=view_subuser($_REQUEST['id']);

}
?>
				<form name="frm" method="post">
				<input type="hidden" name="act" id="act" value="<?php echo $_REQUEST['act'] ; ?>" />
            <input type="hidden" name="id"  id="id" value="<?php echo $_REQUEST['id'] ; ?>" />
			
                    <div class="row">
                       
                        <div class="col-md-8">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Different Width</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Role                                       </div>
                                        <div class="col-xs-6">
            <select class="form-control" name="role_id" id="role_id">
                    <option value=""> - Select - </option>
                                              
				 <?php
				foreach($vRoles as $val)
				{
				?>
                 <option value="<?php echo $val['role_id'];?>" <?php if($v[0]['role_id']==$val['role_id']) echo 'selected';?>> <?php echo $val['role_name'];?></option>
                <?php
				}
				?>
                                            </select>                            </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								
								   <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          User Name                                        </div>
                                        <div class="col-xs-6">
             <input type="text" class="form-control" name="user_name" id="user_name" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['user_name']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div>
								
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          Password                                        </div>
                                        <div class="col-xs-6">
             <input type="text" class="form-control" name="pwd" id="pwd" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['pwd']); ?>" required>
                                        </div>
                                     
                                    </div>
                                </div>
								
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                         Email Id                                        </div>
                                        <div class="col-xs-6">
             <input type="text" class="form-control" name="user_email" id="user_email" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['user_email']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          Mobileno                                        </div>
                                        <div class="col-xs-6">
             <input type="text" class="form-control" name="mobileno" id="mobileno" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['mobileno']); ?>" required>
                                        </div>
                                        <div class="col-xs-2">
                                         
										   <?php if($_REQUEST['act']!='UPDATE'){ ?>
                        <button id="sbtbtn" name="button1id" class="btn btn-primary">Add </button>
					   <?php 
					   }
					   else
					   {
					   ?>
					   <button id="sbtbtn" name="button1id" class="btn btn-primary">Update</button>

					   <?php
					   }
					   ?>
                                        </div>
                                    </div>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                       
                    </div>   <!-- /.row -->
					</form>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        
    </body>
</html>
