<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");



try {
    $db->beginTransaction();
	$sql="select * from roles  order by  role_id ASC";		
	$stmt=$db->prepare($sql);	
	$stmt->execute();
	$norows=$stmt->rowCount();
    $db->commit();
} 
catch(PDOException $ex)
{
    //Something went wrong rollback!
    $db->rollBack();
    writeLog($ex->getMessage().'\n'); 
	writeLog($ex->getLine().'\n'); 
}
?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
		
		
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        All Role Permission Pages
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Role Permission</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									 
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
						<th> Role </th>
						<th> Pages </th>
						<th>Action</th>		
						
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					 
			  while($row= $stmt->fetch(PDO::FETCH_ASSOC))
			  {
				
				  extract($row);
				  
	
	 $sql2="select * from page_permissions  where role_id=".$role_id;		
	$stmt2=$db->prepare($sql2);	
	$stmt2->execute();
	  $k=0;
	 $p=0;
	while($row2= $stmt2->fetch(PDO::FETCH_ASSOC))
	{
	$arr[$k]=$row2['page_id'];
	$k++;
	}
	if(count($arr)>1)
	{
	$imp=implode(",",$arr);
	}
	else
	{
		$imp=0;
	}
	 $sql3="select * from site_pages  where page_id in(".$imp.")";		
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	while($row3= $stmt3->fetch(PDO::FETCH_ASSOC))
	{
	$arr1[$p]=$row3['page_title'];	
	$p++;
	}
	if(count($arr1)>1)
	{
	$imp1=implode(" ,  ",$arr1);
	}
	else
	{
		$imp1="";
	}
	
	 ?>
				
								<tr>
                  
						<td><?php echo $role_name;?></td>
						<td><?php echo $imp1 ?></td>  
<td>

<a href="edit_userpermissions.php?role_id=<?php echo $role_id; ?>" class="btn btn-xs btn-primary">
    Edit</a></td> 
					</tr>
				<?php
				unset($arr);
				unset($arr1);

			  }  
			  ?>
                                        </tbody>
                                    </table>
									</FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2] },{'bSortable': false, 'aTargets': [ 2 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 25
    
 
} );
 } );

    
</script> 

    </body>
</html>
