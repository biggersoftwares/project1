<?php 
include("../config/db_connection.php");
include("../config/constants.php");
include("includes/functions.php");
include("includes/loginsession_loginonly.php");

$msg="";
$product_id=$_REQUEST['id'];

if($_POST['act']=='UPDATE')
{
$product_id=$_REQUEST['id'];
$maincat_id=addslashes(strip_tags(trim($_POST['maincat_id'])));

$food_type=addslashes(strip_tags(trim($_POST['food_type'])));
$product_name=addslashes(strip_tags(trim($_POST['product_name'])));
$calories=addslashes(trim($_POST['calories']));
$fat=addslashes(trim($_POST['fat']));
$proteins=addslashes(trim($_POST['proteins']));
$sugar=addslashes(trim($_POST['sugar']));
$regular_price=strip_tags(trim($_POST['small_regular_price']));
$sale_price=strip_tags(trim($_POST['small_sale_price']));
$regular_price1=strip_tags(trim($_POST['medium_regular_price']));
$sale_price1=strip_tags(trim($_POST['medium_sale_price']));
$regular_price2=strip_tags(trim($_POST['large_regular_price']));
$sale_price2=strip_tags(trim($_POST['large_sale_price']));


     $upd1="update products set
                    product_name='".$product_name."',
                    maincat_id='".$maincat_id."',
                    food_type='".$food_type."',
                    calories='".$calories."',
                    fat='".$fat."',
                    proteins='".$proteins."',
                    sugar='".trim($sugar)."',
                    regular_price='".trim($regular_price)."',
                    sale_price='".trim($sale_price)."'
            where product_id=".$product_id;
		$res1=mysql_query($upd1);
                $price_data = array();
                if($regular_price != "") {
                    $price_data[0]['product_size_id'] = 1;
                    $price_data[0]['regular_price'] = $regular_price;
                    $price_data[0]['sale_price'] = $sale_price;
                }
                if($regular_price1 != "") {
                    $price_data[1]['product_size_id'] = 2;
                    $price_data[1]['regular_price'] = $regular_price1;
                    $price_data[1]['sale_price'] = $sale_price1;
                }
                if($regular_price2 != "") {
                    $price_data[2]['product_size_id'] = 3;
                    $price_data[2]['regular_price'] = $regular_price2;
                    $price_data[2]['sale_price'] = $sale_price2;
                }
                $price_data = array_values($price_data);
                $sql = "delete from product_prices where product_id = '$product_id'";
                mysql_query($sql);
                   for($i=0;$i<count($price_data);$i++) { 
                        $product_size_id = $price_data[$i]['product_size_id'];
                        $regular_price1 = $price_data[$i]['regular_price'];
                        $sale_price1 = $price_data[$i]['sale_price'];
                        $ins1="insert into product_prices ( 
                                    product_id,
                                    product_size_id,
                                    regular_price,
                                    sale_price
                            )	
                            values
                            (
                                    '".$product_id."',
                                    '".$product_size_id."',
                                    '".$regular_price1."',
                                    '".$sale_price1."'
                            )";
                        mysql_query($ins1);
                   }

// ******************** Product description ********************

$product_desc=addslashes(trim($_POST['product_desc']));

$sql_desc="select * from product_desc where product_id=".$product_id;
$res_desc=mysql_query($sql_desc);
if(mysql_num_rows($res_desc)==0)
{


 $ins2="insert into product_desc ( 
									product_id,
									prod_desc
								)	
								values
								
								(
									'".$product_id."',
									'".$product_desc."'
								)";
		$res2=mysql_query($ins2);
		}
		else
		{
 		 $upd2="update product_desc set
									
									prod_desc='".$product_desc."'
								where product_id=".$product_id;
		mysql_query($upd2);
}

//   *******************************  Product Images *****************************


for($k=0;$k<count($_FILES['file']['name']);$k++)
{

    
 	// some information about image we need later.
$ImageName 		= $_FILES["file"]["name"][$k];
$ImageSize 		= $_FILES["file"]["size"][$k];
$TempSrc	 	= $_FILES["file"]["tmp_name"][$k];
$ImageType	 	= $_FILES["file"]["type"][$k];


if ($ImageName) 
{
	

				//  ****************************************  Start Original Image  ******************************************
	//  To uploadd  ORIGINAL IMAGE
	
		///////////////////////////////////////////////////////////////////////////
		 $imgname="../prod_images/".$product_id."_".rand(10, 99)."_".$_FILES["file"]["name"][$k]; // the path with the file name where the file will be stored, upload is the directory name. 
	//echo $_FILES['fleImage']['type'];
	if (!($_FILES["file"]["type"] [$k]=="image/jpeg" OR $_FILES["file"]["type"][$k]=="image/gif" 
	 OR $_FILES["file"]["type"][$k]=="image/jpg" OR $_FILES["file"]["type"][$k]=="image/png" OR $_FILES["file"]["type"][$k]=="image/pjpeg"))
	{
		echo "Your uploaded file must be of JPG or GIF or PNG. Other file types are not allowed<BR>";
		exit;
	}//if
	else
	{
			if(move_uploaded_file ($_FILES["file"]["tmp_name"][$k],$imgname))
			{
				
				$original_image=basename($imgname);
				//echo "Successfully uploaded the Image";
				chmod("$imgname",0777);
			}
			else
			{
				echo "Failed to upload file Contact Site admin to fix the problem";
				exit;
			}
	}//else
	

	
	//  ****************************************  END OF Original Image  ******************************************
	$upload_image=$NewImageName;
	
	 $ins6="insert into product_images ( 
										product_id,
										prodimage_original
									)	
									values
									
									(
										'".$product_id."',
										'".$original_image."'
									)";
			$res5=mysql_query($ins6);
	
		
}// if

}
if($res1)
{
header("Location:products.php");
}
}
$v=view_product($_REQUEST['id']);
$vd=view_product_desc($_REQUEST['id']);
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
                   <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
   <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
   

  <script language="javascript">
	$( document ).ready(function() {

$("#sbtbtn").click(function(){
	if($("#product_name").val()=="")
	{
		$("#product_name").css({"border": "1px solid","color":"#F00"});
		return false;
	}
        if($("#small_regular_price").val()=="" && $("#medium_regular_price").val()=="" && $("#large_regular_price").val()=="")
	{
		$("#small_regular_price").css({"border": "1px solid","color":"#F00"});
		return false;
	}




$("#act").val('UPDATE');
$("#frm").submit();
});
});
	</script>	
		<script type="text/javascript"> 
$(document).ready(function() { 
//elements
var progressbox 		= $('#progressbox'); //progress bar wrapper
var progressbar 		= $('#progressbar'); //progress bar element
var statustxt 			= $('#statustxt'); //status text element
var submitbutton 		= $("#SubmitButton"); //submit button
var myform 				= $("#UploadForm"); //upload form
var output 				= $("#output"); //ajax result output element
var completed 			= '0%'; //initial progressbar value
var FileInputsHolder 	= $('#AddFileInputBox'); //Element where additional file inputs are appended
var MaxFileInputs		= 10; //Maximum number of file input boxs

// adding and removing file input box
var i = $("#AddFileInputBox div").size() + 1;
$("#AddMoreFileBox").click(function () {
		//event.returnValue = false;
		if(i < MaxFileInputs)
		{
			
			$('<br/><span><input type="file" style="float:left; width:52% " id="fileInputBox" size="20" name="file[]" class="addedInput" value=""/>&nbsp;&nbsp;<a href="#" style="float:left" class="removeclass small2"><img src="images/delete.gif"  border="0" />&nbsp;Remove</a></span>').appendTo(FileInputsHolder);
			i++;
		}
		return false;
});

$("body").on("click",".removeclass", function(e){
		//event.returnValue = false;
		if( i > 1 ) {
				$(this).parents('span').remove();i--;
		}
		
}); 

$("#ShowForm").click(function () {
  $("#uploaderform").slideToggle(); //Slide Toggle upload form on click
});
	


}); 
</script> 

<script language="javascript" type="text/javascript">
    function checkNumber(textBox)

{

	while (textBox.value.length > 0 && isNaN(textBox.value)) {

		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	}

	

	textBox.value = textBox.value;

/*	if (textBox.value.length == 0) {

		textBox.value = 0;		

	} else {

		textBox.value = parseInt(textBox.value);

	}*/

}
	


</script>
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
           <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Product
                       <small>Update </small>
                    </h1><?php if($msg!="") { echo $msg; } ?>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="products.php">View All Products</a></li>
                       <!--<li class="active">Roles</li>-->
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				
				<form name="frm" method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'];?>">
				<input type="hidden" name="act" id="act" value="" />
            <input type="hidden" name="id"  id="id" value="<?php echo $_REQUEST['id'] ; ?>" />
			
                 <div class="row">
                        <div class="col-md-8">

                            <div class="box box-info">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
								
									<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Shop Name <font color="#FE5E0A">*</font>                                        </div>
                                        <div class="col-xs-3">
										  <select class="form-control" name="maincat_id">
			<option value=""> Select </option>
			<?php
$sql1="select * from  maincategory  where status=1 order by maincat_name ASC";
$res1=mysql_query($sql1);
while($row1=mysql_fetch_array($res1))
{

?>	
	<option value="<?php echo $row1['maincat_id'];?>" <?php if($row1['maincat_id']==$v[0]['maincat_id']) echo 'selected';?>><?php echo $row1['maincat_name'];?></option>
                                             <?php
											 }
											 ?>
                                                
                                            </select>
            
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								
								
								  <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Brand Name                                         </div>
                                        <div class="col-xs-3">
              <select class="form-control" name="food_type" id="food_type">
											
				<option value="1"  <?php if($v[0]['food_type']==1) echo 'selected';?>>Veg</option>
				<option value="2" <?php if($v[0]['food_type']==2) echo 'selected';?>>Non Veg</option>
				
											</select>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Product Name <font color="#FE5E0A">*</font>                                        </div>
                                        <div class="col-xs-9">
             <input type="text" class="form-control" name="product_name" id="product_name" value="<?php  echo stripslashes($v[0]['product_name']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								 
								   <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Regular Price <font color="#FE5E0A">*</font>                                      </div>
                                        <div class="col-xs-3"> 
                                            <?php 
                                            $prices = $v[0]['prices'];
                                            for($i=0;$i<count($prices);$i++) {
                                                if($prices[$i]['product_size_id'] == '1') {
                                                    $regular_price1 = $prices[$i]['regular_price'];
                                                    $sales_price1 = $prices[$i]['sale_price'];
                                                }
                                                if($prices[$i]['product_size_id'] == '2') {
                                                    $regular_price2 = $prices[$i]['regular_price'];
                                                    $sales_price2 = $prices[$i]['sale_price'];
                                                }
                                                if($prices[$i]['product_size_id'] == '3') {
                                                    $regular_price3 = $prices[$i]['regular_price'];
                                                    $sales_price3 = $prices[$i]['sale_price'];
                                                }
                                            }
                                            ?>
                                            <table width="100%">
                                                <tr>
                                                    <td>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control"  name="small_regular_price" id="small_regular_price" style="width:75px;" placeholder="Small" value="<?php echo stripslashes($regular_price1); ?>" onKeyUp="checkNumber(this);" required>
                                                            <span class="input-group-addon">.00</span>
                                                        </div> 
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control"  name="medium_regular_price" id="medium_regular_price" style="width:75px;" placeholder="Medium" value="<?php echo stripslashes($regular_price2); ?>" onKeyUp="checkNumber(this);" required>
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control"  name="large_regular_price" id="large_regular_price" style="width:75px;" placeholder="Large" value="<?php echo stripslashes($regular_price3); ?>" onKeyUp="checkNumber(this);" required>
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								   <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Sale Price                                        </div>
                                        <div class="col-xs-3">
            <table width="100%">
                                                <tr>
                                                    <td>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control" style="width:75px;" placeholder="Small"  name="small_sale_price" id="small_sale_price" value="<?php echo stripslashes($sales_price1); ?>" onKeyUp="checkNumber(this);">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control" style="width:75px;" placeholder="Medium"  name="medium_sale_price" id="medium_sale_price" value="<?php echo stripslashes($sales_price2); ?>" onKeyUp="checkNumber(this);">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 5px;">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-inr"></i></span>
                                                            <input type="text" class="form-control" style="width:75px;" placeholder="Large"  name="large_sale_price" id="large_sale_price" value="<?php echo stripslashes($sales_price3); ?>" onKeyUp="checkNumber(this);">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          Calories                                        </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="calories" id="calories" value="<?php echo stripslashes($v[0]['calories']); ?>">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                           Fat                                   </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="fat" id="fat" value="<?php echo stripslashes($v[0]['fat']); ?>">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                         Proteins                                      </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="proteins" id="proteins" value="<?php echo stripslashes($v[0]['proteins']); ?>">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                         Sugar                                      </div>
                                        <div class="col-xs-3">
           
                                        <input type="text" class="form-control"  name="sugar" id="sugar" value="<?php echo stripslashes($v[0]['sugar']); ?>">
                                        
                               
                                        </div>
                                        
                                    </div>
                                </div>
								
								 	  <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-12"><div class="form-group">
                                        <label><a href="#" id="AddMoreFileBox">Add More Product  Images</a>  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<a href="prod_images.php?pid=<?php echo $product_id;?>" target="_blank"> <font color="#FE5E0A">View Images</font></a></label><strong><font color="#0000FF">(  Sizes width= 400 to 5000px  and height= 300 to 400px )</font></strong>
                                       <div id="AddFileInputBox">
                                        <div class="col-xs-6">
                                        <input id="fileInputBox" style="margin-bottom: 5px;" type="file"  name="file[]"/>
                                        </div>
                                        <div class="imagePreview col-xs-6">
                                        
                                        </div>
                                        </div>
    <div class="sep_s"></div>
                                    </div>
                                        </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								
								
								 
								  <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-12">
								    <div class='box box-info'>
								       <div class='box-header'>
                                    <h3 class='box-title'>Product  Description</h3>
                                    <!-- tools box -->
                                    <div class="pull-right box-tools">
                                        <button class="btn btn-info btn-sm" data-widget='collapse' data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                                        <button class="btn btn-info btn-sm" data-widget='remove' data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                                    </div><!-- /. tools -->
                                </div><!-- /.box-header -->
                                <div class='box-body pad'>
                                    
                                        <textarea class="textarea"  name="product_desc"  id="product_desc" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo stripslashes($vd[0]['prod_desc']); ?></textarea>
                                    
                                </div>
								  
								  </div></div></div></div>
                            </div><!-- /.box -->

                        </div><!-- /.col (left) -->
                       
                    </div>
					
										<div class='row'>
                        <div class='col-md-12'>
                          
<div class="box-body">
                                    <div class="row">
									<div class="col-xs-7">&nbsp;</div>
                                        <div class="col-xs-2">
                                      
										  
					   <button id="sbtbtn" name="button1id" class="btn btn-primary">Update Product</button>
                                        </div>
                                        
                                    </div>
                                </div>
                             
                        </div><!-- /.col-->
                    </div>
</form>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        
      
        <!-- Bootstrap WYSIHTML5 -->
        <script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
	
           <script src="js/userjs/imageload.js"></script>

       

    </body>
</html>
