<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("includes/loginsession.php");

  $sql="select * from invoice where  order_status=1";
  
  if($_POST['act']=='SEARCH')
{
	$schedule_dates=strip_tags(trim($_POST['schedule_dates']));
	if($schedule_dates!="")
	{
	$dexp=explode("-",$schedule_dates);
	$from_date=trim($dexp[2])."-".$dexp[1]."-".trim($dexp[0]);
	$to_date=trim($dexp[5])."-".$dexp[4]."-".trim($dexp[3]);
	$sql .=" and invoice_date between '".trim($from_date)."' and '".trim($to_date)."'";
	}
	
	
}
 $sql .=" order by invoice_id DESC";
$res_invoice=mysql_query($sql);


  
   

?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
	 <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />	
		
		<script language="javascript" type="text/javascript">

function printlable_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Activeate!");
		return false;
	}
	frm.act.value="printlableall";
	frm.submit();
}


function get_checked()
{
	frm=document.pform;
		var i=0;
		k=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					k++;
				}
			}
		}
		return k;
}

function get_editval()
{
	frm=document.pform;
		var i=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					{
					var edit=frm.elements[i].value;
					}
				}
			}
		}
		return edit;
}
function catAll(e1) 
 {
	 frm=document.pform;
 // alert(frm.elements.length);
	j=0	
  for (var i=0;i<frm.elements.length;i++) 
   {
    if (frm.elements[i].name.substring(0,2)=='id') 
     {
	 j++
     frm.elements[i].checked=e1.checked?true:j==0?true:false;
     //alert(i); 
     }
   }
}  
</script>
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        All New Orders
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Orders</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
<FORM name="pform1" method="post" action="#">
       <input type="hidden" name="act" value="SEARCH" />
							<div class="col-md-12">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
									 <div class="col-xs-2">
                                       Order Dates          </div>
                                        <div class="col-xs-8"><div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" id="reservation" name="schedule_dates" value="<?php echo $_POST['schedule_dates'];?>"/>
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
                                        </div>
                                         
										<div class="col-xs-2"> <button type="submit" name="button1id" class="btn btn-primary">Search </button>
                                    </div>
                                </div><!-- /.box-body -->
								 
								
                                </div>
								 
								  
                            </div><!-- /.box -->

                        </div>
						</FORM>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
							
                                <!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
										    <th>Slno </th>
										   <th>Invoice /Txn ID </th>
						<th> Full Name </th>
						<th> Order  Date </th>
						<th>Product Details</th>
						<th>Payment</th>
						
						<th> Order Status</th>
							
						
						<td>View</td>		
						
						
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					$sl=1; 
		 
			  while($row= mysql_fetch_array($res_invoice))
			  {
				  extract($row);
				 $sql3="select * from bill_ship_address  where user_id=".$user_id;
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
	  
				  
				   
		$sql_orders="select * from orders where invoice_id=".$invoice_id;
$res_orders=mysql_query($sql_orders);
$items=mysql_num_rows($res_orders);		  
	
	 $sql_paystat="select * from  payment_status  where id=".$payment_status;
$res_paystat=mysql_query($sql_paystat);
$row_paystat=mysql_fetch_array($res_paystat);

	$sql_ord="select * from  order_status  where id=".$order_status;
	$res_ord=mysql_query($sql_ord);
$row_ordstat=mysql_fetch_array($res_ord);
	
	 ?>
	
					<tr>
                  
						<td><?php echo $sl;?></td>
						<td>#<?php echo $invoice_id;?><br>
						#<?php echo $transaction_id;?></td>
						<td><?php echo $row3['s_firstname']." ".$row3['s_lastname'];?></td>
						<td><?php echo date("jS F, Y", strtotime($invoice_date)); ?></td>
						
						<td><?php echo number_format($total_amount, 2, '.', '');?></span> for <?php echo $items;?> item(s)</td>					
						<td><?php echo $row_paystat['name'];?><br><?php echo $payment_method;?></td>
						<td><?php echo $row_ordstat['name'];?></td>
  <td><a href="order_details.php?id=<?php echo $invoice_id; ?>"  class="btn btn-xs btn-primary" target="_blank"> <i class="glyphicon glyphicon-eye-open"></i> Invoice</a></td>
					</tr>
				<?php
				$sl++;
			  }  
			  ?>
                                        </tbody>
                                    </table>
									</FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2,3,4,5,6] },{'bSortable': false, 'aTargets': [ 0,4,5,6,7] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 50
    
 
} );
 } );

    
</script> 

        <script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
       
        <script type="text/javascript">
            $(function() {
			
			 //Date range picker
                $('#reservation').daterangepicker({format: 'DD-MM-YYYY'});
        
     
            });
        </script>
    </body>
</html>
