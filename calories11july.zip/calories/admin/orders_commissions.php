<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");

  $sql="select * from orders where  order_status=3";
  
  if($_POST['act']=='SEARCH')
{
	$schedule_dates=strip_tags(trim($_POST['schedule_dates']));
	if($schedule_dates!="")
	{
	$dexp=explode("-",$schedule_dates);
	$from_date=trim($dexp[2])."-".$dexp[1]."-".trim($dexp[0]);
	$to_date=trim($dexp[5])."-".$dexp[4]."-".trim($dexp[3]);
	$sql .=" and order_date between '".trim($from_date)."' and '".trim($to_date)."'";
	}
	
	if($_POST['shop_id']!="")
	{
	$sql .=" and  shop_id=".$_POST['shop_id'];
	}
}
$sql .=" order by order_id DESC";
$res_orders=mysql_query($sql);


  
   

?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
	 <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />	
		
		<script language="javascript" type="text/javascript">

function printlable_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Activeate!");
		return false;
	}
	frm.act.value="printlableall";
	frm.submit();
}


function get_checked()
{
	frm=document.pform;
		var i=0;
		k=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					k++;
				}
			}
		}
		return k;
}

function get_editval()
{
	frm=document.pform;
		var i=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					{
					var edit=frm.elements[i].value;
					}
				}
			}
		}
		return edit;
}
function catAll(e1) 
 {
	 frm=document.pform;
 // alert(frm.elements.length);
	j=0	
  for (var i=0;i<frm.elements.length;i++) 
   {
    if (frm.elements[i].name.substring(0,2)=='id') 
     {
	 j++
     frm.elements[i].checked=e1.checked?true:j==0?true:false;
     //alert(i); 
     }
   }
}  
</script>
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Orders Commissions
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Orders Commissions</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
<FORM name="pform1" method="post" action="#">
       <input type="hidden" name="act" value="SEARCH" />
							<div class="col-md-12">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
									 <div class="col-xs-2">
                                       Order Dates          </div>
                                        <div class="col-xs-8"><div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" id="reservation" name="schedule_dates" value="<?php echo $_POST['schedule_dates'];?>"/>
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
                                        </div>
                                         
										
                                    </div>
                                </div><!-- /.box-body -->
								 
								<div class="box-body">
                                    <div class="row">
									 <div class="col-xs-2">
                                       Shops          </div>
                                        <div class="col-xs-6">
										<select name="shop_id" class="form-control">
										<option value="">Select Shop </option>
										<?php
										$sql="select * from shops where status=1";
										$res=mysql_query($sql);
										while($row=mysql_fetch_array($res))
										{
										?>
										<option value="<?php echo $row['shop_id'];?>" <?php if($row['shop_id']==$_POST['shop_id']) echo 'selected';?>><?php echo $row['shop_name'];?> - <?php echo $row['tin_no'];?> </option>
										<?php
										}
										?>
										</select>
                                        </div>
                                         <div class="col-xs-2"> <button type="submit" name="button1id" class="btn btn-primary">Search </button>
                                                  </div>
										
                                    </div>
                                </div>
								 
								  
                            </div><!-- /.box -->

                        </div>
						</FORM>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
							
                                <!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
										    <th>Slno </th>
											
										   <th>InvoiceID </th>
						
						<th>Product Details</th>
						<th>Commissions</th>
						<th>Total</th>
								
						
						
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					$sl=1; 
					$totalamount=0;
			  while($row_orders= mysql_fetch_array($res_orders))
			  {
				  
		 $sql="select * from invoice where invoice_id=".$row_orders['invoice_id'];
	    $stmt=mysql_query($sql);
	    $inv_row=mysql_fetch_array($stmt);
	
				  $sql3="select * from bill_ship_address  where user_id=".$row_orders['user_id'];
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
				  
	
	
	    $sql2="select * from state  where state_id=".$row3['s_state'];
	$stmt2=$db->prepare($sql2);	
	$stmt2->execute();
	$row2= $stmt2->fetch(PDO::FETCH_ASSOC);
				  
		 $sql_prod1="select * from  products  where product_id=".$row_orders['prod_id'];
$res_prod1=mysql_query($sql_prod1);
$row_prod1=mysql_fetch_array($res_prod1);		   
		  
	 $sql_prodimg="select * from  product_images  where product_id=".$row_prod1['product_id']." order by prodimage_id ASC limit 0,1";
$res_prodimg=mysql_query($sql_prodimg);
$row_prodimg=mysql_fetch_array($res_prodimg);

  $sql_shop="select * from  shops  where shop_id=".$row_orders['shop_id'];
$res_shop=mysql_query($sql_shop);
$row_shop=mysql_fetch_array($res_shop);
	
	
	$sql_ord="select * from  order_status  where id=".$row_orders['order_status'];
$res_ord=mysql_query($sql_ord);
$row_ordstat=mysql_fetch_array($res_ord);


$sql_paystat="select * from  payment_status  where id=".$row_orders['payment_status'];
$res_paystat=mysql_query($sql_paystat);
$row_paystat=mysql_fetch_array($res_paystat);

$sql_disp="select * from  dispatch_order  where order_id=".$row_orders['order_id'];
$res_disp=mysql_query($sql_disp);
$row_disp=mysql_fetch_array($res_disp);
	
	 ?>
		<tr>
                  
						<td><?php echo $sl;?></td>
						
						<td>#<?php echo $inv_row['transaction_id'];?><br><?php echo date("jS F, Y", strtotime($row_orders['order_date'])); ?></td>
						
						<td><?php echo trim(stripslashes($row_prod1['product_name'])); ?> - <?php echo $row_prod1['sku'];?><br>
						<font color="#0000FF"><?php echo trim(stripslashes($row_shop['shop_name'])); ?> -  <?php echo trim(stripslashes($row_shop['tin_no'])); ?></font> <br><?php echo $saleprice=number_format(($row_orders['qty']*$row_orders['sale_price']), 2, '.', '');?> for <?php echo $row_orders['qty'];?> item(s) 
						</td>
						
						
						<td> <?php echo $commission=number_format(($row_orders['qty']*$row_orders['prod_commission']), 2, '.', '');?> </td>					
						
						<td> <?php 
						$remaining=$saleprice-$commission;
						echo number_format($remaining, 2, '.', '');?> </td>

						 
					</tr>
				<?php
				$sl++;
				$totalamount +=$remaining;
				$comm +=$commission;
			  }  
			  ?>
                                        </tbody>
                                    </table>
									<table class="table table-bordered table-hover table-responsive" > 
									 <tr ><td align="center"><strong>Commission : </strong>&nbsp;Rs.&nbsp;<font color="#0000FF" size="+2"><?php echo number_format($comm, 2, '.', '');?></font></td><td align="center"><strong>Total Amount : </strong>&nbsp;Rs.&nbsp;<font color="#0000FF" size="+2"><?php echo number_format($totalamount, 2, '.', '');?></font></td></tr>
									 </table>
									</FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2,3,4] },{'bSortable': false, 'aTargets': [ 0,1 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 50
    
 
} );
 } );

    
</script> 

        <script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
       
        <script type="text/javascript">
            $(function() {
			
			 //Date range picker
                $('#reservation').daterangepicker({format: 'DD-MM-YYYY'});
        
     
            });
        </script>
    </body>
</html>
