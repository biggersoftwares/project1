<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");
if($_POST['act']=='sortorder')
{
 $values=implode(",",$_REQUEST['pvalues']);	
  $pids=implode(",",$_REQUEST['pids']);	
  
	$exp1=explode(",",$values);
	$exp2=explode(",",$pids);
	
	for($k=0; $k<count($_REQUEST['pids']); $k++)
	{
		try
		{
			$db->beginTransaction();
		 $sql="update site_pages set sort=".$exp1[$k]." where page_id=".$exp2[$k];
		$stmt=$db->prepare($sql);
		
		$stmt->execute();
	$db->commit();
	$msg="selected record(s) are sorted";
		
		}
		catch(PDOException $ex)
		{
			//Something went wrong rollback!
			$db->rollBack();
			writeLog($ex->getMessage().'\n'); 
			writeLog($ex->getLine().'\n'); 
		}
	}
	
}
try {
    $db->beginTransaction();
	$sql="select * from site_pages where status=1 order by (sort+0) ASC";		
	$stmt=$db->prepare($sql);	
	$stmt->execute();
	$norows=$stmt->rowCount();
    $db->commit();
} 
catch(PDOException $ex)
{
    //Something went wrong rollback!
    $db->rollBack();
    writeLog($ex->getMessage().'\n'); 
	writeLog($ex->getLine().'\n'); 
}
?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
	 <script language="javascript" type="text/javascript">
function sort_order()
{
	frm=document.pform;
	frm.act.value="sortorder";
	frm.submit();
}






</script>	
		
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       All Pages List
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">All Pages List</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
	<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									<div class="con-rt-head"  style="float:left !important;">
									
          		<a href="#" class="btn btn-xs btn-info" onClick="return sort_order()" ><span class="glyphicon glyphicon-ok"></span>Sort Order</a> 
					</div> 
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
				
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
						<th> Order </th>
						<th> Page Name </th>
						
						
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
			  while($row= $stmt->fetch(PDO::FETCH_ASSOC))
			  {
				  extract($row);
				  
				
	 ?>
				
								<tr>
                  
						<td><input name="pvalues[]" type="text" data-order="<?php echo $sort; ?>" value="<?php echo $sort; ?>"/>
  <input name="pids[]" type="hidden"  value="<?php echo $page_id; ?>" size="3" /></td>
						<td><?php echo ucfirst(stripslashes($page_title));?></td>  

					</tr>
				<?php
			  }  
			  ?>
                                        </tbody>
                                    </table>
									
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            </FORM>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1] },{'bSortable': false, 'aTargets': [ 1 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 100
    
 
} );
 } );

    
</script> 

    </body>
</html>
