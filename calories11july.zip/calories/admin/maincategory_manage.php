<?php 
include("../config/db_connection.php");
include("../config/constants.php");
include("includes/functions.php");
include("includes/loginsession_loginonly.php");
if(isset($_POST['submit']))
{

$maincat_name=addslashes(trim($_POST['maincat_name']));
$sort=trim($_POST['sort']);


if($_POST['act']=='UPDATE')
{
			 $id=strip_tags(trim($_POST['id']));	
			  $upd="update maincategory set 
												maincat_name='".$maincat_name."',
												sort='".$sort."'
												where maincat_id=".$id;
		$res=mysql_query($upd);
		}
else
{
  
	$sql="select maincat_name from maincategory where maincat_name='".$maincat_name."'";
	$res=mysql_query($sql);
	$cnt=mysql_num_rows($res);
	
	if($cnt==0)
	{
		
	 $ins="insert into maincategory (maincat_name,sort)		values
															(
																'".$maincat_name."',
																'".$sort."'
															)";
															
		$res=mysql_query($ins);
	}
}
if($res)
{
header("Location:maincategory.php");
exit;
}
}
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
				  <!--  <script type="text/javascript" src="validations/maincategory.js"></script>-->

    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
           <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Main Category
                       <small><?php
if($_REQUEST['act']=='UPDATE')
{ ?> Update <?php } else { ?> Add New <?php } ?> </small>
                    </h1><span id="resultdiv"></span>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="maincategory.php">View Main Category List</a></li>
                       <!--<li class="active">Roles</li>-->
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<?php
if($_REQUEST['act']=='UPDATE')
{
$v=view_maincategory($_REQUEST['id']);


}
?>
				<form name="frm" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
				<input type="hidden" name="act" id="act" value="<?php echo $_REQUEST['act'] ; ?>" />
            <input type="hidden" name="id"  id="id" value="<?php echo $_REQUEST['id'] ; ?>" />
			
                    <div class="row">
                       
                        <div class="col-md-9">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Different Width</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            Name                                        </div>
                                        <div class="col-xs-7">
             <input type="text" class="form-control" name="maincat_name" id="maincat_name" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['maincat_name']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div>
								
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            Sort Order                                        </div>
                                        <div class="col-xs-2">
             <input type="text" class="form-control" name="sort" id="sort" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['sort']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">
                                    <div class="row">
                                      <div class="col-xs-3">&nbsp;</div>
                                        <div class="col-xs-3">
                                         
										    <?php if($_REQUEST['act']!='UPDATE'){ ?>
						<input type="submit" class="btn btn-success"  name="submit"  value="Add">
					   <?php 
					   }
					   else
					   {
					   ?>
<input type="submit" class="btn btn-success"  name="submit"  value="Update">
					   <?php
					   }
					   ?>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- /.box -->
                        </div>
                       
                    </div>   <!-- /.row -->
					</form>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        
    </body>
</html>
