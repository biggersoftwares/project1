<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("includes/loginsession_loginonly.php");
include("includes/functions.php");
?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
	     </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Our Story
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">  Our Story</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
                                <div class="box-header">
                                    
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
		<script src="js/plugins/tinymce/js/tinymce/tinymce.min.js" type="text/javascript"></script>
		<script type="text/javascript">
tinymce.init({
  selector: 'textarea',
  height: 500,
  plugins: [
        "advlist autolink lists link image charmap print preview anchor",
        "searchreplace visualblocks code fullscreen",
        "insertdatetime media table contextmenu paste imagetools",
        "textcolor colorpicker",
        "fullpage"
    ],
  toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | fontsizeselect | forecolor backcolor ",
  imagetools_cors_hosts: ['www.tinymce.com', 'codepen.io'],
  content_css: [
    '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
    '//www.tinymce.com/css/codepen.min.css'
  ],
  //fontsize_formats: '8pt 10pt 12pt 14pt 18pt 24pt 36pt',
  //fullpage_default_fontsize: "14px",
//  fullpage_default_font_family: "'Times New Roman', Georgia, Serif;",
  //fullpage_default_langcode: "en-US",
  //fullpage_default_text_color: "blue"
});
		</script>
		<script src="js/plugins/tinymce/editor.js" type="text/javascript"></script>
		<link rel="stylesheet" type="text/css" href="js/plugins/tinymce/css/style.css" />
		<link rel="stylesheet" type="text/css" href="js/plugins/tinymce/css/editor.css" />
		<title>Our Story</title>
		
		<div class='action'><img src='js/plugins/tinymce/img/saved.png' alt='saved' /><h3>Saved!</h3></div>
		<div id='container'>
		
		<h1>Our Story</h1>
		<p class='info'>Type something in the editor and click Save or CTRL+S.</p>
		<div id='inner'>
			<form onsubmit='umce();ut(); return false;'>
				<textarea id='main_editor' name='editor'>
				<?php
				$f="../ourstory.txt";
					if(filesize($f)>0){
						$fh=fopen($f,'r');
						$d=fread($fh,filesize($f));
						fclose($fh);
						echo htmlentities($d);
					}
				?>
				</textarea>
				<input type='submit' value='Save' id='submitbtn' name='save' />
			</form>
			
                  <div class='links' style='margin:20px 0 0 0'>
			</div>

							    </div><!-- /.box-body -->
							    
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
    </body>
</html>
