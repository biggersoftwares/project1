<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type='text/javascript' src='<?php echo ADMIN_URL;?>js/jquery-1.11.1.min.js'></script>
		<script type='text/javascript' src='<?php echo ADMIN_URL;?>js/jquery-2.1.1.min.js'></script>
		<script type='text/javascript' src='<?php echo ADMIN_URL;?>js/jquery-ui.js'></script>
		
		<script type='text/javascript' src='<?php echo ADMIN_URL;?>js/bootstrap.js'></script>
		<script type='text/javascript' src='<?php echo ADMIN_URL;?>js/bootstrap.min.js'></script>
		<script src="js/jquery-2.1.1.min.js"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
	<!--	<script src="js/AdminLTE/app.js" type="text/javascript"></script>-->
		
