<?php
date_default_timezone_set('Asia/Kolkata');
function page_name()
{
$page = explode('/',$_SERVER['PHP_SELF']); 
$page = explode('?',array_pop($page)); 
return $page = array_shift($page);
}
function writeLog($data){
	
$page = explode('/',$_SERVER['PHP_SELF']); 
$page = explode('?',array_pop($page)); 
$page = array_shift($page);

		$fileName = date("Y-m-d")." _ ".$page.".txt";

		$fp = fopen("logs/".$fileName, 'a+');

		$data = date("Y-m-d H:i:s")." _ ".$data."\n";

		fwrite($fp,$data);

		fclose($fp);

	}





?>