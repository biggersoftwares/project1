 <?php
  $page = explode('/',$_SERVER['PHP_SELF']);
  $page = explode('?',array_pop($page)); 
  $page = array_shift($page);
   $qrs=$_SERVER['QUERY_STRING'];
 ?>
<!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                   <div class="user-panel">
                        <div class="pull-left image">
                            <img src="img/ganesha.jpg" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, <?php echo $_SESSION['sessionadmin_name']; ?></p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
					
 <?php
        $psql="select * from page_permissions a, site_pages b where
	   a.page_id=b.page_id and a.role_id =".$_SESSION['role_id']. " and b.status=1 order by (b.sort+0) ASC";		
	$pres=mysql_query($psql);	
	while($prow=mysql_fetch_array($pres))
	{
		 $ssql="select * from site_pages  where page_id=".$prow['page_id'];		
	$sres=mysql_query($ssql);	
	$srow=mysql_fetch_array($sres);
		
		if($srow['qr']=="")
		{
		
		
				if($srow['page_url1']=="")
				{
				
			?>					
		<li <?php if($page==$srow['page_url']) echo 'class="active"';?>><a href="<?php echo $srow['page_url']; ?>"><i class="fa fa-edit"></i> <span><?php echo $srow['page_title']; ?></span></a></li>	
		
		<?php
			   }// url1
			   else
			   {
			   ?>
		<li <?php if(($page==$srow['page_url']) || ($page==$srow['page_url1'])) echo 'class="active"';?>><a href="<?php echo $srow['page_url']; ?>"><i class="fa fa-edit"></i> <span><?php echo $srow['page_title']; ?></span></a></li>	
		
		  <?php
			   }
      
		}// qr
		else
		{
			?>
		
		
		
		
		
		<li <?php if($qrs==$srow['qr']) echo 'class="active"';?>><a href="<?php echo $srow['page_url']; ?>"><i class="fa fa-edit"></i> <span><?php echo $srow['page_title']; ?></span></a></li>	
		 <?php
		}
	}
	?>			
	
              
                    </ul>
                </section>
                <!-- /.sidebar -->