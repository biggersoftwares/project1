<?php
$cnt_sql1=mysql_query("select * from maincategory");
$cnt_main=mysql_num_rows($cnt_sql1);

$cnt_sql2=mysql_query("select * from category");
$cnt_cat=mysql_num_rows($cnt_sql2);

$cnt_sql3=mysql_query("select * from subcategory");
$cnt_sub=mysql_num_rows($cnt_sql3);

$cnt_sql4=mysql_query("select * from products");
$cnt_prod=mysql_num_rows($cnt_sql4);

$cnt_sql4=mysql_query("select * from products where status=0");
$cnt_prodinactive=mysql_num_rows($cnt_sql4);


$cnt_sql=mysql_query("select * from brands");
$cnt_brands=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from state");
$cnt_state=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from city");
$cnt_city=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from location");
$cnt_location=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from shops");
$cnt_shops=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from products where eproduct=1");
$cnt_eprod=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from products where ereward=1");
$cnt_erprod=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from pincodes");
$cnt_pincodes=mysql_num_rows($cnt_sql);


$cnt_sql=mysql_query("select * from users");
$cnt_users=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from eusers");
$cnt_eusers=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from dsm");
$cnt_dsm=mysql_num_rows($cnt_sql);
$cnt_sql=mysql_query("select * from csm");
$cnt_csm=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from psp");
$cnt_psp=mysql_num_rows($cnt_sql);


$cnt_sql=mysql_query("select * from constituency");
$cnt_constituency=mysql_num_rows($cnt_sql);
$cnt_sql=mysql_query("select * from districts");
$cnt_districts=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from village");
$cnt_village=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from homebanners");
$cnt_homebanners=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from homeads");
$cnt_homeads=mysql_num_rows($cnt_sql);

$cnt_sql11=mysql_query("select * from invoice");
$cnt_invoice=mysql_num_rows($cnt_sql11);

$cnt_sql12=mysql_query("select * from invoice where order_status='Success'");
$cnt_success=mysql_num_rows($cnt_sql12);

$cnt_sql13=mysql_query("select * from invoice where order_status='Fail'");
$cnt_fail=mysql_num_rows($cnt_sql13);

$cnt_sql14=mysql_query("select * from invoice where order_status='Cancel'");
$cnt_cancel=mysql_num_rows($cnt_sql14);
?>
 
 <?php
  $page = explode('/',$_SERVER['PHP_SELF']);
  $page = explode('?',array_pop($page)); 
  $page = array_shift($page);
   $qrs=$_SERVER['QUERY_STRING'];
 ?>
<!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                   <div class="user-panel">
                        <div class="pull-left image">
                            <img src="img/avatar3.png" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, <?php echo $_SESSION['sessionadmin_name']; ?></p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
 <li <?php if($page=='dashboard.php') echo 'class="active"';?>><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
<li <?php if(($page=='maincategory.php') || ($page=='maincategory_manage.php')) echo 'class="active"';?>><a href="maincategory.php"><i class="fa fa-edit"></i> <span>Main Category</span>  <small class="badge pull-right bg-green"><?php echo $cnt_main;?></small></a></li>	

<li <?php if(($page=='category.php') || ($page=='category_manage.php')) echo 'class="active"';?>><a href="category.php"><i class="fa fa-edit"></i> <span>Category</span> <small class="badge pull-right bg-yellow"><?php echo $cnt_cat;?></small></a></li>	

<li <?php if(($page=='subcategory.php') || ($page=='subcategory_manage.php')) echo 'class="active"';?>><a href="subcategory.php"><i class="fa fa-edit"></i> <span>Sub Category</span> <small class="badge pull-right bg-red"><?php echo $cnt_sub;?></small></a></li>

<li <?php if(($page=='brands.php') || ($page=='brands_manage.php')) echo 'class="active"';?>><a href="brands.php"><i class="fa fa-edit"></i> <span>Brands</span> <small class="badge pull-right bg-red"><?php echo $cnt_brands;?></small></a></li>


<li <?php if(($page=='products_add.php') || ($page=='products_update.php')) echo 'class="active"';?>><a href="products_add.php"><i class="fa fa-edit"></i> <span>Add New Product</span> </a></li>
<li <?php if($page=='products.php')  echo 'class="active"';?>><a href="products.php"><i class="fa fa-edit"></i> <span>All Products</span> <small class="badge pull-right bg-green"><?php echo $cnt_prod;?></small></a></li>

<li <?php if($page=='products_inactive.php')  echo 'class="active"';?>><a href="products_inactive.php"><i class="fa fa-edit"></i> <span>Products Inactive</span> <small class="badge pull-right bg-green"><?php echo $cnt_prodinactive;?></small></a></li>


<li <?php if($page=='eproducts.php')  echo 'class="active"';?>><a href="eproducts.php"><i class="fa fa-edit"></i> <span>All E Products</span> <small class="badge pull-right bg-green"><?php echo $cnt_eprod;?></small></a></li>

<li <?php if($page=='erewardproducts.php')  echo 'class="active"';?>><a href="erewardproducts.php"><i class="fa fa-edit"></i> <span>All E Reward Products</span> <small class="badge pull-right bg-green"><?php echo $cnt_erprod;?></small></a></li>





<li <?php if(($page=='state.php') || ($page=='state_manage.php')) echo 'class="active"';?>><a href="state.php"><i class="fa fa-edit"></i> <span>States</span>  <small class="badge pull-right bg-green"><?php echo $cnt_state;?></small></a></li>	

<li <?php if(($page=='city.php') || ($page=='city_manage.php')) echo 'class="active"';?>><a href="city.php"><i class="fa fa-edit"></i> <span>City</span>  <small class="badge pull-right bg-green"><?php echo $cnt_city;?></small></a></li>	

<li <?php if(($page=='location.php') || ($page=='location_manage.php')) echo 'class="active"';?>><a href="location.php"><i class="fa fa-edit"></i> <span>Location</span>  <small class="badge pull-right bg-green"><?php echo $cnt_location;?></small></a></li>
<li <?php if($page=='shopusers.php') echo 'class="active"';?>><a href="shopusers.php"><i class="fa fa-edit"></i> <span>Shop Users</span>   </a></li>
<li <?php if(($page=='shops.php') || ($page=='shops_manage.php')) echo 'class="active"';?>><a href="shops.php"><i class="fa fa-edit"></i> <span>Shops</span>  <small class="badge pull-right bg-green"><?php echo $cnt_shops;?></small></a></li>


<li <?php if(($page=='districts.php') || ($page=='district_manage.php')) echo 'class="active"';?>><a href="districts.php"><i class="fa fa-edit"></i> <span>Districts</span>  <small class="badge pull-right bg-green"><?php echo $cnt_districts;?></small></a></li>	

<li <?php if(($page=='constituency.php') || ($page=='constituency_manage.php')) echo 'class="active"';?>><a href="constituency.php"><i class="fa fa-edit"></i> <span>Constituency</span>  <small class="badge pull-right bg-green"><?php echo $cnt_constituency;?></small> </a></li>
<li <?php if(($page=='village.php') || ($page=='village_manage.php')) echo 'class="active"';?>><a href="village.php"><i class="fa fa-edit"></i> <span>Village</span>  <small class="badge pull-right bg-green"><?php echo $cnt_village;?></small> </a></li>
	
<li <?php if(($page=='dsm.php') || ($page=='dsm_manage.php')) echo 'class="active"';?>><a href="dsm.php"><i class="fa fa-edit"></i> <span>DSM</span>  <small class="badge pull-right bg-green"><?php echo $cnt_dsm;?></small> </a></li>


<li <?php if(($page=='csm.php') || ($page=='csm_manage.php')) echo 'class="active"';?>><a href="csm.php"><i class="fa fa-edit"></i> <span>CSM</span>   <small class="badge pull-right bg-green"><?php echo $cnt_csm;?></small></a></li>

<li <?php if(($page=='psp.php') || ($page=='psp_manage.php')) echo 'class="active"';?>><a href="psp.php"><i class="fa fa-edit"></i> <span>PSP</span>   <small class="badge pull-right bg-green"><?php echo $cnt_psp;?></small></a></li>

<li <?php if(($page=='eusers.php') || ($page=='eusers_manage.php')) echo 'class="active"';?>><a href="eusers.php"><i class="fa fa-edit"></i> <span>E-Users</span>  <small class="badge pull-right bg-green"><?php echo $cnt_eusers;?></small> </a></li>

<li <?php if($page=='users.php') echo 'class="active"';?>><a href="users.php"><i class="fa fa-edit"></i> <span>All Users</span>  <small class="badge pull-right bg-green"><?php echo $cnt_users;?></small> </a></li>

<li <?php if(($page=='coupons.php') || ($page=='coupons_manage.php')) echo 'class="active"';?>><a href="coupons.php"><i class="fa fa-edit"></i> <span>Coupons</span>  </a></li>

<li <?php if($page=='settings.php') echo 'class="active"';?>><a href="settings.php"><i class="fa fa-edit"></i> <span>Settings</span>  </a></li>
		
<li <?php if(($page=='pincodes.php') || ($page=='pincode_manage.php')) echo 'class="active"';?>><a href="pincodes.php"><i class="fa fa-edit"></i> <span>Pincodes</span>  <small class="badge pull-right bg-green"><?php echo $cnt_pincodes;?></small> </a></li>
<li <?php if($page=='view_usertransferfunds_inactive.php')  echo 'class="active"';?>><a href="view_usertransferfunds_inactive.php"><i class="fa fa-edit"></i> <span>View User Transferfunds Inactive</span></a></li>
<li <?php if($page=='view_usertransferfunds.php')  echo 'class="active"';?>><a href="view_usertransferfunds.php"><i class="fa fa-edit"></i> <span>View User Transfer funds</span></a></li>


<li <?php if($page=='view_psptransferfunds_inactive.php')  echo 'class="active"';?>><a href="view_psptransferfunds_inactive.php"><i class="fa fa-edit"></i> <span>View PSP Transferfunds Inactive</span></a></li>

  
<li <?php if($page=='view_psptransferfunds.php')  echo 'class="active"';?>><a href="view_psptransferfunds.php"><i class="fa fa-edit"></i> <span>View PSP Transfer funds</span></a></li>   
<li <?php if(($page=='homebanners.php') || ($page=='homebanners_manage.php')) echo 'class="active"';?>><a href="homebanners.php"><i class="fa fa-edit"></i> <span>Home Banners</span>  <small class="badge pull-right bg-green"><?php echo $cnt_homebanners;?></small> </a></li>    

<li <?php if(($page=='homeads.php') || ($page=='homeads_manage.php')) echo 'class="active"';?>><a href="homeads.php"><i class="fa fa-edit"></i> <span>Home Ads</span>  <small class="badge pull-right bg-green"><?php echo $cnt_homeads;?></small> </a></li>
<li <?php if($page=='orders.php') echo 'class="active"';?>><a href="orders.php"><i class="fa fa-edit"></i> <span>Orders</span> <small class="badge pull-right bg-green"><?php echo $cnt_invoice;?></small> </a></li>	

<li <?php if($page=='dispatch_orders.php') echo 'class="active"';?>><a href="dispatch_orders.php"><i class="fa fa-edit"></i> <span>Dispatch Orders</span>  </a></li>	

<li <?php if($page=='report_sales.php') echo 'class="active"';?>><a href="report_sales.php"><i class="fa fa-edit"></i> <span>Sales Report</span>  </a></li>	
                <!--<li>
                            <a href="pages/widgets.html">
                                <i class="fa fa-th"></i> <span>Widgets</span> <small class="badge pull-right bg-green">new</small>
                            </a>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>Charts</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/charts/morris.html"><i class="fa fa-angle-double-right"></i> Morris</a></li>
                                <li><a href="pages/charts/flot.html"><i class="fa fa-angle-double-right"></i> Flot</a></li>
                                <li><a href="pages/charts/inline.html"><i class="fa fa-angle-double-right"></i> Inline charts</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-laptop"></i>
                                <span>UI Elements</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/UI/general.html"><i class="fa fa-angle-double-right"></i> General</a></li>
                                <li><a href="pages/UI/icons.html"><i class="fa fa-angle-double-right"></i> Icons</a></li>
                                <li><a href="pages/UI/buttons.html"><i class="fa fa-angle-double-right"></i> Buttons</a></li>
                                <li><a href="pages/UI/sliders.html"><i class="fa fa-angle-double-right"></i> Sliders</a></li>
                                <li><a href="pages/UI/timeline.html"><i class="fa fa-angle-double-right"></i> Timeline</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-edit"></i> <span>Forms</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/forms/general.html"><i class="fa fa-angle-double-right"></i> General Elements</a></li>
                                <li><a href="pages/forms/advanced.html"><i class="fa fa-angle-double-right"></i> Advanced Elements</a></li>
                                <li><a href="pages/forms/editors.html"><i class="fa fa-angle-double-right"></i> Editors</a></li>                                
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-table"></i> <span>Tables</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/tables/simple.html"><i class="fa fa-angle-double-right"></i> Simple tables</a></li>
                                <li><a href="pages/tables/data.html"><i class="fa fa-angle-double-right"></i> Data tables</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="pages/calendar.html">
                                <i class="fa fa-calendar"></i> <span>Calendar</span>
                                <small class="badge pull-right bg-red">3</small>
                            </a>
                        </li>
                        <li>
                            <a href="pages/mailbox.html">
                                <i class="fa fa-envelope"></i> <span>Mailbox</span>
                                <small class="badge pull-right bg-yellow">12</small>
                            </a>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-folder"></i> <span>Examples</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/examples/invoice.html"><i class="fa fa-angle-double-right"></i> Invoice</a></li>
                                <li><a href="pages/examples/login.html"><i class="fa fa-angle-double-right"></i> Login</a></li>
                                <li><a href="pages/examples/register.html"><i class="fa fa-angle-double-right"></i> Register</a></li>
                                <li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Lockscreen</a></li>
                                <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> 404 Error</a></li>
                                <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> 500 Error</a></li>                                
                                <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> Blank Page</a></li>
                            </ul>
                        </li>-->
                    </ul>
                </section>
                <!-- /.sidebar -->