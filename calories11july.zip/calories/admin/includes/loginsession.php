<?php
session_start();
 include("config/constants.php");
 include("includes/js.php");

if($_SESSION['sessionadmin_id']=="")
{
//header("Location:../index.php");
//exit;	
}
$chk_page = explode('/',$_SERVER['PHP_SELF']);
  $chk_page = explode('?',array_pop($chk_page)); 
   $chk_page = array_shift($chk_page);
  $sql_per="select * from site_pages where status=1 and  page_url='".$chk_page."'";
$res_per=mysql_query($sql_per);
$row_per=mysql_fetch_array($res_per);
 $page_id=$row_per['page_id'];

   $sel_pageper="select * from page_permissions where role_id=".$_SESSION['role_id']." and page_id=".$page_id;
$res_pageper=mysql_query($sel_pageper);
if(mysql_num_rows($res_pageper)==0)
{
header("Location:../index.php");
exit;
}
?>
