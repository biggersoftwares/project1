<?php
date_default_timezone_set('Asia/Kolkata');

function view_dispatch($id)
{

	$sql="select * from dispatch_orders where invoice_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}

//  ****************************************     Locations  *************************

function view_locations($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  location where status=1 order by location_name ASC";
	}
	else
	{
		$sql="select * from location where location_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}



//  ****************************************     States  *************************

function view_states($id=0)
{
	
	if($id==0)
	{
		$sql="select * from  state where status=1 order by state_name ASC";
	}
	else
	{
		$sql="select * from state where id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

//  ****************************************    Roles  *************************

function view_roles($id=0)
{
	
	if($id==0)
	{
		$sql="select * from roles where status=1 order by role_id ASC";
	}
	else
	{
		$sql="select * from roles where role_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
//  ****************************************     Sub Users  *************************

function view_subuser($id)
{

	$sql="select * from admin where  user_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}
//  ****************************************    Roles  *************************

function view_subusers($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from admin where status=1 order by user_name ASC";
	}
	else
	{
		$sql="select * from admin where user_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}


function convert_number_words($number)
{
if (($number < 0) || ($number > 999999999))
{
throw new Exception("Number is out of range");
}
 
$Gn = floor($number / 100000);  /* Millions (giga) */
$number -= $Gn * 100000;
$kn = floor($number / 1000);     /* Thousands (kilo) */
$number -= $kn * 1000;
$Hn = floor($number / 100);      /* Hundreds (hecto) */
$number -= $Hn * 100;
$Dn = floor($number / 10);       /* Tens (deca) */
$n = $number % 10;               /* Ones */
 
$res = "";
 
if ($Gn)
{
$res .= convert_number_words($Gn) . " Lacs";
}
 
if ($kn)
{
$res .= (empty($res) ? "" : " ") .
convert_number_words($kn) . " Thousand";
}
 
if ($Hn)
{
$res .= (empty($res) ? "" : " ") .
convert_number_words($Hn) . " Hundred";
}
 
$ones = array("", "One", "Two", "Three", "Four", "Five", "Six",
"Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen",
"Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen",
"Nineteen");
$tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty",
"Seventy", "Eigthy", "Ninety");
 
if ($Dn || $n)
{
if (!empty($res))
{
$res .= " and ";
}
 
if ($Dn < 2)
{
$res .= $ones[$Dn * 10 + $n];
}
else
{
$res .= $tens[$Dn];
 
if ($n)
{
$res .= "-" . $ones[$n];
}
}
}
 
if (empty($res))
{
$res = "zero";
}
return $res;

}

// ------------------------------------------------------  awmindia.net  -----------------------------


//  ****************************************     Products  *************************

function view_product($id)
{

	$sql="select * from products where product_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
        
        $sql="select * from product_prices where product_id=".$id;
	$res=mysql_query($sql);
	while($row= mysql_fetch_array($res))
            $price[]= $row;
        $cat[0]['prices'] = $price;        
	return $cat;
	
}

function view_product_desc($id)
{

	$sql="select * from product_desc where product_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}
function view_staticpage($id)
{

	$sql="select * from staticpages where staticpage_id=".$id;
	$res=mysql_query($sql);
	$row= mysql_fetch_array($res);
	$cat[]= $row;
	return $cat;
	
}

function view_topnews($id)
{

	if($id==0)
	{
		 $sql="select * from  topnews  where status=1 order by article_id DESC";
	}
	else
	{
		$sql="select * from topnews where article_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_newsscroll($id)
{

	if($id==0)
	{
		 $sql="select * from  newsscroll  where status=1 order by article_id DESC";
	}
	else
	{
		$sql="select * from newsscroll where article_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_coupons($id)
{

	if($id==0)
	{
		 $sql="select * from  coupons  where status=1 order by coupon_id DESC";
	}
	else
	{
		$sql="select * from coupons where coupon_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
//  ****************************************     Courses  *************************

function view_maincategory($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  maincategory  where status=1 order by maincat_name ASC";
	}
	else
	{
		$sql="select * from maincategory where maincat_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_category($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  category  where status=1 order by cat_name ASC";
	}
	else
	{
		$sql="select * from category where cat_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_category_maincat($id=0)
{

		$sql="select * from category where maincat_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_subcategory($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  subcategory  where status=1 order by subcat_name ASC";
	}
	else
	{
		$sql="select * from subcategory where subcat_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_country($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  country  where status=1 order by country_name ASC";
	}
	else
	{
		$sql="select * from country where country_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_city($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  city  where status=1 order by city_name ASC";
	}
	else
	{
		$sql="select * from city where city_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
 function view_banners($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  banners  where status=1 order by banner_id ASC";
	}
	else
	{
		$sql="select * from banners where banner_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function forgot_pwd($datas)
{
		foreach($datas as $key => $value)
		$data[$key] = mysql_real_escape_string(trim($value));
		$res=query("select * from users where b_emailid='".$data['email']."'");
		$row=mysql_fetch_array($res);
		$num=mysql_num_rows($res);
		if($num==1)
		{
	     $subject = 'Andrew Wommack Ministries India';

// message

$message = '<div marginheight="0" marginwidth="0">
    	<div style="background-color:#f5f5f5;width:100%;margin:0;padding:70px 0 70px 0">
        	<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
            	<tbody>
                	<tr>
                    <td valign="top" align="center">
						<div></div>
                    	<span class="HOEnZb">
                        	<font color="#888888"></font>
                        </span>
                        <span class="HOEnZb">
                        	<font color="#888888"></font>
                        </span>
                        <table width="600" cellspacing="0" cellpadding="0" border="0" style="border-radius:6px!important;background-color:#fdfdfd;border:1px solid #dcdcdc;border-radius:6px!important">
                        	<tbody>
                            	<tr>
                                	<td valign="top" align="center">
                                		<table width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#557da1" style="background-color:#557da1;color:#ffffff;border-top-left-radius:6px!important;border-top-right-radius:6px!important;border-bottom:0;font-family:Arial;font-weight:bold;line-height:100%;vertical-align:middle">
                                        	<tbody>
                                            	<tr>
                                                	<td>
                                            			<h1 style="color:#ffffff;margin:0;padding:28px 24px;display:block;font-family:Arial;font-size:30px;font-weight:bold;text-align:left;line-height:150%">Welcome to Andrew Wommack Ministries India</h1>

                                            		</td>
                                        		</tr>
                                            </tbody>
                                        </table></td>
                            	</tr>
                                <tr>
                                	<td valign="top" align="center">
                                		<span class="HOEnZb">
                                        	<font color="#888888"></font>
                                        </span>
                                        	<table width="600" cellspacing="0" cellpadding="0" border="0">
                                            	<tbody>
                                                	<tr>
                                                    	<td valign="top" style="background-color:#fdfdfd;border-radius:6px!important">
                                                			<span class="HOEnZb">
                                                            	<font color="#888888"></font>
                                                            </span>
                                                            <table width="100%" cellspacing="0" cellpadding="20" border="0">
                                                            	<tbody>
                                                                	<tr>
                                                                    	<td valign="top">
                                                            				<div style="color:#737373;font-family:Arial;font-size:14px;line-height:150%;text-align:left">
																				<p>Your Password is <strong>'.$row['pwd'].'</strong>.</p>
																				
																				<span class="HOEnZb">
                                                                                	<font color="#888888"></font>
                                                                                </span>
                                                                            </div>
                                                                            <span class="HOEnZb">
                                                                            	<font color="#888888"></font>
                                                                            </span>
                                                                        </td>
                                                                   </tr>
                                                                </tbody>
                                                           </table>
                                                      </td>
                                                  </tr>
                                              </tbody>
                                         </table>
                                   </td>
                               </tr>
                               <tr>
                               	<td valign="top" align="center">
                                	<table width="600" cellspacing="0" cellpadding="10" border="0" style="border-top:0">
                                    	<tbody>
                                        	<tr>
                                            	<td valign="top">
                                                	<table width="100%" cellspacing="0" cellpadding="10" border="0">
                                                    	<tbody>
                                                        	<tr>
                                                            	<td valign="middle" style="border:0;color:#99b1c7;font-family:Arial;font-size:12px;line-height:125%;text-align:center" colspan="2">
                                                        		<p>Andrew Wommack Ministries India</p>
                                                        		</td>
                                                    		</tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                        	</tr>
                                     	</tbody>
                                 	</table>
                             	</td>
                            </tr>
                       </tbody>
                   </table>
                </td>
              </tr>
           </tbody>
       </table>
   </div>
 <div class="yj6qo"></div>
 <div class="adL"></div>
</div>';


$to = $row['user_email'];
$headers .= 'From: '.FROM_NAME.' <'.FROM_MAIL.'>' . "\r\n";
//$headers .= "Reply-To: ". strip_tags($_POST['cemail']) . "\r\n";
//$headers .= "CC:".strip_tags($businessemail)."\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

// Mail it
mail($to, $subject, $message, $headers);
		
		return $num;
		}
		else
		{
		return 0;	
		}
	
	}


function view_orderstatus($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  orderstatus  where status=1 order by orderstatus_name ASC";
	}
	else
	{
		$sql="select * from orderstatus where orderstatus_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_newsletters($id=0)
{
	
	if($id==0)
	{
		  $sql="select * from  newsletters  where status=1 order by id ASC";
	}
	else
	{
		$sql="select * from newsletters where id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}


function view_city_state($id=0)
{

		$sql="select * from city where state_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_location_city($id=0)
{
	

		$sql="select * from location where city_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

//  ****************************************    Roles  *************************

function view_shops($id=0)
{
	
	if($id==0)
	{
		$sql="select * from shops where status=1 order by shop_id DESC";
	}
	else
	{
		$sql="select * from shops where shop_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_brands($id=0)
{
	
	if($id==0)
	{
		$sql="select * from brands where status=1 order by brand_id DESC";
	}
	else
	{
		$sql="select * from brands where brand_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

//-------------------------------

function view_district($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  districts  where status=1 order by district_name ASC";
	}
	else
	{
		$sql="select * from districts where district_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_constituency($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  constituency where status=1 order by constituency_name ASC";
	}
	else
	{
		$sql="select * from constituency where constituency_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_district_state($id=0)
{

		$sql="select * from districts where state_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_constituence_district_state($sid,$did)
{

		 $sql="select * from constituency where state_id=".$sid." and district_id=".$did;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_village($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  village where status=1 order by village_name ASC";
	}
	else
	{
		$sql="select * from village where village_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_dsm($id=0)
{
	
	if($id==0)
	{
		$sql="select * from dsm where status=1 order by dsm_id DESC";
	}
	else
	{
		 $sql="select * from dsm where dsm_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_constituency_district($id=0)
{
	

		$sql="select * from constituency where district_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_csm($id=0)
{
	
	if($id==0)
	{
		$sql="select * from csm where status=1 order by csm_id DESC";
	}
	else
	{
		$sql="select * from csm where csm_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

function view_psp($id=0)
{
	
	if($id==0)
	{
		$sql="select * from psp where status=1 order by psp_id DESC";
	}
	else
	{
		 $sql="select * from psp where psp_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_constituency_csm($id=0)
{
	
	
		 $sql="select * from csm where constituency_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
} 
function view_constituency_villages($id=0)
{
	
	
		  $sql="select * from village where constituency_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_village_psps($id=0)
{
	
	
		  $sql="select * from psp where village_id=".$id;
	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_eusers($id=0)
{
	
	if($id==0)
	{
		$sql="select * from eusers where status=1 order by euser_id DESC";
	}
	else
	{
		 $sql="select * from eusers where euser_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
function view_users($id=0)
{
	
	if($id==0)
	{
		$sql="select * from users where status=1 order by user_id DESC";
	}
	else
	{
		 $sql="select * from users where user_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
//  ****************************************     States  *************************

function view_pincodes($id=0)
{
	
	if($id==0)
	{
		$sql="select * from  pincodes where status=1 order by pincode ASC";
	}
	else
	{
		$sql="select * from pincodes where pincode_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
 function view_homebanners($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  homebanners  where status=1 order by homebanner_id ASC";
	}
	else
	{
		$sql="select * from homebanners where homebanner_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
 function view_homeads($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  homeads  where status=1 order by homead_id ASC";
	}
	else
	{
		$sql="select * from homeads where homead_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}
 function view_ads($id=0)
{
	
	if($id==0)
	{
		 $sql="select * from  admanagement  where status=1 order by ad_id ASC";
	}
	else
	{
		$sql="select * from admanagement where ad_id=".$id;
	}

	
	$res=mysql_query($sql);
	
	while($row= mysql_fetch_array($res))
	{
		$cat[]= $row;
	}
	return $cat;
	
}

?>