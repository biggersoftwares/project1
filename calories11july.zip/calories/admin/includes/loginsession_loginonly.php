<?php
 include("config/constants.php");
 include("includes/js.php");

if($_SESSION['sessionadmin_id']=="")
{
header("Location:../index.php");
exit;	
}

?>