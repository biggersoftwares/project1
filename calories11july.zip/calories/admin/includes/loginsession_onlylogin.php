<?php
if($_SESSION['sessionadmin_id']=="")
{
header("Location:../index.php");
exit;	
}

?>