<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession_loginonly.php");


$sql_cart="select * from orders where invoice_id='".$_REQUEST['id']."'";
$res_cart=mysql_query($sql_cart);



$sql_invoice="select * from invoice where invoice_id='".$_REQUEST['id']."'";
$res_invoice=mysql_query($sql_invoice);
$row_invoice=mysql_fetch_array($res_invoice);
$transaction_id=$row_invoice['transaction_id'];



 $sql_account="select * from bill_ship_address where user_id='".$row_invoice['user_id']."'";
$res_account=mysql_query($sql_account);
$row_account=mysql_fetch_array($res_account);



try {
    $db->beginTransaction();
	 $sql="select * from orders  where invoice_id=".$_REQUEST['id'];
	$stmt=$db->prepare($sql);	
	$stmt->execute();
	$norows=$stmt->rowCount();
	
	$sql_in="select * from invoice  where invoice_id=".$_REQUEST['id'];
	$stmt_in=$db->prepare($sql_in);	
	$stmt_in->execute();
	$row_in= $stmt_in->fetch(PDO::FETCH_ASSOC);
	
	 $sql3="select * from bill_ship_address  where user_id=".$row_in['user_id'];
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
    $db->commit();
} 
catch(PDOException $ex)
{
    //Something went wrong rollback!
    $db->rollBack();
    writeLog($ex->getMessage().'\n'); 
	writeLog($ex->getLine().'\n'); 
}
?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
		
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Invoice Details
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Invoice Details</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <div class="row">
                        <div class="col-xs-12">
						<div id="printableArea">
                            <div class="box">
                                <div class="box-header">
                            <table  class="table" style="width:90%;">
		<tr><th>Transaction ID</th><td> #<?php echo $row_in['transaction_id'];?></td> <th>Name</th><td><?php echo $row3['s_firstname']." ".$row3['s_lastname'];?></td><th>Amount</th><td><?php echo number_format($row_in['total_amount'], 2, '.', '');?></td><th>Date</th><td>	<?php echo date("jS F, Y", strtotime($row_in['invoice_date'])); ?></td></tr>
							</table>
									 
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table width="100%" border="0" cellspacing="1">
								  <tr>
									<td><table width="100%" border="2" style="border-collapse:collapse" cellspacing="5">
									  <tr>
										<td height="30"><strong>&nbsp;Product</strong></td>
										<td><strong>&nbsp;Quantity</strong></td>
										<td><strong>&nbsp;Price</strong></td>
									  </tr>
									  <?php
$cart_subtotal=0;
$k=0;
while($cart_row=mysql_fetch_array($res_cart))
{

$sql_prod1="select * from  products  where product_id=".$cart_row['prod_id'];
$res_prod1=mysql_query($sql_prod1);
$row_prod1=mysql_fetch_array($res_prod1);

if($row_prod1['sale_price']!="")
{
$price=$row_prod1['sale_price'];
}
else
{
$price=$row_prod1['regular_price'];
}
$subtotal=$price*$cart_row['qty'];



?>
									  <tr>
										<td>&nbsp;<?php echo trim(stripslashes($row_prod1['product_name']))."  ".$row_prod1['sku']; ?></td>
										<td>&nbsp;<?php echo $cart_row['qty'];?></td>
										<td>&nbsp;Rs.<?php echo number_format($subtotal, 2, '.', '');?></td>
									  </tr>
									  <?php
													$k++;
													$cart_subtotal +=$subtotal;
													}
													?>
									  
									  <tr>
									    <td colspan="2" height="30"><strong>Cart Subtotal:</strong></td>
									    <td>&nbsp;Rs.&nbsp;<?php echo number_format($cart_subtotal, 2, '.', '');?></td>
								      </tr>
									  
									
												<?php 
												$shipping="";
												if($shipping=="")
												{
												$ship='Free';
												
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal*$shipping)/100;
												$cart_subtotal=$cart_subtotal+$grandtotal;
												}
												?>
									  <tr>
									    <td colspan="2" height="30"><strong>Shipping:</strong></td>
									    <td>&nbsp;<?php echo $ship;?></td>
									  
								      </tr>
									  <tr>
									    <td colspan="2" height="30"><strong>Payment Method:</strong></td>
									    <td>&nbsp;<?php echo $row_in['payment_method'];?></td>
									    
								      </tr>
									  <tr>
									    <td colspan="2" height="30"><strong>Order Total:</strong></td>
									    <td>&nbsp;Rs.&nbsp;<?php echo number_format($cart_subtotal, 2, '.', '');?></td>
									   
								      </tr>
									</table>
									</td>
								  </tr>
								  <tr>
									<td>&nbsp;</td>
								  </tr>
								</table>

										 <h2 style="color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;text-align:left;line-height:150%">Customer details</h2>
										 <p><b>Email: </b><?php echo $row_account['s_emailid'];?></p>
										 <p><b>Tel: </b><?php echo $row_account['s_mobileno'];?></p>
										 <table cellspacing="0" cellpadding="0" border="0" style="width:100%;vertical-align:top">
                                	<tbody>
                                    	<tr>
                                        	<td width="50%" valign="top">
                							<h3 style="color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;text-align:left;line-height:150%">Billing address</h3>
											<p><?php 
															echo $row_account['b_firstname']."  ".$row_account['b_lastname']."<br>";
														echo $row_account['b_address']."<br>";
														echo $row_account['b_city']." - ".$row_account['b_zipcode'];
															?></p>
											
    
           									</td>
            								<td width="50%" valign="top">
                							<h3 style="color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;text-align:left;line-height:150%">Shipping address</h3>
                                        <p><?php
															echo $row_account['s_firstname']."  ".$row_account['s_lastname']."<br>";
														echo $row_account['s_address']."<br>";
														echo $row_account['s_city']." - ".$row_account['s_zipcode'];
														?></p><span>
                                           </span>
                                            </td>
                                      </tr>
                                       </tbody>
                                    </table>
								  </FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
							
							</div>  <!--   Print purpose  -->
							<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-6">
                                                                             </div>
                                       
                                        <div class="col-xs-2">
                                       
                         <button id="addfeestu" name="addfeestu" onClick="printDiv('printableArea')" class="btn btn-primary">Print</button>
					 
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
         <script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
 
     document.body.innerHTML = printContents;
 
     window.print();
 
     document.body.innerHTML = originalContents;
}
 
</script>

    </body>
</html>
