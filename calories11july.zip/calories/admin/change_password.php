<?php 
include("../config/db_connection.php");
include("includes/loginsession_onlylogin.php");
include("../config/constants.php");
include("includes/functions.php");
$msg="";
if(isset($_POST['submit']))
{
	
	 $old_pass=mysql_real_escape_string(stripslashes($_POST['old_pass']));
	 $new_pass=mysql_real_escape_string(stripslashes($_POST['new_pass']));
	// ----------------------------------------To Check The User----------------------
	  $display_user="select * from admin where user_id='".$_SESSION['sessionadmin_id']."' and pwd='".$old_pass."'";
	$display_result=mysql_query($display_user);
		if(mysql_num_rows($display_result)==1)
		{
			 $upd_qry="update admin set pwd='$new_pass'
			
			where user_id='".$_SESSION['sessionadmin_id']."'";
			mysql_query($upd_qry);
			$msg="The record is updated successfully";
		}
		else
		{
			$msg="Wrong Password.";
		}

	
	
}// isset
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
<script language="javascript" type="text/javascript">
function funChg()
{
frm=document.frmadd;
if(frm.old_pass.value=="")
{
alert("Enter Old Password");
frm.old_pass.focus();
return false;
}
if(frm.new_pass.value=="")
{
alert("Enter New Password");
frm.new_pass.focus();
return false;
}
if(frm.new_pass.value!=frm.confirm_pass.value)
{
alert("New Password and Confirm Password not Match");
frm.confirm_pass.focus();
return false;
}
document.frmadd.act.value="UPDATE";
return true;
	
}


</script>
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Change Password <font color="#0000FF"><span style="font-size:14px;"><?php if($msg!=""){ echo $msg;} ?></span>	</font>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Change Password</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
 <div class="row">
                       
                        <div class="col-md-6">
<div class="box box-primary">
                                
                                <form role="form" name="frmadd" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"  onsubmit="return funChg();">
                      <input type="hidden" name="act" value="" />
                                    <div class="box-body">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Old Password</label>
                                            <input  class="form-control" name="old_pass" id="old_pass" type="password" placeholder="Old Password" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">New Password</label>
                                            <input type="password" class="form-control" name="new_pass" id="new_pass"  placeholder=" New Password" required>
                                        </div>
										<div class="form-group">
                                            <label for="exampleInputPassword1">Confirm Password</label>
                                            <input type="password" class="form-control" name="confirm_pass" id="confirm_pass"  placeholder=" Confirm Password" required>
                                        </div>
                                     
                                    </div><!-- /.box-body -->

                                    <div class="box-footer">
                                        <input name="submit" type="submit" class="btn btn-primary" value="Update Password"/>
                                    </div>
                                </form>
                            </div>

</div>
</div>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

    </body>
</html>
