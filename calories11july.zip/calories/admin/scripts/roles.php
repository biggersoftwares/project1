<?php
include("../../config/dbpdo.php");
include("../includes/common_functions.php");

  $role_name=strip_tags(trim($_POST['role_name']));

$act=strip_tags(trim($_POST['act']));


$v=1;



if($act=='UPDATE')
{
	try
	{
		$db->beginTransaction();
			
			 $id=strip_tags(trim($_POST['id']));	
			  $upd="update roles set 
												role_name=:role_name
												where role_id=:id";
		$stmt=$db->prepare($upd);
		$stmt->bindValue(":role_name",$role_name,PDO::PARAM_STR);
		$stmt->bindValue(":id",$id,PDO::PARAM_INT);
		$stmt->execute();
		$db->commit();
		$v=5;
	}
	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=6;
		   }
	
}
else
{
  
	$sql="select role_name from roles where role_name=:role_name";
	$stmt=$db->prepare($sql);  
	$stmt->bindValue(":role_name",$role_name,PDO::PARAM_STR);
	$stmt->execute();
	$cnt=$stmt->rowCount();
	
	if($cnt==0)
	{
		
			try
			{
			$db->beginTransaction();
	 $ins="insert into roles (role_name)		values
															(
																:role_name
															)";
$stmt=$db->prepare($ins);
				
				$stmt->bindValue(":role_name",$role_name,PDO::PARAM_STR);
				$stmt->execute();
				$db->commit();
				$v=3;
			}
		 	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=4;
		   }
		
	}
	else
	{
	$v=2;	
	}
  
	  
	  
}
echo $v
?>