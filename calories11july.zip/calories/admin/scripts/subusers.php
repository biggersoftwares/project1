<?php
include("../../config/dbpdo.php");
include("../../includes/common_functions.php");

  $role_id=strip_tags(trim($_POST['role_id']));
  $user_name=strip_tags(trim($_POST['user_name']));
  $pwd=strip_tags(trim($_POST['pwd']));	
  $user_email=strip_tags(trim($_POST['user_email']));
  $mobileno=strip_tags(trim($_POST['mobileno']));

$act=strip_tags(trim($_POST['act']));



$v=1;


if($act=='UPDATE')
{
	try
	{
		$db->beginTransaction();
			
			 $id=strip_tags(trim($_POST['id']));	
			     $upd="update admin set 
												user_name='".$user_name."',
												role_id='".$role_id."',
												user_email='".$user_email."',
												mobileno='".$mobileno."'
												where user_id='".$id."'";
		$stmt=$db->prepare($upd);
		$stmt->execute();
		$db->commit();
		$v=5;
	}
	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=6;
		   }
	
}
else
{
  
	$sql="select user_name from admin where user_name=:user_name";
	$stmt=$db->prepare($sql);  
	$stmt->bindValue(":user_name",$user_name,PDO::PARAM_STR);
	$stmt->execute();
	$cnt=$stmt->rowCount();
	
	if($cnt==0)
	{
		
			try
			{
			$db->beginTransaction();
	 $ins="insert into admin(user_name,pwd,role_id,user_email,mobileno)
																values
															(
																:name,
																:pwd,
																:roleid,
																:user_email,
																:mobileno
															)";
$stmt=$db->prepare($ins);
				
				$stmt->bindValue(":name",$user_name,PDO::PARAM_STR);
				$stmt->bindValue(":pwd",$pwd,PDO::PARAM_STR);
				$stmt->bindValue(":roleid",$role_id,PDO::PARAM_INT);
				$stmt->bindValue(":user_email",$user_email,PDO::PARAM_STR);
				$stmt->bindValue(":mobileno",$mobileno,PDO::PARAM_STR);
				$stmt->execute();
				$db->commit();
				$v=3;
			}
		 	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=4;
		   }
		
	}
	else
	{
	$v=2;	
	}
  
	  
	  
}

echo $v;
?>