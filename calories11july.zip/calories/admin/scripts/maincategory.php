<?php
include("../../config/dbpdo.php");
include("../includes/common_functions.php");

  $maincat_name=addslashes(trim(str_replace("_","&",$_POST['maincat_name'])));

$act=strip_tags(trim($_POST['act']));


$v=1;



if($act=='UPDATE')
{
	try
	{
		$db->beginTransaction();
			
			 $id=strip_tags(trim($_POST['id']));	
			  $upd="update maincategory set 
												maincat_name=:maincat_name
												where maincat_id=:id";
		$stmt=$db->prepare($upd);
		$stmt->bindValue(":maincat_name",$maincat_name,PDO::PARAM_STR);
		$stmt->bindValue(":id",$id,PDO::PARAM_INT);
		$stmt->execute();
		$db->commit();
		$v=5;
	}
	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=6;
		   }
	
}
else
{
  
	$sql="select maincat_name from maincategory where maincat_name=:maincat_name";
	$stmt=$db->prepare($sql);  
	$stmt->bindValue(":maincat_name",$maincat_name,PDO::PARAM_STR);
	$stmt->execute();
	$cnt=$stmt->rowCount();
	
	if($cnt==0)
	{
		
			try
			{
			$db->beginTransaction();
	 $ins="insert into maincategory (maincat_name)		values
															(
																:maincat_name
															)";
$stmt=$db->prepare($ins);
				
				$stmt->bindValue(":maincat_name",$maincat_name,PDO::PARAM_STR);
				$stmt->execute();
				$db->commit();
				$v=3;
			}
		 	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=4;
		   }
		
	}
	else
	{
	$v=2;	
	}
  
	  
	  
}
echo $v
?>