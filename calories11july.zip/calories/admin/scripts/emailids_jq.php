<?php
include("../../config/dbpdo.php");
include("../../config/constants.php");

$group_id=strip_tags(trim($_POST['group_id']));
?>

<?php 
if($group_id==1)
{
	$sql="select * from dsm where status=1";
	$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	$emailids[]=trim($row['email_id']);
	}
	$imp_emailids=implode(",",$emailids);
}
else if($group_id==2)
{
$sql="select * from csm where status=1";
$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	$emailids[]=trim($row['email_id']);
	}
	$imp_emailids=implode(",",$emailids);
}
else if($group_id==3)
{
$sql="select * from psp where status=1";
$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	$emailids[]=trim($row['email_id']);
	}
	$imp_emailids=implode(",",$emailids);
}
else if($group_id==4)
{
$sql="select * from users where user_type=2 and status=1";
$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	$emailids[]=trim($row['user_email']);
	}
	$imp_emailids=implode(",",$emailids);
}
else if($group_id==5)
{
$sql="select * from shopusers where status=1";
$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	$emailids[]=trim($row['user_email']);
	}
	$imp_emailids=implode(",",$emailids);
}
else if($group_id==6)
{
$sql="select * from users where user_type=1 and status=1";
$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	$emailids[]=trim($row['user_email']);
	}
	$imp_emailids=implode(",",$emailids);
}
else
{
$imp_emailids="";
}
	

?>
 <textarea class="form-control" name="email_ids" id="email_ids" cols="100" rows="10"><?php echo $imp_emailids;;?></textarea>
							