<?php
include("../../config/dbpdo.php");
include("../includes/common_functions.php");
$val1=strip_tags(trim($_POST['val1']));
$val2=strip_tags(trim($_POST['val2']));	
//echo $sql="select * from admin where user_name='".$val1."' and pwd='".$val2."'";
if(empty($val1) || empty($val2))
{
echo 1;
}
	try
	{
		$db->beginTransaction();
		
		  $sql="select * from admin where user_name=? and pwd=?";
		$stmt=$db->prepare($sql);  
		$stmt->bindValue(1,$val1,PDO::PARAM_STR);
		$stmt->bindValue(2,$val2,PDO::PARAM_STR);
		$stmt->execute();
		$cnt=$stmt->rowCount();
		if($cnt==1)
		{       session_start();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$_SESSION['sessionadmin_name']=$row['user_name'];
			$_SESSION['sessionadmin_id']=$row['user_id'];
			$_SESSION['role_id']=$row['role_id'];
			echo 2;	
		}
		else
		{
		echo '3';	
		}
		$db->commit();
	}
		 	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				echo 4;
		   }
?>
