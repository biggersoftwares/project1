<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");

//  To dispaly count

$cnt_sql0=mysql_query("select * from invoice");
$cnt_total=mysql_num_rows($cnt_sql0);

$cnt_sql1=mysql_query("select * from invoice where order_status='New'");
$cnt_new=mysql_num_rows($cnt_sql1);

$cnt_sql2=mysql_query("select * from invoice where order_status='Completed'");
$cnt_completed=mysql_num_rows($cnt_sql2);

$cnt_sql3=mysql_query("select * from invoice where order_status='Failed'");
$cnt_failed=mysql_num_rows($cnt_sql3);

$cnt_sql4=mysql_query("select * from invoice where order_status='Cancelled'");
$cnt_cancelled=mysql_num_rows($cnt_sql4);

$cnt_sql5=mysql_query("select * from invoice where order_status='Inprocess'");
$cnt_inprocess=mysql_num_rows($cnt_sql5);


$cnt_sql6=mysql_query("select * from dispatch_orders where status=1");
$cnt_dispatch=mysql_num_rows($cnt_sql6);

$cnt_sql7=mysql_query("select * from dispatch_orders where status=0");
$cnt_undispatch=mysql_num_rows($cnt_sql7);

// -------------------------------------------------------------------------
    $sql="select * from dispatch_orders order by dispatch_id DESC";
	$stmt=mysql_query($sql);
	$norows=mysql_num_rows($stmt);
   

?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
		
		
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        All Dispath Orders
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dispath Orders</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									  <table  class="table" style="width:99%;">
		<tr><th>Total </th><td><?php echo $cnt_total;?></td><th>New</th><td><font color="#FE5E0A"><?php echo $cnt_new;?></font></td> <th>InProcess</th><td><?php echo $cnt_inprocess;?></td><th>Fail</th><td><?php echo $cnt_failed;?></td><th>Cancel</th><td>	<?php echo $cnt_cancelled; ?></td><th>Completed</th><td>	<font color="#0000FF"><?php echo $cnt_completed; ?></font></td><th> Un Dispatch</th><td>	<font color="#FE5E0A"><?php echo $cnt_undispatch; ?></font></td><th>Dispatch</th><td>	<font color="#0000FF"><?php echo $cnt_dispatch; ?></font></td></tr>
							</table>
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
										   <th>Slno </th>
										   <th>Order Id / Txn ID  </th>
						
						<th> Order / Dispatch Date </th>
						
						<th>Details / Tracking Url</th>
						
						
						<th>Status</th>	
						<td>Dispatch</td>
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					$sl=1; 
			  while($row= mysql_fetch_array($stmt))
			  {
			
				   $sql3="select * from invoice  where invoice_id=".$row['invoice_id'];
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
			  extract($row3);		  

	   
	  
	
	if($payment_status=='Pending' &&  $payment_method=='NEFT')
	{
	$paystatus='<font color="red">'.$payment_status.'</font>';
	}
	else if($payment_status=='Success')
	{
	$paystatus='<font color="#0000FF">'.$payment_status.'</font> </a>	';
	}
	else
	{
	$paystatus=$payment_status;
	}
	
	if($payment_method=='NEFT')
	{
	$paymethod='<font color="#000000">'.$payment_method.'</font>';
	}
	else
	{
	$paymethod='<font color="#0000FF">'.$payment_method.'</font>';
	}
	
	if($order_status=='New')
	{
	$ordstat='<b><font color="#990033">'.$order_status.'</font></b>';
	}
	else if($order_status=='Completed')
	{
	$ordstat='<font color="#0000FF">'.$order_status.'</font>';
	}
	else
	{
	$ordstat=$order_status;
	}
	
	
	if($row['status']==1)
  $sta='active.png';
  else
  $sta='inactive.png';
  
  if($row['dispatch_date']!="")
  $disp_date='<font color="#0000FF">'.date("jS F, Y", strtotime($row['dispatch_date'])).'</font>';
  else
  $disp_date='';
	 ?>
	
			
					<tr>
                  
						<td><?php echo $sl;?></td>
						<td>#<?php echo $invoice_id;?><br>
						#<?php echo $transaction_id;?></td>
						<td><?php echo date("jS F, Y", strtotime($invoice_date)); ?><br>
						<?php echo $disp_date; ?></td>
						<td><?php echo $row['docket_number'] ;?><br>
						<?php echo $row['courier_company'] ;?><br>
						<?php echo $row['tracking_url'];?></td>
						<td><img src="images/<?php echo $sta; ?>" border="0" /></td>

  <td><a href="dispatch_details.php?id=<?php echo $invoice_id; ?>"  class="btn btn-xs btn-primary"> <i class="glyphicon glyphicon-eye-open"></i> Dispatch</a></td>
					</tr>
				<?php
				$sl++;
			  }  
			  ?>
                                        </tbody>
                                    </table>
									</FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2,3,4,5] },{'bSortable': false, 'aTargets': [ 4,5 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 50
    
 
} );
 } );

    
</script> 

    </body>
</html>
