<?php 
include("../config/db_connection.php");
include("../config/constants.php");
include("includes/functions.php");
include("includes/loginsession_loginonly.php");
if(isset($_POST['submit']))
{

$nutritionprod_name=addslashes(trim($_POST['nutritionprod_name']));
$calories=addslashes(trim($_POST['calories']));
if($_POST['act']=='UPDATE')
{
			 $id=strip_tags(trim($_POST['id']));	
			  $upd="update nutrition_products set 
												nutritionprod_name='".$nutritionprod_name."',
												calories='".$calories."'
												where nutritionprod_id=".$id;
		$res=mysql_query($upd);
		
		$lid=$id;
		
		$del1="delete from nutrition_products_category where nutritionprod_id=".$id;
		mysql_query($del1);
		$del2="delete from burncalorie_products_category where nutritionprod_id=".$id;
		mysql_query($del2);
		
		$nutritions=$_POST['nutritions'];
		for($k=0;$k<count($nutritions); $k++)
		{
		 $v1="ncval_".$k;
		 $val1=$_POST[$v1];
		
		 $v2="ncpercentage_".$k;
		
		 $val2=$_POST[$v2];
		
		 $sql1="select * from nutrition_products_category where nutritionprod_id='".$lid."' and nutritioncat_id='".$nutritions[$k]."'";
	$res1=mysql_query($sql1);
							if(mysql_num_rows($res1)==0)
							{
							  $ins="insert into nutrition_products_category
									 (
										 nutritionprod_id,
										 nutritioncat_id,
										 val1,
										 val2
									 )
									values
									(
										'".$lid."',
										'".$nutritions[$k]."',
										'".$val1."',
										'".$val2."'
									)";
							mysql_query($ins);
							
							}
		}// for
		
		
		$burncalories=$_POST['burncalories'];
		for($p=0;$p<count($burncalories); $p++)
		{
		$v3="bcval_".$p;
		$val3=$_POST[$v3];
		
		$sql1="select * from burncalorie_products_category where nutritionprod_id='".$lid."' and burncaloriecat_id='".$burncalories[$p]."'";
	$res1=mysql_query($sql1);
							if(mysql_num_rows($res1)==0)
							{
							  $ins="insert into burncalorie_products_category
									 (
										 nutritionprod_id,
										 burncaloriecat_id,
										 val1
									 )
									values
									(
										'".$lid."',
										'".$burncalories[$p]."',
										'".$val3."'
									)";
							mysql_query($ins);
							
							}
		}// for
		
		}
else
{
  
	$sql="select nutritionprod_name from nutrition_products where nutritionprod_name='".$nutritionprod_name."'";
	$res=mysql_query($sql);
	$cnt=mysql_num_rows($res);
	
	if($cnt==0)
	{
		
	 $ins="insert into nutrition_products (nutritionprod_name,calories)		values
															(
																'".$nutritionprod_name."',
																'".$calories."'
															)";
															
		$res=mysql_query($ins);
		
		$lid=mysql_insert_id();
		
		$nutritions=$_POST['nutritions'];
		for($k=0;$k<count($nutritions); $k++)
		{
		$v1="ncval_".$k;
		$val1=$_POST[$v1];
		
		$v2="ncpercentage_".$k;
		$val2=$_POST[$v2];
		
		$sql1="select * from nutrition_products_category where nutritionprod_id='".$lid."' and nutritioncat_id='".$nutritions[$k]."'";
	$res1=mysql_query($sql1);
							if(mysql_num_rows($res1)==0)
							{
							 $ins="insert into nutrition_products_category
									 (
										 nutritionprod_id,
										 nutritioncat_id,
										 val1,
										 val2
									 )
									values
									(
										'".$lid."',
										'".$nutritions[$k]."',
										'".$val1."',
										'".$val2."'
									)";
							mysql_query($ins);
							}
		}// for
		
		
		$burncalories=$_POST['burncalories'];
		for($k=0;$k<count($burncalories); $k++)
		{
		$v3="bcval_".$k;
		$val3=$_POST[$v3];
		
		$sql1="select * from burncalorie_products_category where nutritionprod_id='".$lid."' and burncaloriecat_id='".$burncalories[$k]."'";
	$res1=mysql_query($sql1);
							if(mysql_num_rows($res1)==0)
							{
							 $ins="insert into burncalorie_products_category
									 (
										 nutritionprod_id,
										 burncaloriecat_id,
										 val1
									 )
									values
									(
										'".$lid."',
										'".$burncalories[$k]."',
										'".$val3."'
									)";
							mysql_query($ins);
							}
		}// for
		
	}// if prod name
}// else
if($res)
{
header("Location:nutrition_products.php");
exit;
}
}
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
				  <!--  <script type="text/javascript" src="validations/maincategory.js"></script>-->

    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
           <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Nutrition Products
                       <small><?php
if($_REQUEST['act']=='UPDATE')
{ ?> Update <?php } else { ?> Add New <?php } ?> </small>
                    </h1><span id="resultdiv"></span>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="nutrition_products.php">View Nutrition Products List</a></li>
                       <!--<li class="active">Roles</li>-->
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<?php
if($_REQUEST['act']=='UPDATE')
{
$v=view_nutrition_products($_REQUEST['id']);


}
?>
				<form name="frm" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
				<input type="hidden" name="act" id="act" value="<?php echo $_REQUEST['act'] ; ?>" />
            <input type="hidden" name="id"  id="id" value="<?php echo $_REQUEST['id'] ; ?>" />
			
                    <div class="row">
                       
                        <div class="col-md-9">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Different Width</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                           Product Name                                        </div>
                                        <div class="col-xs-7">
             <input type="text" class="form-control" name="nutritionprod_name" id="nutritionprod_name" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['nutritionprod_name']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div>
								
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            Calories                                        </div>
                                        <div class="col-xs-3">
             <input type="text" class="form-control" name="calories" id="calories" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['calories']); ?>" required>
                                        </div>
                                        
                                    </div>
                                </div>
								<div class="box-body">

									<div class="row">

                                        <div class="col-xs-12">

                                         <strong> <font color="#0000FF" size="+1">NUTRITION FACTS</font></strong>

                                        </div>

										</div></div>
								
								<?php
								
								$NC=view_nutrition_category();
								$y=0;
								foreach($NC as $val)
								{
								
								if($_REQUEST['act']=='UPDATE')
								{
								
								 $sel="select * from nutrition_products_category where nutritionprod_id=".$_REQUEST['id']." and nutritioncat_id=".$val['nutritioncat_id'];
								$res_update=mysql_query($sel);
								$row_upd=mysql_fetch_array($res_update);
								}
								?>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            <?php echo $val['nutritioncat_name'];?>                                       </div>
                                        <div class="col-xs-3">
             <input type="text" class="form-control" name="ncval_<?php echo $y;?>" 
			 value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($row_upd['val1']); ?>" >
                                        </div>
										<div class="col-xs-3">
             <input type="text" class="form-control" name="ncpercentage_<?php echo $y;?>" 
			 									 value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($row_upd['val2']); ?>" >
                                        </div>
                                        
                                    </div>
                                </div>
								<input type="hidden" name="nutritions[]" value="<?php echo $val['nutritioncat_id'];?>">
								<?php
								$y++;
								}
								?>
								<div class="box-body">

									<div class="row">

                                        <div class="col-xs-12">

                                         <strong> <font color="#0000FF" size="+1">Burn Calories</font></strong>

                                        </div>

										</div></div>
										<?php
								$BC=view_burncalories_category();
								$z=0;
								foreach($BC as $val)
								{
									if($_REQUEST['act']=='UPDATE')
								{
								
								 $sel1="select * from burncalorie_products_category where nutritionprod_id=".$_REQUEST['id']." and burncaloriecat_id=".$val['burncaloriecat_id'];
								$res_update1=mysql_query($sel1);
								$row_upd1=mysql_fetch_array($res_update1);
								}
								?>
								<div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            <?php echo $val['burncaloriecat_name'];?>                                       </div>
                                        <div class="col-xs-3">
             <input type="text" class="form-control" name="bcval_<?php echo $z;?>" 
			 value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($row_upd1['val1']); ?>" >
                                        </div>
									
                                        
                                    </div>
                                </div>
								<input type="hidden" name="burncalories[]" value="<?php echo $val['burncaloriecat_id'];?>">
								<?php
								$z++;
								}
								?>
								<div class="box-body">
                                    <div class="row">
                                      <div class="col-xs-7">&nbsp;</div>
                                        <div class="col-xs-3">
                                         
										    <?php if($_REQUEST['act']!='UPDATE'){ ?>
						<input type="submit" class="btn btn-success"  name="submit"  value="Add">
					   <?php 
					   }
					   else
					   {
					   ?>
<input type="submit" class="btn btn-success"  name="submit"  value="Update">
					   <?php
					   }
					   ?>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- /.box -->
                        </div>
                       
                    </div>   <!-- /.row -->
					</form>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        
    </body>
</html>
