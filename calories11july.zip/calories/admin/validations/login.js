$( document ).ready(function() {
	
$("#sbtbtn").click(function(){
	
	if($("#val1").val()=="")
	{
		$("#val1").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	if($("#val2").val()=="")
	{
		$("#val2").css({"border": "1px solid","color":"#F00"});
		$("#val1").css({"border": "","color":""});
		return false;
	}

	var dataString = "val1="+$("#val1").val()+"&val2="+$("#val2").val();  
			$.ajax({
				  type: "POST",
				  url: "scripts/login.php",
				  data: dataString,
				  success: function(data)
				  { 
				  if(data==2)
				  {

					$(location).attr('href', 'dashboard.php');
				  }
				   else if(data==3)
				  {
					 $("#val1").val('');
					  $("#val2").val('');
					$("#val2").css({"border": "","color":""});

				   $("#resultdiv").html('<font color="#FE5E0A">Invalid user or password</font>');
				  }
				   else  if(data==4)
				  {
				   $(location).attr('href', 'index.php');
				  }
				  else				   
				  {
				   $("#resultdiv").html('<font color="#FE5E0A">Fill all the  fields</font>');
				   $("#val1").val('');
					$("#val2").val('');
					$("#val2").css({"border": "","color":""});
				  }
				   
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
			});
			

});