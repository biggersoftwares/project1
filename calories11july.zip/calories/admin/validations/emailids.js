$( document ).ready(function() {
			
			$("#group_id").change(function(){

	var dataString = "group_id="+$("#group_id").val();  
			$.ajax({
				  type: "POST",
				  url: "scripts/emailids_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				   $("#emailidsspan").html(data);
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});		

});