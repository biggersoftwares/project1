$( document ).ready(function() {
	
$("#sbtbtn").click(function(){
	
	if($("#role_id").val()=="")
	{
		$("#role_id").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	if($("#user_name").val()=="")
	{
		$("#user_name").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	

	var dataString = "user_name="+$("#user_name").val()+"&pwd="+$("#pwd").val()+"&role_id="+$("#role_id").val()
	+"&user_email="+$("#user_email").val()+"&mobileno="+$("#mobileno").val()
	+"&id="+$("#id").val()+"&page="+$("#page").val()+"&act="+$("#act").val();  
			$.ajax({
				  type: "POST",
				  url: "scripts/subusers.php",
				  data: dataString,
				  success: function(data)
				  { 
				//document.write(data);
				   if(data==2)
				  {
					$("#user_name").css({"border": "1px solid","color":"#F00"});

				   $("#resultdiv").html('<font color="#FF0000">Already Existed.</font>');
				  }
				  else if(data==3)
				  {

					$(location).attr('href', 'subusers.php');
				  }
				  
				   else if(data==4)
				  {

				   $("#resultdiv").html('<font color="#FF0000">Not Inserted.</font>');
				  }
				   else  if(data==5)
				  {
				   $(location).attr('href', 'subusers.php');
				  }
				   else if(data==6)
				  {

				   $("#resultdiv").html('<font color="#FF0000">Not Updated.</font>');
				  }
				  else				   
				  {
				   $("#resultdiv").html('<font color="#FF0000">Fill all the  fields</font>');
				   $("#role_id").val('');
					$("#user_name").val('');
					$("#role_id").css({"border": "","color":""});
				  }
				   
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
			});
			

});