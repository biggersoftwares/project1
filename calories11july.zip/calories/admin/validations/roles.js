$( document ).ready(function() {
	
$("#sbtbtn").click(function(){
	
	if($("#role_name").val()=="")
	{
		$("#role_name").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	
	//var page=$("#tablename").val()+".php";

	var dataString = "role_name="+$("#role_name").val()+"&id="+$("#id").val()+"&act="+$("#act").val(); 
			$.ajax({
				  type: "POST",
				  url: "scripts/roles.php",
				  data: dataString,
				  success: function(data)
				  { 
				   if(data==2)
				  {
					$("#role_name").css({"border": "1px solid","color":"#F00"});

				   $("#resultdiv").html('<font color="#FF0000">Already Existed.</font>');
				  }
				  else if(data==3)
				  {

					$(location).attr('href', 'roles.php');
				  }
				  
				   else if(data==4)
				  {

				   $("#resultdiv").html('<font color="#FF0000">Not Inserted.</font>');
				  }
				   else  if(data==5)
				  {
				   $(location).attr('href', 'roles.php');
				  }
				   else if(data==6)
				  {

				   $("#resultdiv").html('<font color="#FF0000">Not Updated.</font>');
				  }
				  else				   
				  {
				   $("#resultdiv").html('<font color="#FF0000">Fill all the  fields</font>');
				   $("#role_name").val('');
					$("#role_name").css({"border": "","color":""});
				  }
				   
				   
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
			});
			

});