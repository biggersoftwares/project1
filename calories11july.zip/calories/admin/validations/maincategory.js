$( document ).ready(function() {
	
$("#sbtbtn").click(function(){
	//alert("pavan");
	if($("#maincat_name").val()=="")
	{
		$("#maincat_name").css({"border": "1px solid","color":"#F00"});
		return false;
	}
	var sval=$("#maincat_name").val();
	var val=sval.replace('&','_');
	//var page=$("#tablename").val()+".php";

	var dataString = "maincat_name="+val+"&id="+$("#id").val()+"&act="+$("#act").val(); 
	//alert(dataString);
			$.ajax({
				  type: "POST",
				  url: "scripts/maincategory.php",
				  data: dataString,
				  success: function(data)
				  { 
				   // alert(data);
				 document.write(data);
				   if(data==2)
				  {
					$("#maincat_name").css({"border": "1px solid","color":"#F00"});

				   $("#resultdiv").html('<font color="#FE5E0A">Already Existed.</font>');
				  }
				  else if(data==3)
				  {

					$(location).attr('href', 'maincategory.php');
				  }
				  
				   else if(data==4)
				  {

				   $("#resultdiv").html('<font color="#FE5E0A">Not Inserted.</font>');
				  }
				   else  if(data==5)
				  {
				   $(location).attr('href', 'maincategory.php');
				  }
				   else if(data==6)
				  {

				   $("#resultdiv").html('<font color="#FE5E0A">Not Updated.</font>');
				  }
				  else				   
				  {
				   $("#resultdiv").html('<font color="#FE5E0A">Fill all the  fields</font>');
				   $("#maincat_name").val('');
					$("#maincat_name").css({"border": "","color":""});
				  }
				   
				   
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
			});
			

});