<?php
error_reporting(0);
session_start();
$Base_dir="calories";

if($_SERVER['SERVER_NAME']=='localhost')
{
	define('SITE_URL',"http://".$_SERVER['SERVER_NAME']."/".$Base_dir."/");
	define('ADMIN_URL',"http://".$_SERVER['SERVER_NAME']."/".$Base_dir."/admin/");
}
else
{
	define('SITE_URL',"http://".$_SERVER['SERVER_NAME']."/demos/".$Base_dir."/");
	define('ADMIN_URL',"http://".$_SERVER['SERVER_NAME']."/demos/".$Base_dir."/admin/");
}
	define('DBEXT',"");

?>
