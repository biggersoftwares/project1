<?php 
php_ob();
session_start();
error_reporting(0);
if($_SERVER['SERVER_NAME']=='localhost')
{
define('DB_SERVER', 'localhost');

define('DB_USERNAME', 'root');

define('DB_PASSWORD', '');

define('DB_DATABASE', 'calories');
}
else
{
define('DB_SERVER', 'localhost');

define('DB_USERNAME', 'arkaitso_fit');

define('DB_PASSWORD', 'fit@1234');

define('DB_DATABASE', 'arkaitso_fit_revolution');
	
// cpanel details

// user name  : wbilprxp

// password : A28VRM5rQKG96

//propfirs_root
//LOxxOWBsS^_K
	
}
$connection = mysql_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
$database = mysql_select_db(DB_DATABASE);

if($_SERVER['SERVER_NAME']=='localhost')
{
$dsn = 'mysql:host=localhost;dbname=calories';
$username = 'root';
$password = '';
}
else
{
$dsn = 'mysql:host=localhost;dbname=arkaitso_fit_revolution';
$username = 'arkaitso_fit';
$password = 'fit@1234';
}
/*$options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
);*/
//$db = new PDO($dsn, $username, $password,$options);
$db = new PDO($dsn, $username, $password);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

?>
