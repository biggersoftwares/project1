<?php 
include("../config/db_connection.php");
include("../config/constants.php");
include("includes/functions.php");
include("includes/loginsession_onlylogin.php");
?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>
				    <script type="text/javascript" src="validations/roles.js"></script>

    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
           <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Roles
                       <small><?php
if($_REQUEST['act']=='UPDATE')
{ ?> Update <?php } else { ?> Add New <?php } ?> </small>
                    </h1><span id="resultdiv"></span>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
						<li><a href="roles.php">View Roles List</a></li>
                       <!--<li class="active">Roles</li>-->
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<?php
if($_REQUEST['act']=='UPDATE')
{
$v=view_roles($_REQUEST['id']);


}
?>
				<form name="frm" method="post">
				<input type="hidden" name="act" id="act" value="<?php echo $_REQUEST['act'] ; ?>" />
            <input type="hidden" name="id"  id="id" value="<?php echo $_REQUEST['id'] ; ?>" />
			
                    <div class="row">
                       
                        <div class="col-md-6">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Different Width</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-2">
                                            Name                                        </div>
                                        <div class="col-xs-7">
             <input type="text" class="form-control" name="role_name" id="role_name" value="<?php if($_REQUEST['act']=='UPDATE') echo stripslashes($v[0]['role_name']); ?>" required>
                                        </div>
                                        <div class="col-xs-2">
                                         
										   <?php if($_REQUEST['act']!='UPDATE'){ ?>
                        <button id="sbtbtn" name="button1id" class="btn btn-primary">Add </button>
					   <?php 
					   }
					   else
					   {
					   ?>
					   <button id="sbtbtn" name="button1id" class="btn btn-primary">Update</button>

					   <?php
					   }
					   ?>
                                        </div>
                                    </div>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                       
                    </div>   <!-- /.row -->
					</form>
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        
    </body>
</html>
