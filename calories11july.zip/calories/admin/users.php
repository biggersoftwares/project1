<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("includes/loginsession.php");
include("includes/functions.php");
$vState=view_states();

if($_POST['act']=='deleteall')
{
	$values=implode(",",$_REQUEST['id']);	 
	try
	{
		$db->beginTransaction();
		$sql="delete from users where  user_id IN ($values)";
		$stmt=$db->prepare($sql);
		$stmt->execute();
		
		$sql2="delete from bill_ship_address where  user_id IN ($values)";
		$stmt2=$db->prepare($sql2);
		$stmt2->execute();
		
		
	$db->commit();
	$msg="selected record(s) are deleted";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
}


if($_POST['act']=='activeall')
{
 $values=implode(",",$_REQUEST['id']);	 

	$stat=1;
	
	try
	{
		$db->beginTransaction();
		 $sql="update users set status=? where user_id IN ($values)";
		$stmt=$db->prepare($sql);
		$stmt->bindValue(1,$stat,PDO::PARAM_INT);
		$stmt->execute();
	$db->commit();
	$msg="selected record(s) are activated";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
	
}
if($_POST['act']=='inactiveall')
{
 $values=implode(",",$_REQUEST['id']);	 
 $stat=0;
	
	try
	{
		$db->beginTransaction();
		  $sql="update users set status=? where user_id IN ($values)";
		$stmt=$db->prepare($sql);
		$stmt->bindValue(1,$stat,PDO::PARAM_INT);
		$stmt->execute();
	$db->commit();
	$msg="selected record(s) are inactivated";
	}
	catch(PDOException $ex)
	{
		//Something went wrong rollback!
		$db->rollBack();
		writeLog($ex->getMessage().'\n'); 
		writeLog($ex->getLine().'\n'); 
	}
	
}


	$sql="select * from users  where user_id!=0 ";
if($_POST['act']=='SEARCH')
{
	$schedule_dates=strip_tags(trim($_POST['schedule_dates']));
	if($schedule_dates!="")
	{
	$dexp=explode("-",$schedule_dates);
	$from_date=$dexp[0]."-".$dexp[1]."-".$dexp[2];
	$to_date=$dexp[3]."-".$dexp[4]."-".$dexp[5];
	$sql .=" and register_date between '".trim($from_date)."' and '".trim($to_date)."'";
	}
}

$sql .=" order by user_id DESC";
$stmt=mysql_query($sql);


?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
	 <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />	
		<script language="javascript" type="text/javascript">
function validateedit()
{
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("To Edit , Please select respective check box");
		return false;
	}
	else if(cnt > 1)
	{
		alert("Please select only one checkbox");
		return false;
	}
	
	var idval=get_editval();
	
	document.frmedit.id.value=+idval;
	document.frmedit.act.value="UPDATE";
	document.frmedit.submit();
}

function activate_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Activeate!");
		return false;
	}
	frm.act.value="activeall";
	frm.submit();
}
function inactivate_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to InActivate!");
		return false;
	}
	frm.act.value="inactiveall";
	frm.submit();
}
function catdelete_all()
{
frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Delete!");
		return false;
	}
	else
	{
	var retVal = confirm("Do you want to continue ?");
   if( retVal == true )
   {
     // alert("User wants to continue!");
	  //return true;
	  frm.act.value="deleteall";
	frm.submit();
   }
   else   
   {
      //alert("User does not want to continue!");
	  return false;
   }
   	}
	
}
function validateview()
{
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("To  View, Please select respective check box");
		return false;
	}
	else if(cnt > 1)
	{
		alert("Please select only one checkbox");
		return false;
	}
	
	var idval=get_editval();
	
	document.frmview.id.value=+idval;
	document.frmview.submit();
}

function get_checked()
{
	frm=document.pform;
		var i=0;
		k=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					k++;
				}
			}
		}
		return k;
}

function get_editval()
{
	frm=document.pform;
		var i=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					{
					var edit=frm.elements[i].value;
					}
				}
			}
		}
		return edit;
}
function catAll(e1) 
 {
	 frm=document.pform;
 // alert(frm.elements.length);
	j=0	
  for (var i=0;i<frm.elements.length;i++) 
   {
    if (frm.elements[i].name.substring(0,2)=='id') 
     {
	 j++
     frm.elements[i].checked=e1.checked?true:j==0?true:false;
     //alert(i); 
     }
   }
}  
</script>
<script language="javascript">

$( document ).ready(function() {

	
			$("#state_id").change(function(){

	var dataString = "state_id="+$("#state_id").val();  
			$.ajax({
				  type: "POST",
				  url: "scripts/districts_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				   $("#districtsdiv").html(data);
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});	
	$("#district_id").change(function(){

	var dataString = "state_id="+$("#state_id").val()+"&district_id="+$("#district_id").val();  
			$.ajax({
				  type: "POST",
				  url: "scripts/constituency_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				   $("#constituencydiv").html(data);
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});			

});
</script>
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		    <!-- DATA TABLES -->
        <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        All Users
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">All Users</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
<FORM name="pform1" method="post" action="#">
       <input type="hidden" name="act" value="SEARCH" />
							<div class="col-md-12">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
									 <div class="col-xs-1">
                                        RegDate          </div>
                                        <div class="col-xs-9"><div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" id="reservation" name="schedule_dates" value="<?php echo $_POST['schedule_dates'];?>"/>
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
                                        </div>
                                         
										
                                    </div>
                                </div><!-- /.box-body -->
								 
								
								 
								  
                            </div><!-- /.box -->

                        </div>
						</FORM>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									 <div class="con-rt-head">
									<?php /*?><a href="users_manage.php" class="btn btn-xs btn-primary"  ><span class="glyphicon glyphicon-plus"></span> Add New</a>&nbsp;
          		<a href="#" class="btn btn-xs btn-info" onClick="return validateedit()" ><span class="glyphicon glyphicon-edit"></span> Edit</a> <?php */?>
				&nbsp;&nbsp;<a href="#" onClick="return activate_all()" class="btn btn-xs btn-success" > <i class="glyphicon glyphicon-ok"></i> Active</a>
				&nbsp;<a href="#" onClick="return inactivate_all()" class="btn btn-xs btn-warning" > <i class="glyphicon glyphicon-off"></i> In Active</a>		
				
				&nbsp;<a href="#" onClick="return catdelete_all()" class="btn btn-xs btn-danger" > <i class="glyphicon glyphicon-trash"></i> Delete</a>
							</div>
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
				
       <input type="hidden" name="act" value="" />
                                 <table id="example" class="table table-bordered table-striped" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
										    <th> SNO </th>
																	<th> Name </th>
						<th> Mobile no </th>
						<th> Email Id </th>
						<th> Reg Date </th>
						<th>Status</th>	
						<th><INPUT type="checkbox" onClick="return catAll(this)" class="icheckbox_minimal"  id="checkall" name="checkall">&nbsp;
                        <i class="glyphicon glyphicon-check"></i></th>
						
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
										$s=1;
					 
			   while($row= mysql_fetch_array($stmt))
			  {
				  extract($row);
				  
				    
	
	 if($status==1)
				  $sta='active.png';
				  else
				  $sta='inactive.png';
				  
				  if($user_type==1)
				  $type='Direct';
				  else
				  $type='E User';
				  
	 ?>
				
					<tr>
					<td><?php echo $s;?></td>  
						<td><?php echo ucfirst(stripslashes($user_name));?> </td>
						<td><?php echo stripslashes($mobileno);?></td>
						<td><?php echo stripslashes($user_email);?><br><font color="#FE5E0A"><?php echo $pwd;?></font></td>
							
					
						
							<td><?php echo date("d-m-Y", strtotime($register_date)); ?></td>
						
							<td><img src="images/<?php echo $sta; ?>" border="0" /></td>
  <td > <input name="id[]" type="checkbox"  class="icheckbox_minimal"  value="<?php echo $user_id; ?>" /></td>
					</tr>
				<?php
				$s++;
			  }  
			  ?>
                                        </tbody>
                                    </table>
									</FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2,3,4,5,6] },{'bSortable': false, 'aTargets': [0,1,4,5,6] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 50
    
 
} );
 } );

    
</script> 

        <script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
       
        <script type="text/javascript">
            $(function() {
			
			 //Date range picker
                $('#reservation').daterangepicker({format: 'DD-MM-YYYY'});
        
     
            });
        </script>

    </body>
</html>
