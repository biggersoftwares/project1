<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");



$sql="select * from invoice where invoice_id!=0 ";
if($_POST['act']=='SEARCH')
{
	$schedule_dates=strip_tags(trim($_POST['schedule_dates']));
	if($schedule_dates!="")
	{
	$dexp=explode("-",$schedule_dates);
	$from_date=$dexp[0]."-".$dexp[1]."-".$dexp[2];
	$to_date=$dexp[3]."-".$dexp[4]."-".$dexp[5];
	$sql .=" and invoice_date between '".trim($from_date)."' and '".trim($to_date)."'";
	}
	
	if($_POST['order_status']!="")
	{
	$sql .= " and order_status='".$_POST['order_status']."'";
	}
}

$sql .=" order by invoice_id DESC";
//echo $sql;
$stmt=mysql_query($sql);
$norows=mysql_num_rows($stmt);
   

?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
		
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Sales Report
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Reports</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
				<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="SEARCH" />
							<div class="col-md-12">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Input masks</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
									 <div class="col-xs-1">
                                          Date          </div>
                                        <div class="col-xs-7"><div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" id="reservation" name="schedule_dates" value="<?php echo $_POST['schedule_dates'];?>"/>
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
                                        </div>
                                         <div class="col-xs-2">
                                          <select class="form-control" name="order_status" id="order_status">
										  <option value="">Order Satatus</option>
                                                <option value="New" <?php if($_POST['order_status']=="New") echo 'selected';?>>New</option>
                                                <option value="Failed" <?php if($_POST['order_status']=="Failed") echo 'selected';?>>Failed</option>
												<option value="Cancelled" <?php if($_POST['order_status']=="Cancelled") echo 'selected';?>>Cancelled</option>
												<option value="Inprocess" <?php if($_POST['order_status']=="Inprocess") echo 'selected';?>>Inprocess</option>
												<option value="Completed" <?php if($_POST['order_status']=="Completed") echo 'selected';?>>Completed</option>
                                                
                                            </select>        </div>
										  <div class="col-xs-2">
                                         <input type="submit" name="submit" class="btn btn-primary" value="Search">    </div>
                                    </div>
                                </div><!-- /.box-body -->
								 
								
								 
								  
                            </div><!-- /.box -->

                        </div>
						</FORM>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
							
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									 
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
										    <th>Slno </th>
										   <th>Ord /Txn ID </th>
						<th> Full Name </th>
						<th> Order / Dispatch Date </th>
						<th> Status </th>
						<th> Amount </th>
						<th>Pay Status</th>
						<th>Pay Method</th>			
						
						<td>View</td>
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					$sl=1; 
					$total =0;
			  while($row= mysql_fetch_array($stmt))
			  {
				  extract($row);
				  $sql3="select * from bill_ship_address  where user_id=".$user_id;
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
				  
	
	
	   $sql2="select * from state  where state_id=".$row3['s_state'];
	$stmt2=$db->prepare($sql2);	
	$stmt2->execute();
	$row2= $stmt2->fetch(PDO::FETCH_ASSOC);
				  
				   
		$sql_orders="select * from orders where invoice_id=".$invoice_id;
$res_orders=mysql_query($sql_orders);
$items=mysql_num_rows($res_orders);		  
	
	if($payment_status=='Pending' &&  $payment_method=='NEFT')
	{
	$paystatus='<a href="orders.php?invoice_id='.$invoice_id.'&paystatus=Success" title="Change to Success"> <font color="red">'.$payment_status.'</font> </a>	';
	}
	else if($payment_status=='Success')
	{
	$paystatus='<font color="#0000FF">'.$payment_status.'</font> </a>	';
	}
	else
	{
	$paystatus=$payment_status;
	}
	
	if($payment_method=='NEFT')
	{
	$paymethod='<font color="#000000">'.$payment_method.'</font>';
	}
	else
	{
	$paymethod='<font color="#0000FF">'.$payment_method.'</font>';
	}
	
	if($order_status=='New')
	{
	$ordstat='<b><font color="#990033">'.$order_status.'</font></b>';
	}
	else if($order_status=='Completed')
	{
	$ordstat='<font color="#0000FF">'.$order_status.'</font>';
	}
	else
	{
	$ordstat=$order_status;
	}
	
	 $sql4="select * from dispatch_orders  where invoice_id=".$invoice_id;		
	$stmt4=$db->prepare($sql4);	
	$stmt4->execute();
	$row4= $stmt4->fetch(PDO::FETCH_ASSOC);	   
	 if($row4['dispatch_date']!="")
  $disp_date='<font color="#0000FF">'.date("jS F, Y", strtotime($row4['dispatch_date'])).'</font>';
  else
  $disp_date='';
	 ?>
	
					<tr>
                  
						<td><?php echo $sl;?></td>
						<td>#<?php echo $invoice_id;?><br>
						#<?php echo $transaction_id;?></td>
						<td><?php echo $row3['s_firstname']." ".$row3['s_lastname'];?></td>
						<td><?php echo date("jS F, Y", strtotime($invoice_date)); ?><br>
						<?php echo $disp_date; ?></td>
						<td><?php echo $ordstat;?></td>
						<td><?php echo number_format($total_amount, 2, '.', '');?></span> for <?php echo $items;?> item(s)</td>					
						<td><?php echo $paystatus;?></td>
						<td><?php echo $paymethod;?></td>
  <td><a href="order_details.php?id=<?php echo $invoice_id; ?>"  class="btn btn-xs btn-primary" target="_blank"> <i class="glyphicon glyphicon-eye-open"></i> Invoice</a></td>
					</tr>
				<?php
				$sl++;
				$total +=number_format($total_amount, 2, '.', '');
			  }  
			  ?>
                                        </tbody>
                                    </table>
									
									 <table class="table table-bordered table-hover table-responsive" > 
									 <tr ><td align="center"><strong>Total Amount : </strong>&nbsp;Rs.&nbsp;<font color="#FE5E0A"><?php echo number_format($total, 2, '.', '');?></font></td></tr>
									 </table>
									
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
	<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1,2,3,4,5,6,7,8] },{'bSortable': false, 'aTargets': [ 8 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 50
    
 
} );
 } );

    
</script> 

        <script src="js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
       
        <script type="text/javascript">
            $(function() {
			
			 //Date range picker
                $('#reservation').daterangepicker({format: 'YYYY-MM-DD'});
                //Date range picker with time picker
                $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
				
				 //iCheck for checkbox and radio inputs
                $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
                    checkboxClass: 'icheckbox_minimal',
                    radioClass: 'iradio_minimal'
                });
                //Red color scheme for iCheck
                $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
                    checkboxClass: 'icheckbox_minimal-red',
                    radioClass: 'iradio_minimal-red'
                });
				 //Flat red color scheme for iCheck
                $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
                    checkboxClass: 'icheckbox_flat-red',
                    radioClass: 'iradio_flat-red'
                });
     
            });
        </script>

    </body>
</html>
