<?php 
include("../config/db_connection.php");
include("includes/loginsession.php");
include("includes/functions.php");
include("../config/constants.php");

 $sql_completed="select * from invoice where  order_status=3";
  $res_completed=mysql_query($sql_completed);
  $completed=mysql_num_rows($res_completed);


 $sql_new="select * from invoice where  order_status=1";
  $res_new=mysql_query($sql_new);
  $new=mysql_num_rows($res_new);
  
  
 $sql_inprocess="select * from invoice where  order_status=2";
  $res_inprocess=mysql_query($sql_inprocess);
  $inprocess=mysql_num_rows($res_inprocess);
  
  
  $cnt_sql=mysql_query("select * from products where status=0");
$products_inactive=mysql_num_rows($cnt_sql);

  $cnt_sql=mysql_query("select * from products where status=1");
$products_active=mysql_num_rows($cnt_sql);



$cnt_sql=mysql_query("select * from users where status=0");
$users_inactive=mysql_num_rows($cnt_sql);

$cnt_sql=mysql_query("select * from users where status=1");
$users_active=mysql_num_rows($cnt_sql);




?>
<!DOCTYPE html>
<html>
    <head>
                   <?php include("includes/metatags.php"); ?>

    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
                       <?php include("includes/header.php"); ?>

        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
               <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Dashboard
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Main Dashboard</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
<div class="row">
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3>
                                        <?php echo $new;?>
                                    </h3>
                                    <p>
                                        New Orders
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="orders_new.php" class="small-box-footer" target="_blank">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3>
                                        <?php echo $inprocess;?>
                                    </h3>
                                    <p>
                                       In Process Orders
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-stats-bars"></i>
                                </div>
                                <a href="orders_inprocess.php" class="small-box-footer" target="_blank">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3>
                                      <?php echo $completed;?>
                                    </h3>
                                    <p>
                                        Completed Orders
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="orders_completed.php" class="small-box-footer" target="_blank">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3>
                                       <?php echo $products_inactive;?>
                                    </h3>
                                    <p>
                                        Inactive Products
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="products_inactive.php" class="small-box-footer" target="_blank">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                    </div>
					
					<div class="row">
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3>
                                        <?php echo $users_inactive;?>
                                    </h3>
                                    <p>
                                       InActive Users
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-ios7-cart-outline"></i>
                                </div>
                                <a href="users_inactive.php" class="small-box-footer" target="_blank">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3>
                                       <?php echo $users_active;?>
                                    </h3>
                                    <p>
                                      Users List
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-ios7-briefcase-outline"></i>
                                </div>
                                <a href="users_active.php" class="small-box-footer" target="_blank">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        
                    </div>
					
					
                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

    </body>
</html>
