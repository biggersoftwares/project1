<?php
include("../config/dbpdo.php");
include("../config/constants.php");
include("includes/common_functions.php");
include('includes/functions.php');
$msg="";

	if(isset($_POST['Verify']))
{

$sql_sett5="select * from settings where id=5";
$res_sett5=mysql_query($sql_sett5);
$row_sett5=mysql_fetch_array($res_sett5);
$from_mail=$row_sett5['value'];
	$email=  strip_tags(trim($_POST['email']));
	
	$sql="select * from admin where user_email='".$email."'";
		$res=mysql_query($sql);
		$row=mysql_fetch_array($res);
		$num=mysql_num_rows($res);
		if($num==1)
		{

		 $subject = 'Andrew Wommack Ministries India';

// message

 $message = '<div marginheight="0" marginwidth="0">
    	<div style="background-color:#f5f5f5;width:100%;margin:0;padding:70px 0 70px 0">
        	<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
            	<tbody>
                	<tr>
                    <td valign="top" align="center">
						<div></div>
                    	<span class="HOEnZb">
                        	<font color="#888888"></font>
                        </span>
                        <span class="HOEnZb">
                        	<font color="#888888"></font>
                        </span>
                        <table width="600" cellspacing="0" cellpadding="0" border="0" style="border-radius:6px!important;background-color:#fdfdfd;border:1px solid #dcdcdc;border-radius:6px!important">
                        	<tbody>
                            	<tr>
                                	<td valign="top" align="center">
                                		<table width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#557da1" style="background-color:#557da1;color:#ffffff;border-top-left-radius:6px!important;border-top-right-radius:6px!important;border-bottom:0;font-family:Arial;font-weight:bold;line-height:100%;vertical-align:middle">
                                        	<tbody>
                                            	<tr>
                                                	<td>
                                            			<h1 style="color:#ffffff;margin:0;padding:28px 24px;display:block;font-family:Arial;font-size:22px;font-weight:bold;text-align:left;line-height:150%">Welcome to Andrew Wommack Ministries India</h1>

                                            		</td>
                                        		</tr>
                                            </tbody>
                                        </table></td>
                            	</tr>
                                <tr>
                                	<td valign="top" align="center">
                                		<span class="HOEnZb">
                                        	<font color="#888888"></font>
                                        </span>
                                        	<table width="600" cellspacing="0" cellpadding="0" border="0">
                                            	<tbody>
                                                	<tr>
                                                    	<td valign="top" style="background-color:#fdfdfd;border-radius:6px!important">
                                                			<span class="HOEnZb">
                                                            	<font color="#888888"></font>
                                                            </span>
                                                            <table width="100%" cellspacing="0" cellpadding="20" border="0">
                                                            	<tbody>
                                                                	<tr>
                                                                    	<td valign="top">
                                                            				<div style="color:#737373;font-family:Arial;font-size:14px;line-height:150%;text-align:left">
																				<p>Your Password is <strong>'.$row['pwd'].'</strong>.</p>
																				
																				<span class="HOEnZb">
                                                                                	<font color="#888888"></font>
                                                                                </span>
                                                                            </div>
                                                                            <span class="HOEnZb">
                                                                            	<font color="#888888"></font>
                                                                            </span>
                                                                        </td>
                                                                   </tr>
                                                                </tbody>
                                                           </table>
                                                      </td>
                                                  </tr>
                                              </tbody>
                                         </table>
                                   </td>
                               </tr>
                               <tr>
                               	<td valign="top" align="center">
                                	<table width="600" cellspacing="0" cellpadding="10" border="0" style="border-top:0">
                                    	<tbody>
                                        	<tr>
                                            	<td valign="top">
                                                	<table width="100%" cellspacing="0" cellpadding="10" border="0">
                                                    	<tbody>
                                                        	<tr>
                                                            	<td valign="middle" style="border:0;color:#99b1c7;font-family:Arial;font-size:12px;line-height:125%;text-align:center" colspan="2">
                                                        		<p>Andrew Wommack Ministries India</p>
                                                        		</td>
                                                    		</tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                        	</tr>
                                     	</tbody>
                                 	</table>
                             	</td>
                            </tr>
                       </tbody>
                   </table>
                </td>
              </tr>
           </tbody>
       </table>
   </div>
 <div class="yj6qo"></div>
 <div class="adL"></div>
</div>';

$to = $email;
$headers .= 'From: '.FROM_NAME.' <'.$from_mail.'>' . "\r\n";
//$headers .= "Reply-To: ". strip_tags($_POST['cemail']) . "\r\n";
//$headers .= "CC:".strip_tags($businessemail)."\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

// Mail it
mail($to, $subject, $message, $headers);
		$msg = "Password has been sent to your mail id successfully.";
		//header("Location:login_user.php?msg=".$msg);
		//exit;
	}
	else
	{
		$msg = "Wrong  Mail ID ...";
		
	}
	
	
}

?>
<!DOCTYPE html>
<html class="bg-black">
    <head>
       <?php include("includes/metatags.php");?>
	   <script src="js/jquery-2.1.1.min.js"></script>	
<script language="javascript" type="text/javascript">
function trim(s) {
  while (s.substring(0,1) == ' ') {
    s = s.substring(1,s.length);
  }
  while (s.substring(s.length-1,s.length) == ' ') {
    s = s.substring(0,s.length-1);
  }
  return s;
}

function funValidate()
{
frm=document.frmadd;

// Email Validation

if(trim(frm.email.value)=="")
{
alert("Please Enter the Email Address");
frm.email.focus();
return false;
}// email 1




if(trim(frm.email.value)!="")
{
e1=frm.email.value.indexOf('@',0);
e2=frm.email.value.indexOf('.',0);
if((e1==-1)||(e2==-1))
	{
	alert("Enter a valid Email");
	frm.email.focus();
	return(false);
	}// email 1
	
if((frm.email.value.charAt(0)=="@") || frm.email.value.charAt(frm.email.value.length-1)=="@")
{

alert("Should not enter @ (symbol) first and last");
frm.email.focus();
return false;
}//email 2
if((frm.email.value.charAt(0)==".") || frm.email.value.charAt(frm.email.value.length-1)==".")
{

alert("Should not enter . ( dot symbol) first and last");
frm.email.focus();
return false;
}//email 3
}// email 4
// email  validation

return true;
	
}


</script>
    </head>
    <body class="bg-black">

        <div class="form-box" id="login-box">
            <div class="header"><span id="resultdiv"><strong>Admin Panel</strong></span></div>
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" name="frmadd" method="post" onSubmit="return funValidate();">
                <div class="body bg-gray">
                    <div class="form-group">
                  
						 <input type="email" class="form-control"  name="email" value="" maxlength="50" placeholder="Email Id"/>
                    </div>
                          
                   
                </div>
                <div class="footer">  
				<input type="submit" name="Verify" value="Submit" class="btn bg-olive btn-block">                                                             
                    
                    
                    <p><a href="index.php">Login</a></p>  
					<?php
								if($msg!="")
								{
								?>
					<p><?php echo $msg;?></p>  
					<?php
					}
					?>                  
                </div>
            </form>

           
        </div>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>

    </body>
</html>