<?php 
include("../config/dbpdo.php");
include("includes/common_functions.php");
include("../config/constants.php");
include("includes/loginsession.php");
if($_POST['act']=='activeall')
{
 $values=implode(",",$_REQUEST['id']);	 

	$role_id=$_REQUEST['role_id'];
	
	$cnt=count($_REQUEST['id']);
	 $sql="delete from page_permissions where role_id=".$role_id;
	$stmt=$db->prepare($sql);
	$stmt->execute();
	
	$exp=explode(",",$values);
	for($k=0; $k<$cnt; $k++)
	{
	
		try
		{
			$db->beginTransaction();
			  $ins="insert into page_permissions(role_id,page_id)
																values
															(
															'".$role_id."',
															'".$exp[$k]."'
															)";
			$stmt=$db->prepare($ins);
		
			$stmt->execute();
		$db->commit();
		$msg="Success";
		}
		catch(PDOException $ex)
		{
			//Something went wrong rollback!
			$db->rollBack();
			writeLog($ex->getMessage().'\n'); 
			writeLog($ex->getLine().'\n'); 
		}
	}
	
}
try {
    $db->beginTransaction();
	$sql="select * from site_pages  where status=1 order by (sort+0) ASC";		
	$stmt=$db->prepare($sql);	
	$stmt->execute();
	$norows=$stmt->rowCount();
    $db->commit();
} 
catch(PDOException $ex)
{
    //Something went wrong rollback!
    $db->rollBack();
    writeLog($ex->getMessage().'\n'); 
	writeLog($ex->getLine().'\n'); 
}
?>
<!DOCTYPE html>
<html>
    <head>
<?php include("includes/metatags.php");?>
<link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
	 <script language="javascript" type="text/javascript">
function activate_all()
{
	frm=document.pform;
	var cnt=get_checked();
	if(cnt==0)
	{
		alert("Please select atleast one respective check box to Activeate!");
		return false;
	}
	frm.act.value="activeall";
	frm.submit();
}



function get_checked()
{
	frm=document.pform;
		var i=0;
		k=0;
		for(i=0;i<frm.elements.length;i++)
		{
			if(frm.elements[i].type == "checkbox")
			{
				
				if(frm.elements[i].name!="checkall")
				{
					if(frm.elements[i].checked)
					k++;
				}
			}
		}
		return k;
}


function catAll(e1) 
 {
	 frm=document.pform;
 // alert(frm.elements.length);
	j=0	
  for (var i=0;i<frm.elements.length;i++) 
   {
    if (frm.elements[i].name.substring(0,2)=='id') 
     {
	 j++
     frm.elements[i].checked=e1.checked?true:j==0?true:false;
     //alert(i); 
     }
   }
}  
</script>
		
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
           <?php include("includes/header.php"); ?>
		   
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <?php include("includes/leftmenu.php");?>
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                       Add Permissions
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Roles Permissions</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
	<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
	   
	   <div class="row">
                       
                        <div class="col-md-12">

                            <div class="box box-success">
                               <!-- <div class="box-header">
                                    <h3 class="box-title">Different Width</h3>
                                </div>-->
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-xs-3">
                                          Roles List                                       </div>
                                        <div class="col-xs-6">
           <select name="role_id" id="role_id" class="form-control" required>
                            
               
                <?php
				$sql1="select * from roles  order by role_id ASC";		
	$stmt1=$db->prepare($sql1);	
	$stmt1->execute();
	while($row1= $stmt1->fetch(PDO::FETCH_ASSOC))
			  {
				?>
                 <option value="<?php echo $row1['role_id'];?>"> <?php echo $row1['role_name'];?></option>
                <?php
				}
				?>
                        </select>                           </div>
                                        
                                    </div>
                                </div><!-- /.box-body -->
								
								   
                            </div><!-- /.box -->
                        </div>
                       
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box">
                                <div class="box-header">
                                    <!--<h3 class="box-title">Hover Data Table</h3>-->
									<div class="con-rt-head" >
								&nbsp;&nbsp;<a href="#" onClick="return activate_all()" class="btn btn-xs btn-success" > <i class="glyphicon glyphicon-ok"></i> Give Permisions</a>	
          		
					</div> 
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
				
                                 <table id="example" class="table table-bordered table-hover table-responsive" > 
                                        <thead>
                                           <tr style="background-color:#3C8DBC; color:#FFFFFF;">
						<th>Page Name  </th>
						<th> <INPUT type="checkbox" onClick="return catAll(this)" id="checkall" name="checkall">&nbsp;
                        <i class="glyphicon glyphicon-check"></i> </th>
						
						
					</tr>
                                        </thead>
                                        <tbody>
										
										<?php
					 
			  while($row= $stmt->fetch(PDO::FETCH_ASSOC))
			  {
				  extract($row);
	 ?>
				
								<tr>
                  
						<td><?php echo ucfirst(stripslashes($page_title));?></td>
						<td><input name="id[]" type="checkbox"  value="<?php echo $page_id; ?>" /></td>  

					</tr>
				<?php
			  }  
			  ?>
                                        </tbody>
                                    </table>
									
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

            </FORM>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


      
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  
<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
$('#example').dataTable( {
	"aoColumnDefs": [{ "sClass": "text-center", "aTargets": [1] },{'bSortable': false, 'aTargets': [ 1 ] }],
 /* "bPaginate": true,
   "bFilter": false,
   "bLengthChange": false,*/
   "iDisplayLength": 100,
     "aLengthMenu": [[5, 10, 25, 50,100,150,200,250,500, -1], [5, 10, 25, 50,100,150,200,250,500, "All"]]
    
 
} );
 } );

    
</script> 

    </body>
</html>
