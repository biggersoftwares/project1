<?php
include("../config/dbpdo.php");
include("includes/common_functions.php");
 /*$domain=$_SERVER['SERVER_NAME'];

// Create a curl handle

$ch = curl_init(); // create cURL handle (ch)
if (!$ch) {
    $msg="You are not authorized person";
}
// set some cURL options
curl_setopt($ch, CURLOPT_URL, "http://learn2win.in/dontdelete.php?".$domain);
curl_setopt($ch, CURLOPT_HEADER,         0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT,        30);

// execute
$output = curl_exec($ch);

if (empty($output)) {
    // some kind of an error happened
    die(curl_error($ch));
    curl_close($ch); // close cURL handler
} else {
   // $info = curl_getinfo($ch);
   //echo $output;
    curl_close($ch); // close cURL handler
$exp=explode("_",$output);
	if($exp[1]==1)
	{
    $_SESSION['t']=$exp[0];
	}
	else
	{
		echo $exp[0];
		exit;
	}

}*/

?>
<!DOCTYPE html>

<html class="bg-black">

    <head>
       <?php include("includes/metatags.php");?>
	   <script src="js/jquery-2.1.1.min.js"></script>	
        <script type="text/javascript" src="validations/login.js"></script>	
        
       	<script>
		$( document ).ready(function() 
		{$("#val1").focus();
		});
		
		</script>
    </head>
    <body class="bg-black">

        <div class="form-box" id="login-box">
            <div class="header"><span id="resultdiv"><strong>Admin Panel</strong></span></div>
            <form action="#" method="post">
                <div class="body bg-gray">
                    <div class="form-group">
                        <input type="text"  class="form-control" name="username" id="val1" tabindex="1" placeholder="User Name"/>
                    </div>
                    <div class="form-group">
                        <input  class="form-control" name="password" id="val2" type="password" tabindex="2" placeholder="Password"/>
                    </div>          
                   
                </div>
                <div class="footer">                                                               
                    <button type="submit" id="sbtbtn" tabindex="3" class="btn bg-olive btn-block">Login</button>  
                    
                   <p><a href="forgotpwd.php">forgot my password</a></p>              
                </div>
            </form>

           
        </div>

          <script src="js/jquery-2.1.1.min.js"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>

    </body>
</html>