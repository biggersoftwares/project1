<?php
ob_start();
session_start();
//session_destroy();
unset($_SESSION['sessionadmin_id']);
unset($_SESSION['sessionadmin_name']);
unset($_SESSION['role_id']);

session_destroy();
header("Location:index.php");
?>
