<?php
include("config/db_connection.php");
include("includes/functions.php");
$sid=session_id();

if($_SESSION['sessionuser_id']=="")
{
$user_id=0;
}
else
{
$user_id=$_SESSION['sessionuser_id'];
}
if($_POST['update_cart']=='Update Cart')
{
$pids=$_POST['pids'];
if(count($pids)>0)
{

	for($k=0;$k<count($pids);$k++)
	{
	
	$qty="quantity_".$k;
	$updqty= $_POST[$qty];

	 $upd_cart="update temp_cart set user_id=".$user_id.",qty=".$updqty." where temp_id=".$_POST['tids'][$k];
	$res=mysql_query($upd_cart);
	}
	
}


}
if($_POST['act']=='ADDTOCART')
{

 $pid=strip_tags(trim($_POST['pid']));
$qty=1;
$post_date=date('Y-m-d');
$sid=session_id();

$sql_cart="select * from temp_cart where sid='".$sid."' and prod_id=".$pid;
$res_cart=mysql_query($sql_cart);
if(mysql_num_rows($res_cart)==0)
{
  $ins_temp="insert into temp_cart ( 
									prod_id,
									user_id,
									qty,
									sid,
									post_date
								)	
								values
								
								(
									'".$pid."',
									'".$user_id."',
									'".$qty."',
									'".$sid."',
									'".$post_date."'
								)";
$res=mysql_query($ins_temp);
}
else
{
$row=mysql_fetch_array($res_cart);
$qty=$row['qty']+1;
$upd_cart="update temp_cart set user_id=".$user_id.",qty=".$qty." where sid='".$sid."' and prod_id=".$pid;
$res=mysql_query($upd_cart);
}
if($res)
{
header("Location:cart.php");
exit;
}

}
if($_POST['act']=='DELETECART')
{
$tid=strip_tags(trim($_POST['tid']));
 $del_cart="delete  from temp_cart where temp_id='".$tid."'";
mysql_query($del_cart);
}
$sql_cart_disp="select * from temp_cart where sid='".$sid."'";
$res_cart_disp=mysql_query($sql_cart_disp);
if(mysql_num_rows($res_cart_disp)==0)
{
header("Location:index.php");
exit;
}

?>
<!doctype html>
<html lang="en-US">
<head>
<?php include("includes/metatags.php"); ?>

	</head>
	<body data-spy="scroll">
		<div id="preloader">
			<img class="preloader__logo" src="<?php echo SITE_URL;?>images/logo.png" alt="" width="100" height="100"/>
			<div class="preloader__progress">
				<svg width="60px" height="60px" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
					<path class="preloader__progress-circlebg" fill="none" stroke="#dddddd" stroke-width="4" stroke-linecap="round" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					<path id='preloader__progress-circle' fill="none" stroke="#fe6367" stroke-width="4" stroke-linecap="round" stroke-dashoffset="192.61" stroke-dasharray="192.61 192.61" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
				</svg>
			</div>
		</div>
		<div id="wrapper" class="wide-wrap">
			<?php	include("includes/header.php");?>
			<?php	include("includes/video.php");?>
			<?php	include("includes/search.php");?>			
			<?php	include("includes/menubar.php");?>

		<div class="content-container">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div class="commerce">
									 <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" name="frmcart" id="frmcart">
										<table class="table shop_table cart">
											<thead>
												<tr>
													<th class="product-remove hidden-xs">&nbsp;</th>
													<th class="product-thumbnail hidden-xs">&nbsp;</th>
													<th class="product-name">Product</th>
													<th class="product-price text-center">Price</th>
													<th class="product-quantity text-center">Quantity</th>
													<th class="product-subtotal text-center hidden-xs">Total</th>
												</tr>
											</thead>
											<tbody>
											
											<?php
$cart_subtotal=0;
$k=0;
while($cart_row=mysql_fetch_array($res_cart_disp))
{
$sql_prodimg="select * from  product_images  where product_id=".$cart_row['prod_id']." order by prodimage_id ASC limit 0,1";
$res_prodimg=mysql_query($sql_prodimg);
$row_prodimg=mysql_fetch_array($res_prodimg);

$sql_prod1="select * from  products  where product_id=".$cart_row['prod_id'];
$res_prod1=mysql_query($sql_prod1);
$row_prod1=mysql_fetch_array($res_prod1);

if($row_prod1['sale_price']!="")
{
$price=$row_prod1['sale_price'];
}
else
{
$price=$row_prod1['regular_price'];
}
$subtotal=$price*$cart_row['qty'];



?>
												<tr class="cart_item">
													<td class="product-remove hidden-xs">
														<a href="#" onClick="return deletecart(<?php echo $cart_row['temp_id'];?>)" class="remove" title="Remove this item">&times;</a>
													</td>
													<td class="product-thumbnail hidden-xs">
														<a href="#">
															<img  src="<?php echo SITE_URL;?>prod_images/thumb/<?php echo $row_prodimg['prodimage_original'];?>" alt="<?php echo trim(stripslashes($row_prod['product_name']));?>"/>
														</a>
													</td>
													<td class="product-name">
														<a href="#" onClick="return showprod(<?php echo $row_prod1['product_id'];?>)"> <?php echo trim(stripslashes($row_prod1['product_name'])); ?></a>
														<dl class="variation">
															<dt class="variation-Color">Kcal:</dt>
															<dd class="variation-Color"><p><?php echo $row_prod1['calories'];?></p></dd>
														</dl>
													</td>
													<td class="product-price text-center">
														<span class="amount"><i class="fa fa-inr"></i> <?php echo $price;?></span>
													</td>
													<td class="product-quantity text-center">
														<div class="quantity">
															<input type="number" step="1" min="1" name="quantity_<?php echo $k;?>" value="<?php echo $cart_row['qty'];?>" title="Qty" class="input-text qty text" size="4" max="9" style="width:60px;"/>
															<input type="hidden" name="pids[]" value="<?php echo $cart_row['prod_id'];?>" />
															<input type="hidden" name="tids[]" value="<?php echo $cart_row['temp_id'];?>" />
														</div>
													</td>
													<td class="product-subtotal hidden-xs text-center">
														<span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($subtotal);?>.00</span>
													</td>
												</tr>
												<?php
													$k++;
													$cart_subtotal +=$subtotal;
													}
													?>
												<tr>
													<td colspan="6" class="actions">
														
														<input type="submit" class="button update-cart-button" name="update_cart"  value="Update Cart"/>
													</td>
												</tr>
											</tbody>
										</table>
									</form>
									<div class="cart-collaterals">
										<div class="cart_totals">
											<h2>Cart Totals</h2>
											<table>
												<tr class="cart-subtotal">
													<th>Subtotal</th>
													<td><span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($cart_subtotal, 2, '.', '');?></span></td>
												</tr>
												<?php 
												$shipping="";
												if($shipping=="")
												{
												$ship='Free';
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal*$shipping)/100;
												$cart_subtotal=$cart_subtotal+$grandtotal;
												}
												?>
												<tr class="shipping">
													<th>Shipping</th>
													<td><span class="amount"><i class="fa fa-inr"></i> <?php echo $ship;?></span></td>
												</tr>
												<tr class="order-total">
													<th>Total</th>
													<td><strong><span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($cart_subtotal, 2, '.', '');?></span></strong></td>
												</tr>
											</table>
											<div class="wc-proceed-to-checkout">
												<a href="checkout.php" class="checkout-button button alt wc-forward">Proceed to Checkout</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			</div>
			<?php include("includes/footer1.php");?>
			<?php include("includes/footer.php");?>
		</div>
		<a href="#" class="go-to-top"><i class="fa fa-angle-up"></i></a>
		<div class="sitesao-preview__loading">
			<div class="sitesao-preview__loading__animation"><i></i><i></i><i></i><i></i></div>
		</div>
		<?php include("includes/js.php");?>
		 <script language="javascript" type="text/javascript">

function addtocart(id)
{	
var frm=document.frmcart;

	frm.pid.value=+id;

	frm.act.value="ADDTOCART";

	frm.submit();

}
function deletecart(id)
{
	var frm=document.frmdelcart;
	frm.tid.value=+id;
	frm.act.value="DELETECART";
	frm.submit();
}
function showprod(id)

{	

var frm=document.frmshow;

	frm.pid.value=+id;

	frm.submit();

}

</script>
 <form name="frmcart" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

      <input type="hidden" name="pid" value="" />

	   <input type="hidden" name="act" value="" />

      </form>
	<form name="frmdelcart" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
      <input type="hidden" name="tid" value="" />
	   <input type="hidden" name="act" value="" />
      </form>
	  <form name="frmshow" method="post" action="productdetails.php">

      <input type="hidden" name="pid" value="" />

      </form>
	</body>
</html>