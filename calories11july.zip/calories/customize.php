<!doctype html>
<script type="text/javascript"  language="javascript">

    $(document).ready(function () {

        function validateEmail(sEmail) {

            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

            if (filter.test(sEmail)) {

                return true;

            } else {

                return false;

            }

        }

        $("#submit").click(function () {
             var vuser_name = $('#firstname').val();

            if ($.trim(vuser_name).length == 0) {

                $("#firstname").css({"border": "1px solid", "color": "#F00"});

                return false;

            }


            var vrpwd = $('#lastname').val();

            if ($.trim(vrpwd).length == 0) {

                $("#lastname").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            var vmobileno = $('#mobile').val();

            if ($.trim(vmobileno).length == 0) {

                $("#mobile").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            //  Email Validation

            var sEmail = $('#email').val();

            if ($.trim(sEmail).length == 0) {

                $("#email").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            if ($.trim(vmobileno).length < 10) {

                $("#mobile").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            if (!validateEmail(sEmail)) {

                $("#email").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

        });

    });

</script>
<?php
include("config/dbpdo.php");

if(isset($_REQUEST['submit'])) {
    $file_name = $_FILES['menu_file']['name'];
    $tmp = $_FILES['menu_file']['tmp_name'];
    $sql =  "INSERT INTO customize_menu (first_name, last_name, mobile, email, menu_file) "
            . " VALUES ("
            . "'".$_REQUEST['firstname']."',"
            . "'".$_REQUEST['lastname']."',"
            . "'".$_REQUEST['mobile']."',"
            . "'".$_REQUEST['email']."',"
            . "'".$file_name."')";
    mysql_query($sql);
    $file_name = time().$file_name;
    move_uploaded_file($tmp, 'dietmenu/'.$file_name);
}
?>
<html lang="en-US">
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
		<title>Fit revolution</title>
		<link rel="shortcut icon" type="image/ico" href="images/favicon.ico" />

		<link rel='stylesheet' href='css/bootstrap.min.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/jquery.selectBox.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/elegant-icon.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/font-awesome.min.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/style.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/commerce.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/form.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/custom.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/magnific-popup.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/preloader.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/skin-selector.css' type='text/css' media='all'/>
		
		
		<!-- Bootstrap Core CSS -->
  <!--   <link href="css/bootstrap.min.css" rel="stylesheet"> -->

    <!-- Custom CSS -->
    <link href="css/scrolling-nav.css" rel="stylesheet">
	
		<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans%3A400%2C700%7CDancing+Script%3A400%2C700%7CRoboto+Slab%3A400%2C700&amp;' type='text/css' media='all'/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
		<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>

<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/i18n/defaults-*.min.js"></script>

	
	
		
	</head>
	<body id="page-top" data-spy="scroll"    >
		

		
						
	<nav class="navbar navbar-fixed-top"  >
  <div class="container-fluid">
    
	<div class="navbar-header page-scroll">
	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index@.html" style="margin-left: 15px;padding-top: 12px;">
        FIT REVOLUTION
      </a>
    </div>
	
	<div class="collapse navbar-collapse " id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav int">
	
			<li><a class="page-scroll" href="index@.html">HOME</a></li>
			<li><a class="page-scroll" href="index@.html#menu" >MENU</a></li>
			<li><a class="page-scroll" href="index@.html#call1">CACULATOR</a></li>
			<li><a class="page-scroll" href="index@.html#aboutus">OUR STORY</a></li>
		
			<li><a href="#" id="cart" data-toggle="modal" data-target="#myModal"><i class="fa fa-shopping-cart"></i> Cart <span class="badge">3</span></a></li>
			<li>
			<a class="minicart-link" data-toggle="modal" data-target="#myModal1" href="#">
			<img src="images/profile.png" />
			</a>
			</li>
	
		</ul>

		
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="container">
  <div class="shopping-cart">
    <div class="shopping-cart-header">
      <i class="fa fa-shopping-cart cart-icon"></i><span class="badge">3</span>
      <div class="shopping-cart-total">
        <span class="lighter-text">Total:</span>
        <span class="main-color-text">&#8360; 2,229.97</span>
      </div>
    </div> <!--end shopping-cart-header -->

    <ul class="shopping-cart-items">
      <li class="clearfix">
        <img src="images/pizaz.jpg" alt="item1" />
        <span class="item-name">Pizza</span>
        <span class="item-price">&#8360; 849.99</span>
        <span class="item-quantity">Quantity: 01</span>
      </li>

      <li class="clearfix">
        <img src="images/buger.jpg" alt="item1" />
        <span class="item-name">Burzer</span>
        <span class="item-price">&#8360; 1,249.99</span>
        <span class="item-quantity">Quantity: 01</span>
      </li>

      <li class="clearfix">
        <img src="images/fries.jpg" />
        <span class="item-name">French fry</span>
        <span class="item-price">&#8360; 129.99</span>
        <span class="item-quantity">Quantity: 01</span>
      </li>
    </ul>

      <a href="checkout.html" class="button"><b>Checkout</b></a>
  </div> <!--end shopping-cart -->
</div> <!--end container -->	
</div>
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document" style=" margin-right: 240px; /* margin-bottom: 150px; */">
    <div class="modal-content" style="width: 350px;margin-top: 150px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel" style="text-align: center; color:white;">LOGIN</h4>
      </div>
      <div class="modal-body">
     
    <div class="form-group">
     
      <input type="text" class="form-control" id="usr" placeholder="USERNAME">
    </div>
    <div class="form-group">
    
      <input type="password" class="form-control" id="pwd" placeholder="PASSWORD">
    </div>
	
    <button type="button" class="btn btn-success">LOG IN</button>
      </div>
      <div class="modal-footer">
     <a href="login1.html" hspace="5" style="border-right: 1px solid white;    padding-right: 5px;">REGISTER</a>
        <a href="forgot_password.html">FORGOT PASSWORD?</a>
      </div>
    </div>
  </div>
</div>			
			



<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>



					
<section class="tabs_section"  id="menu">
	
	<div class="container">
	
		<div class="row">
					<h4 style="text-align:center;">MENU</h4>
			<ul id="nav-menus">
<li class="selected" id="daily"><a href="index@.html#daily">DAILY</a></li>
<li><a href="weekly.html">WEEKLY</a></li>
<li><a href="customize.html">CUSTOMIZE MENU</a></li>

</ul>
		</div>
	</div>

	
</section>

<section>

	
	<div class="container customize">

<h2 style="text-align:center;     margin-top: -51px;"> Fill the details , get the diet menu</h2>

		<div class="row">
		<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="text-block">
                                                        
            <form action="#" method="post" class="form my_account" role="form" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-xs-6 col-md-6">
                            <input class="form-control" name="firstname" placeholder="First Name" type="text" required="" autofocus="">
                        </div>
                        <div class="col-xs-6 col-md-6">
                            <input class="form-control" name="lastname" placeholder="Last Name" type="text" required="">
                        </div>
                    </div>
                 
                    <input class="form-control" name="email" id="email" placeholder="Your Email" type="text" required="">
               
                    <input class="form-control" name="mobile" id="mobile" placeholder="Mobile No" type="text" required="">
                   

		<div class="form-group">
                <label for="usr">Upload Your Menu </label>
                </div>
                <div class="row">
                  <div class="col-xs-6 col-md-6">
                      <input class="form-control" name="menu_file" placeholder="Upload File" type="file" required="">
                  </div>
                </div>
              <div class="row">
                  <div class="col-xs-6 col-md-6">
                          Upload Formats: Pdf, Jpg, Word Document
                  </div>
              </div>
                    <br>
     
    

				

				<input type="submit" id="submit" class="btn btn-primary " value="Upload" name="submit"  >	
				<p>We will get back to you in 12hours, if we can prepare your diet.</p>
		
                   
                    
                </form>
                                                    </div>
			</div>
			<div class="col-md-3"></div>

			<div class="col-md-6">
			<form></form>
				
			</div>
		</div>

		             
                                                    


</div>

</section>




			










			
			<div class="footer-widget">
				<div class="container">
					<div class="footer-widget-wrap">
						<div class="row">
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget widget_text">
									<h3 class="widget-title">
										<span>Business Hours</span>
									</h3>
									<div class="textwidget">
										<p>
											mr Fit revolution opended in 1999 - We specialize in three course tasting menus, allowing the customer to select any three dishes from the menu for $52 per person.
										</p>
										<p>
											<strong>Mon - Fri: ---------- 8am - 5pm</strong><br/>
											<strong>Sat: ------------------ 8am - 11pm</strong><br/>
											<strong>Sun: ----------------- Closed</strong>
										</p>
									</div>
								</div>
							</div>
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget widget-post-thumbnail">
									<h3 class="widget-title">
										<span>Recent News</span>
									</h3>
									<ul class="posts-thumbnail-list">
										<li>
											<div class="posts-thumbnail-image">
												<a href="#">
													<img width="600" height="319" src="images/blog/blog-5.jpg" alt="blog-5" />
												</a>
											</div>
											<div class="posts-thumbnail-content">
												<h4><a href="#">Cheese Brie Sandwich</a></h4>
												<div class="posts-thumbnail-meta">
													<time datetime="2015-04-28T08:40:24+00:00">April 28, 2015</time>, 
													<span class="comment-count">
														<a href="#">0 Comments</a>
													</span>
												</div>
											</div>
										</li>
										<li>
											<div class="posts-thumbnail-image">
												<a href="#">
													<img width="600" height="319" src="images/blog/blog-2.jpg" alt="blog-2" />
												</a>
											</div>
											<div class="posts-thumbnail-content">
												<h4><a href="#">Fermentum Commodo Arcu</a></h4>
												<div class="posts-thumbnail-meta">
													<time datetime="2015-04-28T08:40:24+00:00">April 28, 2015</time>, 
													<span class="comment-count">
														<a href="#">0 Comments</a>
													</span>
												</div>
											</div>
										</li>
										<li>
											<div class="posts-thumbnail-image">
												<a href="#">
													<img width="600" height="319" src="images/blog/blog-3.jpg" alt="blog-3" />
												</a>
											</div>
											<div class="posts-thumbnail-content">
												<h4><a href="#">Cooking Lesson</a></h4>
												<div class="posts-thumbnail-meta">
													<time datetime="2015-04-28T08:40:24+00:00">April 28, 2015</time>, 
													<span class="comment-count">
														<a href="#">0 Comments</a>
													</span>
												</div>
											</div>
										</li>
									</ul>
								</div>
							</div>
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget tweets-widget">
									<h3 class="widget-title">
										<span>Latest Tweets</span>
									</h3>
									<div class="recent-tweets">
										<ul>
											<li>
												<span>
													Social Login for Magento allow users to log into your store through their social profiles <a href="#" target="_blank">http://t.co/H6b1SdBddu</a> <a href="#" target="_blank">http://t.co/cG9vSZoTjy</a>
												</span>
												<a class="twitter_time" target="_blank" href="#">223 days ago</a>
											</li>
											<li>
												<span>
													Copy VC shortcode for different purposes: in WP Widget Text, in do_shortcode function…. <a href="#" target="_blank">http://t.co/kgeZgVppr1</a> <a href="#" target="_blank">http://t.co/UT26ch7daD</a>
												</span>
												<a class="twitter_time" target="_blank" href="#">229 days ago</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="footer-widget-col col-md-3 col-sm-6">
								<div class="widget widget_nav_menu">
									<h3 class="widget-title">
										<span>Infomation</span>
									</h3>
									<div class="menu-infomation-container">
										<ul class="menu">
											<li><a href="#">Legal Notice</a></li>
											<li><a href="#">Terms of use</a></li>
											<li><a href="#">OUR STORY</a></li>
											<li><a href="#">Secure payment</a></li>
											<li><a href="#">Typo</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="footer-info">
					<div class="container">
						<div class="footer-info-wrap">
							<div class="row">
								<div class="col-md-4 hidden-sm hidden-xs">
									<div class="copyright text-left">mr Fit revolution © 2015</div>
								</div>
								<div class="col-md-4 col-sm-12 text-center">
									<div class="footer-info-logo">
										<a href="#">
											<img alt="mr Fit revolution" src="images/logo.png">
										</a>
									</div>
									<div class="footer-social">
										<a href="#" title="Facebook" target="_blank">
											<i class="fa fa-facebook facebook-bg-hover"></i>
										</a>
										<a href="#" title="Twitter" target="_blank">
											<i class="fa fa-twitter twitter-bg-hover"></i>
										</a>
										<a href="#" title="Google+" target="_blank">
											<i class="fa fa-google-plus google-plus-bg-hover"></i>
										</a>
										<a href="#" title="Pinterest" target="_blank">
											<i class="fa fa-pinterest pinterest-bg-hover"></i>
										</a>
										<a href="#" title="RSS" target="_blank">
											<i class="fa fa-rss rss-bg-hover"></i>
										</a>
										<a href="#" title="Instagram" target="_blank">
											<i class="fa fa-instagram instagram-bg-hover"></i>
										</a>
									</div>
								</div>
								<div class="col-md-4 hidden-sm hidden-xs">
									<div class="footer-info-text text-right">
										Designed by <a href="http://www.lptechlog.com" target="_blank">Lptechlog</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
		<a href="#" class="go-to-top"><i class="fa fa-angle-up"></i></a>
		<div class="sitesao-preview__loading">
			<div class="sitesao-preview__loading__animation"><i></i><i></i><i></i><i></i></div>
		</div>
		<script type='text/javascript' src='js/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.validate.min.js'></script>
		<script type='text/javascript' src='js/easing.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/jquery.appear.min.js'></script>
		<script type='text/javascript' src='js/script.js'></script>
		<script type='text/javascript' src='js/jquery.blockUI.min.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel.min.js'></script>
		<script type='text/javascript' src='js/isotope.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.magnific-popup.min.js'></script>
		<script type='text/javascript' src='js/jquery.parallax.js'></script>
		<script type='text/javascript' src='js/preloader.min.js'></script>
	    <!-- jQuery -->
    <script src="js/jquery.js">
    	
    	(function(){
 
  $("#cart").on("click", function() {
    $(".shopping-cart").fadeToggle( "fast");
  });
  
})();
    </script>


    <!-- Scrolling Nav JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrolling-nav.js"></script>
	</body>
</html>                                                                                                                                                                                                                                                                       