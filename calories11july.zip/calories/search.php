<?php ?>
<section class="hero__content-footer hide-sm">
	<div class="container">
		<div class="row">
						
			<div class="col-md-2">
			&nbsp;
			</div>
			<div class="col-md-8" style="background-color: rgba(0,0,0,0.21);padding: 15px;">
			<input type="text" placeholder="lets Know what you ate?" name="search_item" class="search_item"><input type="button" value="search" name="searchbtn" onclick="funSearch()">
			</div>
			<div class="col-md-2">
			&nbsp;
			</div>
		</div>
	</div>
</section>

<script language="javascript" type="text/javascript">

			function funSearch()
			{
			search_item=$.trim($(".search_item").val());
				//alert(search_item);
			if(search_item=="")
			{
			alert("Enter Item ");
			$(".search_item").focus();
			return false;
			
			}
			json_obj={};
			json_obj.pname=search_item;
			$.fn.refresh_prodDiv(json_obj);
			}
</script>

<?php ?>
