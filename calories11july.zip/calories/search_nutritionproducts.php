<?php
include("config/db_connection.php");
include("config/dbpdo.php");
include("includes/functions.php");
$sql ="select * from ".DBEXT."calorie_table1 where ndbno!=''";
if($_POST['search']=='PRODSEARCH')
{
 $sql .=" and name like '%".stripslashes(trim($_POST['prod_title']))."%'";
}

//echo  $sql ;

$res_prod=mysqli_query($conn, $sql);
print_r($res_prod);
?>
<!doctype html>
<html lang="en-US">
	<head>
	<?php
	include_once("config/db_connection.php");
	include_once("includes/functions.php");
	include_once("DBFns.php");
	?>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		<style type="text/css">
        	.search_result_ul{
  margin: 30px 0;
  padding: 0px;
  list-style: none;
}
.search_result_ul li{
  margin-bottom: 10px;
}
.search_result_ul li a{
  color: #77c8d5;
  font-size: 22px;
}
        </style>
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->
						
<body data-spy="scroll">
	<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	
<!-- ---------------------------------------      ------------------------------------------------- -->

<section class="facts_table">
<div class="content-container">
				<section class="facts_table">
    		<div class="container">
			
    			<div class="row">
				<?php
			if($_POST['prod_title']!="")
			{
			?>
    					<h1 class="searched_">You are searched for : <span>“ <?php echo stripslashes(trim($_POST['prod_title']));?> “</span></h1>
    					<!--<br><br>
    					<h1 class="searched_">RESULTS</h1>-->
						
    					<ul class="search_result_ul">
						<?php
						
/*$xmlDoc = new DOMDocument();
$xmlDoc->load( 'http://api.nal.usda.gov/ndb/search/?format=xml&q='.$_POST['prod_title'].'&max=25&offset=0&api_key=wRAzXPXM7yXYo0mLXo2kF7w34YkPCp5EglAHLiab' );

$searchNode = $xmlDoc->getElementsByTagName( "item" );

foreach( $searchNode as $searchNode )
{
    $valueID = $searchNode->getAttribute('offset');

 $group = $searchNode->getElementsByTagName( "group" );
    $valueGroup = $group->item(0)->nodeValue;
	
    $xmlName = $searchNode->getElementsByTagName( "name" );
    $valueName = $xmlName->item(0)->nodeValue;

    $xmlID = $searchNode->getElementsByTagName( "ndbno" );
    $ndbno = $xmlID->item(0)->nodeValue;*/
	while($row1=mysqli_fetch_array($res_prod))
	{
						?>
<li><a href="<?php echo SITE_URL;?>nutritionvalues.php?id=<?php echo $row1['ndbno'];?>"><?php echo stripslashes($row1['name']);?></a></li>

						<?php
						}
						}//if
						?>
<!--<li><a href="#">Pizzas : 14" Pizza, Cheese Topping, Thin Crust</a></li>
<li><a href="#">Bread Products & Mixes : Dough, Pizza Dough, Whole Wheat</a></li>-->
    						
    					</ul>

          <br clear="all">
          <div class="col-md-4">
          
              

              </div>
    					
    				
    			</div>
				
    			</div>
    		</div>

</section>
		
<!-- ----------------------------------------     ------------------------------------------------ -->
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		</body>
</html>