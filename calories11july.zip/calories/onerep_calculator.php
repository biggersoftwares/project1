<!doctype html>
<html lang="en-US">
	<head>
	<?php
	include_once("config/db_connection.php");
	include_once("includes/functions.php");
	include_once("DBFns.php");
	?>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->
						
<body data-spy="scroll">
	<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	
<!-- ---------------------------------------      ------------------------------------------------- -->

<section class="facts_table">
			<div class="content-container backg">
				
    		<div class="container">
    			<div class="row">
    			<h1 class="searched_">One-Rep Max (one-rm) Calculator</h1>
          <br clear="all">
          <div class="col-md-6">
          <form action="#" method="post" class="form my_account" role="form" >
                                                  
                                                      <div class="row">
                       
                        <div class="col-xs-4 col-md-4">
                          <label> Weight Lifted</label>
                            <input class="form-control" id="weight_lifted" placeholder="" type="text" onKeyUp="checkNumber(this);" required="required">
                        </div>
                        <div class="col-xs-4 col-md-4">
                          <label>  Reps</label>
                          <select class="form-control" name="reps" id="reps">
                          <?php
						  for($k=1;$k<=12;$k++)
						  {
							  ?>
                          <option value="<?php echo $k;?>"><?php echo $k;?></option>
                          <?php
						  }
						  ?>
                          </select>
                           
                        </div>
                        <div class="col-xs-4 col-md-4">
                        <label>  &nbsp;</label>
                            <button class="btn btn-lg btn-primary btn-block" type="button" id="calculate">Calculate</button><br>
                        </div>

                    </div>
                    
                   <div class="row">
                        <div class="col-xs-6 col-md-6">
                        <label> 95% ONE-RM</label>
                            <input class="form-control" id="one" placeholder="?" type="text">
                        </div>
                        <div class="col-xs-6 col-md-6">
                         <label> 70% ONE-RM</label>
                            <input class="form-control" id="six" placeholder="?" type="text"  >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-6">
                        <label> 90% ONE-RM</label>
                            <input class="form-control" id="two" placeholder="?" type="text">
                        </div>
                        <div class="col-xs-6 col-md-6">
                         <label> 65% ONE-RM</label>
                            <input class="form-control" id="seven" placeholder="?" type="text"  >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-6">
                        <label> 85% ONE-RM</label>
                            <input class="form-control" id="three" placeholder="?" type="text">
                        </div>
                        <div class="col-xs-6 col-md-6">
                         <label> 60% ONE-RM</label>
                            <input class="form-control" id="eight" placeholder="?" type="text"  >
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-xs-6 col-md-6">
                        <label> 80% ONE-RM</label>
                            <input class="form-control" id="four" placeholder="?" type="text">
                        </div>
                        <div class="col-xs-6 col-md-6">
                         <label> 55% ONE-RM</label>
                            <input class="form-control" id="nine" placeholder="?" type="text"  >
                        </div>
                    </div>
                       <div class="row">
                        <div class="col-xs-6 col-md-6">
                        <label> 75% ONE-RM</label>
                            <input class="form-control" id="five" placeholder="?" type="text">
                        </div>
                        <div class="col-xs-6 col-md-6">
                         <label> 50% ONE-RM</label>
                            <input class="form-control" id="ten" placeholder="?" type="text"  >
                        </div>
                    </div>
					  
                   
                </form>

              </div>
    					<div class="col-md-6">
           <h4 class="searched_">Your One-Rep Max (one-rm):  <span style="font-weight:bold;color:#2cabbf"><span id="maxhrspan">?</span> </span></h4>
              
			   <!--<h6>This is the World Health Organization's (WHO) recommended body weight based on BMI values for adults. It is used for both men and women, age 18 or older.</h6>
			  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        
        <th>Category</th>
        <th>BMI range - kg/m2</th>
      </tr>
    </thead>
    <tbody>

        <tr><td>Severe Thinness</td>
        <td>< 16</td>      </tr>
		
		<tr><td>Mild Thinness</td>
        <td>17 - 18.5</td>      </tr>
		
		<tr><td>Overweight</td>
        <td>25 - 30</td>      </tr>
		
		
		
		<tr><td>Obese Class I</td>
        <td>30 - 35</td>      </tr>
		
		<tr><td>Obese Class II</td>
        <td>35 - 40</td>      </tr>
		
		<tr><td>Obese Class III</td>
        <td>> 40</td>      </tr>
    </tbody>
  </table>
  </div>-->
</div>
              <br clear="all">
              

              </div>
    				
    			</div>
    			</div>
    		</div>
    </section>

<script type="text/javascript" src="js/userjs/general.js"></script>
<script type="text/javascript" src="js/userjs/onerep_calculator.js"></script>
		
<!-- ----------------------------------------     ------------------------------------------------ -->
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		</body>
</html>