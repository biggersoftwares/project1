<!doctype html>
<html lang="en-US">
	<head>
		<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
		<?php	
		include("config/db_connection.php");
		include("includes/functions.php");
		include("DBFns.php");
		?>
		
	</head>
	
	<body id="page-top" data-spy="scroll"    >
		
<!-- cart display start -->
	<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->			

<!-- maincat start -->
	<?php include("preloader.php");?>
<!-- maincat end -->			

<?php
$sid =session_id();
if($_SESSION['sessionuser_id']=="")
{
	$cartItems = $db->get_cart_items($sid);
}else{
	$user_id=$_SESSION['sessionuser_id'];
	$cartItems = $db->get_user_cart_items($user_id);
}
if(empty($cartItems))
{
header("Location:index.php");
exit;
}
$sql_account="select * from bill_ship_address where user_id='".$user_id."'";
$res_account=mysql_query($sql_account);
$row_account=mysql_fetch_array($res_account);
?>
		<?php
	if(isset($_POST['sbtplaceorder'])) {
		
	}
	?>

<section class="checkout_section">
		<form method="post" class="form" role="form" name="frmsame">
		 <?php
if($_SESSION['sessionuser_id']=="")
{
?>
		<div class="container">
				<div class="row">
					<div class="col-md-6">
						
						<h3>User Details</h3>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Full Name</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input class="form-control"  name="username" id="username" type="text" maxlength="25">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Mobile No</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input class="form-control" name="mobileno" id="mobileno" type="text" maxlength="10">
                        </div>
                    </div>
                   
                  
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control"> Email Id(User Id)</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input class="form-control" name="user_email" id="user_email" type="text" maxlength="50">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control"> Password</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input class="form-control" name="pwd" id="pwd" type="text" maxlength="25">
                        </div>
                    </div>
               
					</div>
					
					
				</div>
			</div>
			<?php
			}
			?>
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						
						<h3>Billing Address</h3>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control"> First Name</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input class="form-control" value="<?php echo $row_account['b_firstname'];?>" placeholder="" id="b_firstname" name="b_firstname" type="text" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Last name</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                             <input type="text" value="<?php echo $row_account['b_lastname'];?>" placeholder="" id="b_lastname" name="b_lastname" class="form-control" maxlength="30" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Email Id</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                           <input type="text" value="<?php echo $row_account['b_emailid'];?>" placeholder=""  name="b_emailid"  id="b_emailid" class="form-control" maxlength="50" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Mobile No</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input type="text" value="<?php echo $row_account['b_mobileno'];?>" placeholder="" id="b_mobileno" name="b_mobileno" class="form-control" maxlength="10"  onKeyUp="checkNumber(this);" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Address</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                           <input type="text" value="<?php echo $row_account['b_address'];?>" placeholder="Street address" id="b_address" name="b_address" class="form-control" required="" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Address1</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                             <input type="text" value="<?php echo $row_account['b_address1'];?>" placeholder="" name="b_address1" id="b_address1" class="form-control" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">City</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input type="text" value="<?php echo $row_account['b_city'];?>" placeholder="Town / City" id="b_city" name="b_city" class="form-control" maxlength="30" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Zip Code</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                              <input type="text" value="<?php echo $row_account['b_zipcode'];?>" placeholder="Postal code / Zip" name="b_zipcode" id="b_zipcode" class="form-control" maxlength="6" required=""  onKeyUp="checkNumber(this);">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">&nbsp;</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                        	  <label><input type="checkbox"  name="same" Onclick="javascript:makesame();"  class="input-checkbox" id="same"> My Billing and Shipping Address are same</label>
                        </div>
                    </div>
                    
					</div>
					
					<div class="col-md-6">
						
						<h3>Shipping Address</h3>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control"> First Name</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input class="form-control" value="<?php echo $row_account['s_firstname'];?>" placeholder="" id="s_firstname" name="s_firstname" type="text" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Last name</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                             <input type="text" value="<?php echo $row_account['s_lastname'];?>" placeholder="" id="s_lastname" name="s_lastname" class="form-control" maxlength="30" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Email Id</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                           <input type="text" value="<?php echo $row_account['s_emailid'];?>" placeholder=""  name="s_emailid"  id="s_emailid" class="form-control" maxlength="50" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Mobile No</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input type="text" value="<?php echo $row_account['s_mobileno'];?>" placeholder="" id="s_mobileno" name="s_mobileno" class="form-control" maxlength="10"  onKeyUp="checkNumber(this);" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Address</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                           <input type="text" value="<?php echo $row_account['s_address'];?>" placeholder="Street address" id="s_address" name="s_address" class="form-control" required="" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Address1</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                             <input type="text" value="<?php echo $row_account['s_address1'];?>" placeholder="" name="s_address1" id="s_address1" class="form-control" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">City</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                            <input type="text" value="<?php echo $row_account['s_city'];?>" placeholder="Town / City" id="s_city" name="s_city" class="form-control" maxlength="30" required="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Zip Code</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                              <input type="text" value="<?php echo $row_account['s_zipcode'];?>" placeholder="Postal code / Zip" name="s_zipcode" id="s_zipcode" class="form-control"  onKeyUp="checkNumber(this);" maxlength="6" required="">
                        </div>
                    </div>
					<div class="row">
                        <div class="col-xs-6 col-md-3">
                            <label class="form-control">Landmark</label>
                        </div>
                        <div class="col-xs-6 col-md-9">
                               <input type="text" name="landmark" id="landmark" class="form-control" value="<?php echo $row_account['landmark'];?>"maxlength="50" required="">
                        </div>
                    </div>
					<div class="row">
                        <div class="col-xs-6 col-md-9">
                            <label class="form-control">&nbsp;</label>
                        </div>
                        <div class="col-xs-6 col-md-3">
<!--                                  <input class="btn btn-lg btn-primary " type="submit" id="sbtplaceorder" value="Continue"> -->
                                 <input type="button" class="btn btn-lg btn-primary" name="sbtplaceorder" id="sbtplaceorder"  value="Continue"/>
                        </div>
                    </div>
                    <br>
                  
               
					</div>
				</div>
			</div>	
			</form>	
		</section>
		
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		
<?php
if(mysql_num_rows($res_account)==1)
{
?>
	<script type="text/javascript" src="js/billing_shipping_edit.js"></script>
	<?php
	}
	else
	{
	?>
	<script type="text/javascript" src="js/billing_shipping_add.js"></script>
	<?php
	}
	?>
	<script language="javascript" type="text/javascript">
	function makesame(){
	var frm=document.frmsame;
	//alert(frm.same.checked);
	
	if (frm.same.checked==true){
		frm.s_firstname.value =frm.b_firstname.value;
		frm.s_lastname.value=frm.b_lastname.value
		frm.s_address.value=frm.b_address.value;
		frm.s_address1.value=frm.b_address1.value;
		frm.s_city.value=frm.b_city.value;
		frm.s_zipcode.value=frm.b_zipcode.value;
		frm.s_emailid.value=frm.b_emailid.value;
		frm.s_mobileno.value=frm.b_mobileno.value;
	}
	else
	{
		frm.s_firstname.value="";
		frm.s_lastname.value="";
		frm.s_address.value="";
		frm.s_address1.value="";
		frm.s_city.value="";
		frm.s_zipcode.value="";
		frm.s_emailid.value="";
		frm.s_mobileno.value=""
		}	
	}

		function checkNumber(textBox)
	
		{
	
			while (textBox.value.length > 0 && isNaN(textBox.value)) {
	
				textBox.value = textBox.value.substring(0, textBox.value.length - 1)
	
			}
	
			
	
			textBox.value = textBox.value;
	
		/*	if (textBox.value.length == 0) {
	
				textBox.value = 0;		
	
			} else {
	
				textBox.value = parseInt(textBox.value);
	
			}*/
	
		}
	
	</script>
	
			</body>
</html>                                                                                                                                                                                                                                                                       
<?php ?>
