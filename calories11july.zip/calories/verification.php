<?php 
include("config/dbpdo.php");
//include("includes/functions.php");
//include("includes/mail_function.php");

$msg="";
$msg1="";
if($_POST['act']=='VERIFY')
{
$activation=strip_tags(trim($_POST['activation']));
$user_id=trim($_POST['key']);


 $sql="select * from users where activation='".$activation."' and user_id=".$user_id;
		$res=mysql_query($sql);  
		
		$cnt=mysql_num_rows($res);
		if($cnt==1)
		{
			
				$upd="update users set status=1 where activation='".$activation."' and user_id=".$user_id;
			
			$resupd=mysql_query($upd);
			if($resupd)
			{
			$row = mysql_fetch_array($res);
			 $_SESSION['sessionuser_name']=$row['user_name'];
			 $_SESSION['sessionuser_id']=$row['user_id'];
			header("Location:myaccount.php");
				exit;
			}	
		}
		else
		{
		$_REQUEST['key']=$_POST['key'];
		$msg="Activation Code Wrong.";
		}

}
if($_POST['act']=='RESEND')
{
$user_id=trim($_POST['key']);
$activation=rand(100000,999999);

 $sql_sel="select * from users where  user_id=".$user_id;
		$res_sel=mysql_query($sql_sel); 
		$row_sel= mysql_fetch_array($res_sel);
		  $user_name=$row_sel['user_name'];

 $upd="update users set status=0,activation='".$activation."' where   user_id=".$user_id;
$res=mysql_query($upd);

			$verify=$user_id;
			
			$subject = 'Your account on My Calorie';

// message
   $body = '
 
 <div style="margin: 0 auto; width: 600px; background:#fff; box-shadow:0px 1px 1px 1px #428bca;">
	             <div style="background:#FFFFFF; padding: 20px; color:#fff"> <a href="'.SITE_URL.'"><img src="'.SITE_URL.'images/logo.png" alt="My Calorie" title="My Calorie" width="120" height="80"></a>
	              </div>
	       <div style="clear: left; padding: 20px;">
    
		<h3 style="color:#000; font-size: 14px; margin:3px 0;">
			
            <p>Dear '.$user_name.',</p>
		</h3>
		
        <p>Thank You for showing inerest to register with us  </p>
	
 
	</div>
    
   <div style="clear: left; padding: 10px; border-top:1px solid #ccc; width:90%; margin-left:8px;">
    <table width="90%"  cellspacing="2" cellpadding="5" align="center" bgcolor="#f2f2f2">
      
      <tr>
        <td height="30" align="left"><strong>Activation Code</strong></td>
        <td> :  '.$activation.'</td>
      </tr>     
    </table>
    </div>
	<div style="background:#428bca; text-align:left; padding: 8px 20px; color:#fff;"><p><strong>Warms Regards</strong>,<br />

                                                                                My Calorie<br />

                                                                                www.mycalories.com</p>

 </div>
</div> ';

 $to = $row_sel['user_email'];;
 
$files = array();

$head = array(
       'to'      =>array($to=>$user_name),
       'from'    =>array('pavankumarraju.n@gmail.com' =>'My Calorie'),
      /* 'cc'      =>array('reitake.com@gmail.com'=>'Admin'),*/
       
       );
//mail::send($head,$subject,$body, $files);

if($res)
{

//   ***************************  EMAIL   END **************************
		
			header("Location:verification.php?key=".$verify);
			exit;
			
			}
		

}
?>
<!doctype html>
<html lang="en-US">
	<head>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
	<?php	
		include("config/db_connection.php");
		include("includes/functions.php");
		include("DBFns.php");
		?>
	</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php include("search_nutrition.php");?>
<!-- search bar end -here -->
						
<section class="tabs_section"  id="menu">
	
	<div class="container">
	
		<div class="row">
					<h4 style="text-align:center;">MENU</h4>
			<ul id="nav-menus">
<li class="selected" id="daily"><a href="index@.html#daily">DAILY</a></li>
<li><a href="weekly.html" >WEEKLY</a></li>
<li><a href="customize.html" >CUSTOMIZE MENU</a></li>

</ul>
		</div>
	</div>

	
</section>

		<div id="preloader">
			<img class="preloader__logo" src="<?php echo SITE_URL;?>images/logo.png" alt="" width="100" height="100"/>
			<div class="preloader__progress">
				<svg width="60px" height="60px" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
					<path class="preloader__progress-circlebg" fill="none" stroke="#dddddd" stroke-width="4" stroke-linecap="round" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					<path id='preloader__progress-circle' fill="none" stroke="#fe6367" stroke-width="4" stroke-linecap="round" stroke-dashoffset="192.61" stroke-dasharray="192.61 192.61" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
				</svg>
			</div>
		</div>

<div id="wrapper" class="wide-wrap">
    
    <section class="verification_section">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						
						<h1>Verification</h1>
						<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" class="form" role="form">
						<input type="hidden" name="act" value="VERIFY">
						<input type="hidden" name="key" value="<?php echo $_REQUEST['key'];?>">
						<?php
								if($msg!="")
								{
								?>
						<span><font color="#FE5E0A">
								<?php
								echo $msg;
								?></font>
							</span>
							<br>
							<?php
							}
							?>
                    <input type="text" class="form-control" placeholder="Enter Verification code then your account will be activate."  name="activation"  maxlength="8" required/>
                    
                    <br>
                    <button class="btn btn-warning" type="submit">
                        Verify</button>
						</form>
						<form name="frmresend" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
						<input type="hidden" name="act" value="RESEND">
						<input type="hidden" name="key" value="<?php echo $_REQUEST['key'];?>">
						<?php
								if($msg1!="")
								{
								?>
						<span><font color="#FE5E0A">
								<?php
								echo $msg1;
								?></font>
							</span>
							<br>
							<?php
							}
							?>
                                                        <br/>
                                                        <button class="btn btn-warning`" type="submit">Resend</button>
                                                        <br/>
                                            </form>
					</div>
					<div class="col-md-2">&nbsp;</div>
					<div class="col-md-5"></div>
				</div>
			</div>		
		</section>
    
</div>
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>