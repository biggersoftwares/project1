<?php 
include_once("admin/config/constants.php");
include_once("config/db_connection.php");
include_once("includes/functions.php");
include_once("DBFns.php");
$db = new DBFns();
$sid =session_id();
if($_SESSION['sessionuser_id']=="")
{
	$cartItems = $db->get_cart_items($sid);
}else{
	$user_id=$_SESSION['sessionuser_id'];
	$cartItems = $db->get_user_cart_items($user_id);
}
if(empty($cartItems))
{
	header("Location:index.php");
	exit;
}
?>
<!doctype html>
<html lang="en-US">
	<head>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->
						
<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->

<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	

<div class="content-container">
		<form name="frmEBSPay" id="frmEBSPay" method="post" action="success.php" >
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div class="commerce">
									
										<table class="table shop_table cart">
											<thead>
												<tr>
													
													<th class="product-thumbnail hidden-xs">Item Image</th>
													<th class="product-name">Product</th>
													<th class="product-price text-center">Price</th>
													<th class="product-quantity text-center">Quantity</th>
													<th class="product-subtotal text-center hidden-xs">Total</th>
												</tr>
											</thead>
											<tbody>
											<?php
												$cart_subtotal=0;
												$shipping=0;
												foreach ($cartItems as $ckey=>$items){
												$product=$items[product][0];
												$product_images=$product['product_images'];
												$product_price=$product[product_prices];
												$sale_price=$product_price[0]['sale_price'];
												$subtotal=($items['qty']*$sale_price);
												?>
											<tr>
											<td class="product-thumbnail hidden-xs">
														<a href="#">
															<img  src="<?php echo SITE_URL;?>prod_images/<?php echo $product['prodimage_original'];?>" alt="<?php echo trim(stripslashes($product['product_name']));?>"/>
														</a>
													</td>
													<td class="product-name">
														<a href="#" onClick="return showprod(<?php echo $product['product_id'];?>)"> <?php echo trim(stripslashes($product['product_name'])); ?></a>
														<dl class="variation">
															<dt class="variation-Color">Kcal:</dt>
															<dd class="variation-Color"><p><?php echo $product['calories'];?></p></dd>
														</dl>
														<dl class="variation">
															<dt class="variation-Color">Size:</dt>
															<dd class="variation-Color"><p><?php echo $product_price[0]['size_name'];?></p></dd>
														</dl>
													</td>
													<td class="product-price text-center">
														<span class="amount"><i class="fa fa-inr"></i> <?php echo $sale_price;?></span>
													</td>
													<td class="product-quantity text-center">
														<div class="quantity">
														<?php echo $items['qty'];?>
															
														</div>
													</td>
													<td class="product-subtotal hidden-xs text-center">
														<span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($subtotal);?>.00</span>
													</td>
											</tr>
												<?php 
												$cart_subtotal+=$subtotal;
												}?>
											
											</tbody>
										</table>
									
									<div class="cart-collaterals">
										<div class="payment_mode">
											Payment Gateway Details here
										</div>
										<div class="cart_totals">
											<h2>Cart Totals</h2>
											<table>
												<tr class="cart-subtotal">
													<th>Subtotal</th>
													<td><span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($cart_subtotal, 2, '.', '');?></span></td>
												</tr>
												<?php 
												$shipping="";
												if($shipping=="")
												{
												$ship='Free';
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal*$shipping)/100;
												$cart_subtotal=$cart_subtotal+$grandtotal;
												}
												?>
												<tr class="shipping">
													<th>Shipping</th>
													<td><span class="amount"><i class="fa fa-inr"></i> <?php echo $ship;?></span></td>
												</tr>
												<tr class="order-total">
													<th>Total</th>
													<td><strong><span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($cart_subtotal, 2, '.', '');?></span></strong></td>
												</tr>
											</table>
											<div class="wc-proceed-to-checkout">
												<button type="submit" class="checkout-button button alt wc-forward">Place Order</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				</form>
			</div>

		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
</body>
</html>