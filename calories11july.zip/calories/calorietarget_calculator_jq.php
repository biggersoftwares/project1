<?php
/*http://www.docruppel.com/calorie_target_calculator.htm*/

/*
**********************************************************************************

 function calcCtc()
{ 
var A=document.ctc.age.value*1;
var H=document.ctc.height.value*1;
var W=document.ctc.weight.value*1;
var Al=document.ctc.activity.value*1;
displayctc = (Math.round((4.95*W*Al)+(16.78*H*Al)+(387-7.31*A)));

document.ctc.answer.value = displayctc;
}
//  End -->
<!-- Begin men
 function calcCtcm()
{ 
var v=document.ctcm.age.value*1;
var x=document.ctcm.height.value*1;
var y=document.ctcm.weight.value*1;
var z=document.ctcm.activity.value*1;
displayctcm = (Math.round((6.46*y*z)+(12.8*x*z)+(864-9.72*v)));

document.ctcm.answer.value = displayctcm;
}



	*/



$height=strip_tags(trim($_POST['height']));
$weight=strip_tags(trim($_POST['weight']));
$age=strip_tags(trim($_POST['age']));
$gender=strip_tags(trim($_POST['gender']));


$activity_level=strip_tags(trim($_POST['activity_level']));

if($gender==1)
{
/*	ACTIVITY
                Women	    Men
Sedentary		1.0      	1.0
Low Active		1.14	    1.12
Active		    1.27	    1.27
Very Active		1.45	    1.54*/
	// (6.46*Weight*activity)+(12.8*Height*activity)+(864-9.72*age)
 if($activity_level==1)
 {
	   $level = 1.0 ; 
 }
 else if($activity_level==2)
 {
	   $level = 1.12; 
 }
  else if($activity_level==3)
 {
	  $level =  1.27; 
 }
  else if($activity_level==4)
 {
	    $level =  1.54; 
 }
 else
 {
	 $level =0;
 }
 
 $result=(6.46*$weight*$level)+(12.8*$height*$level)+(864-9.72*$age);

}
else
{
	// (4.95*Weight*activity)+(16.78*Height*activity)+(387-7.31*age));
 if($activity_level==1)
 {
	   $level = 1.0 ; 
 }
 else if($activity_level==2)
 {
	   $level = 1.12; 
 }
  else if($activity_level==3)
 {
	  $level =  1.27; 
 }
  else if($activity_level==4)
 {
	    $level =  1.54; 
 }
 else
 {
	 $level =0;
 }
 
 $result=(4.95*$weight*$level)+(16.78*$height*$level)+(387-7.31*$age);
   
}
	// *****************************  CARBOHYDRATE INTAKE CALCULATOR  *********************		

echo round($result);
?>
