<?php
/*http://www.calculator.net/bmr-calculator.html*/
$height=strip_tags(trim($_POST['height']));
$weight=strip_tags(trim($_POST['weight']));
$age=strip_tags(trim($_POST['age']));
$gender=strip_tags(trim($_POST['gender']));

if($gender==1)
echo $bmr= 10 * $weight + 6.25 * $height - 5 * $age + 5 ;  
else
echo $bmr= 10 * $weight + 6.25 * $height - 5 * $age + 161 ;  
?>
