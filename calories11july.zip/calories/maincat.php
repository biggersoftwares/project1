 <?php ?>
<section id="menu">
	<div class="con tabs_section">
	<div class="container ">
	
		<div id="menub" style="text-align:center;" class="row">
					<h4>MENU</h4>
          <div id="daily" class="col-md-4"> <a href="index.php#daily">DAILY</a></div>
          <div class="col-md-4"> <a href="weekly.html">WEEKLY</a></div>
          <div class="col-md-4"> <a href="customize.html">CUSTOMIZE MENU</a></div>

		</div>
	</div>
	</div>

	
</section>
<?php ?>