<?php
ob_start();
session_start();
$sid=session_id();
include("config/db_connection.php");
//session_destroy();
unset($_SESSION['sessionuser_id']);
unset($_SESSION['sessionuser_name']);



/* $sql="select  * from temp_cart where sid='".$sid."'";
$res=mysql_query($sql);
if(mysql_num_rows($res)>0)
{
$del_cart="delete  from temp_cart where sid='".$sid."'";
mysql_query($del_cart);
} */
session_destroy();
header("Location:index.php");
?>
