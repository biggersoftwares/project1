<?php
session_start();
include_once("google/Google_Client.php");
include_once("google/contrib/Google_Oauth2Service.php");
######### edit details ##########
$clientId = '297437794849-6rkp1vb3g5p2tp8sdjt4u7s2h1d8egtv.apps.googleusercontent.com'; //Google CLIENT ID
$clientSecret = 'A9cX5eBtKAug91YjHbxZQuS7'; //Google CLIENT SECRET
$redirectUrl = 'http://localhost/calories/myaccount.php';  //return url (url to script)
$homeUrl = 'http://localhost/calories/myaccount.php';  //return to home

##################################

$gClient = new Google_Client();
$gClient->setApplicationName('biggersoftwares');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectUrl);

$google_oauthV2 = new Google_Oauth2Service($gClient);

/*****************************************************************************/

include_once("facebook/facebook.php"); //include facebook SDK
######### Facebook API Configuration ##########
$appId = '141362842953119'; //Facebook App ID
$appSecret = 'd8a6055da399c38ffac9a1bb3589dc28'; // Facebook App Secret
$homeurl = 'http://localhost/calories/myaccount.php';  //return to home
$fbPermissions = 'email';  //Required facebook permissions

//Call Facebook API
$facebook = new Facebook(array(
		'appId'  => $appId,
		'secret' => $appSecret

));
$fbuser = $facebook->getUser();


?>
