<?php
print_r($_REQUEST);
if(isset($_REQUEST["act"])&&$_REQUEST["act"]=="social_login"){
	if(isset($_REQUEST["type"])&&$_REQUEST["type"]=="facebook"){
		header("location: google_login.php");
	}else{
		header("location: facebook_login.php");
	}
}
?>