<?php 
include_once("config.php");
include_once("google_login.php");
include_once("facebook_login.php");

?>