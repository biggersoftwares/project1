<?php
include("config/db_connection.php");
include("includes/functions.php");
$ndbno=$_REQUEST['id'];		
$sql_main="select * from calorie_table1  where ndbno='".$ndbno."'";
$res_main=mysqli_query($conn, $sql_main);
$row_main=mysqli_fetch_array($res_main);
?>
<!doctype html>
<html lang="en-US">
	<head>
	<?php
	include_once("config/db_connection.php");
	include_once("includes/functions.php");
	include_once("DBFns.php");
	?>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->
						
<body data-spy="scroll">
	<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	
<!-- ---------------------------------------      ------------------------------------------------- -->
		<div class="content-container">
				<section class="facts_table">
    		<div class="container">
			
    			<div class="row">
                <h1 class="searched_">Basic Report : <span><?php echo $ndbno;?> ,  <?php echo $row_main['name'];?></span></h1>
				<?php
				 $sql_group="select * from calorie_table2  where ndbno='".$ndbno."' limit 1";
$res_group=mysqli_query($conn, $sql_group);
$row_group=mysqli_fetch_array($res_group);
$nutrient_id=$row_group['nutrient_id'];

 $sql_group1="select * from calorie_table3  where ndbno='".$ndbno."' and nutrient_id=".$nutrient_id ." order by id3 ASC";
$res_group1=mysqli_query($conn, $sql_group1);

?>
    					<div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Nutrient</th>
        <th>Unit</th>
        <th>Value per <br>100 g</th>
        <?php
		$a=0;
		$arr_val=array('5g','28.4g','227g','113g');
       while($row_group1=mysqli_fetch_array($res_group1))
		{
			?>
        <th><?php echo $row_group1[3];?><br><?php echo $arr_val[$a];?></th>
        <?php
		$a++;
		}
		?>
        
      </tr>
    </thead>
    <tbody>
    <?php
	 $sql_group3="select * from calorie_table2  where ndbno='".$ndbno."' group by ngroup order by id2 ASC";
$res_group3=mysqli_query($conn, $sql_group3);
while($row_group3=mysqli_fetch_array($res_group3))
{
?>
    <tr><th colspan="7" style="background-color:#6CC;"><?php echo trim($row_group3['ngroup']);?>  </th></tr>
    <?php
$sql_group4="select * from calorie_table2  where ndbno='".$ndbno."' and ngroup like '%".trim($row_group3['ngroup'])."%'";
$res_group4=mysqli_query($conn, $sql_group4);
		while($row_group4=mysqli_fetch_array($res_group4))
		{
			$sql_group5="select * from calorie_table3  where ndbno='".$ndbno."' and nutrient_id=".$row_group4['nutrient_id'];
			$res_group5=mysqli_query($conn, $sql_group5);
			
			
			?>
			  <tr>
				<td><?php echo $row_group4['name'];?></td>
				<td><?php echo $row_group4['unit'];?></td>
				<td><?php echo $row_group4['value'];?></td>
                <?php
				while($row_group5=mysqli_fetch_array($res_group5))
				{
					?>
				<td><?php echo $row_group5['value'];?></td>
                <?php
				}
				?>
				
			  </tr>
			  <?php
		}// second while
}// first while
?>
    </tbody>
  </table>
  </div>
    						
    					</ul>

          <br clear="all">
          <div class="col-md-4">
          
              

              </div>
    					
    				
    			</div>
				
    			</div>
    		</div>
				
<!-- ----------------------------------------     ------------------------------------------------ -->
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		</body>
</html>