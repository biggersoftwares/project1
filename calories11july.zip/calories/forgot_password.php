<?php 
include("config/dbpdo.php");
include("includes/functions.php");
include("includes/mail_function.php");
include_once("config/db_connection.php");
include_once("DBFns.php");

$msg="";
if($_REQUEST['act']=='FORGOT')
{
$user_email=trim($_POST['user_email']);



		
	$res=mysql_query("select * from users where user_email='".$user_email."' and status=1");
		$row=mysql_fetch_array($res);
		$num=mysql_num_rows($res);
		if($num>=1)
		{
$subject = 'Your account on My Calorie';
// message

 $message = '<div marginheight="0" marginwidth="0">
    	<div style="background-color:#f5f5f5;width:100%;margin:0;padding:70px 0 70px 0">
        	<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
            	<tbody>
                	<tr>
                    <td valign="top" align="center">
						
                        <table width="600" cellspacing="0" cellpadding="0" border="0" style="border-radius:6px!important;background-color:#fdfdfd;border:1px solid #dcdcdc;border-radius:6px!important">
                        	<tbody>
                            	<tr>
                                	<td valign="top" align="center">
                                		<table width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#557da1" style="background-color:#557da1;color:#ffffff;border-top-left-radius:6px!important;border-top-right-radius:6px!important;border-bottom:0;font-family:Arial;font-weight:bold;line-height:100%;vertical-align:middle">
                                        	<tbody>
                                            	<tr>
                                                	<td>
                                            			<h1 style="color:#ffffff;margin:0;padding:28px 24px;display:block;font-family:Arial;font-size:30px;font-weight:bold;text-align:left;line-height:150%">Welcome to Reitake</h1>

                                            		</td>
                                        		</tr>
                                            </tbody>
                                        </table></td>
                            	</tr>
                                <tr>
                                	<td valign="top" align="center">
                                		
                                        	<table width="600" cellspacing="0" cellpadding="0" border="0">
                                            	<tbody>
                                                	<tr>
                                                    	<td valign="top" style="background-color:#fdfdfd;border-radius:6px!important">
                                                			
                                                            <table width="100%" cellspacing="0" cellpadding="20" border="0">
                                                            	<tbody>
                                                                	<tr>
                                                                    	<td valign="top">
                                                            				<div style="color:#737373;font-family:Arial;font-size:14px;line-height:150%;text-align:left">
																				<p>Your Password is <strong>'.$row['pwd'].'</strong>.</p>
																				
																				
                                                                            </div>
                                                                          
                                                                        </td>
                                                                   </tr>
                                                                </tbody>
                                                           </table>
                                                      </td>
                                                  </tr>
                                              </tbody>
                                         </table>
                                   </td>
                               </tr>
                               <tr>
                               	<td valign="top" align="center">
                                	<table width="600" cellspacing="0" cellpadding="10" border="0" style="border-top:0">
                                    	<tbody>
                                        	<tr>
                                            	<td valign="top">
                                                	<table width="100%" cellspacing="0" cellpadding="10" border="0">
                                                    	<tbody>
                                                        	<tr>
                                                            	<td valign="middle" style="border:0;color:#99b1c7;font-family:Arial;font-size:12px;line-height:125%;text-align:center" colspan="2">
                                                        		<p>  My Calorie<br />

                                                                                www.mycalories.com</p>
                                                        		</td>
                                                    		</tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                        	</tr>
                                     	</tbody>
                                 	</table>
                             	</td>
                            </tr>
                       </tbody>
                   </table>
                </td>
              </tr>
           </tbody>
       </table>
   </div>

</div>';


$to = $_POST['user_email'];
$from_name="My Calorie";
$from_mail="pavankumarraju.n@gmail.com";

$username=$row['user_name'];
$files = array();



$head = array(

       'to'      =>array($to=>$username),

       'from'    =>array('pavankumarraju.n@gmail.com' =>'My Calorie'),

      // 'cc'      =>array('reitake.com@gmail.com'=>'Admin'),

       

       );

mail::send($head,$subject,$message, $files);
		
header("Location:login.php");
exit;
		
}
else
{
$msg="Wrong Mail ID.";
}
}
?>

<!doctype html>
<html lang="en-US">
	<head>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->
						
<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->

<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	
	
<!-- ---------------------------------------      ------------------------------------------------- -->

		<div id="wrapper" class="wide-wrap">
		
		<section class="login_section">
<div class="conten">
			<div class="container">
				<div class="row">
		
						<div class="col-md-3">&nbsp;</div>
					<div class="col-md-6">
						<form role="form" method="post" name="frmforgot" onSubmit="return validate();" action="<?php echo $_SERVER['PHP_SELF'];?>">
						<input type="hidden" name="act" value="">
						<h1 style="text-align:center;">Forgot Password</h1>
                    
                    <input type="email" placeholder="Your Email" name="user_email" class="form-control" required>
                    <?php
								if($msg!="")

								{

								?>

						<span><font color="#FE5E0A">

								<?php

								echo $msg;

								?></font>

							</span><br>

							<?php

							}

							?>
                    
                   
                    <b style="color:red">Note:</b> Password will sent to your Registered email.
                    <br>
                    <br>
                    
                      <button data-target="#myModal5" data-toggle="modal" class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                     
                </form>
					</div>
					<div class="col-md-3">&nbsp;</div>
				</div>	
			</div>	
		</div>
		</section>		
		
		</div>

<!-- ----------------------------------------     ------------------------------------------------ -->
	<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		
		<script language="javascript" type="text/javascript">
	function validate()
	{
	//alert("HAIA");
	var frm=document.frmforgot;
	if(frm.user_email.value=="")
	{
		alert("Please Enter Email");
		return false;
	}

	frm.act.value='FORGOT';
	frm.submit();
	//return true;
}
</script>
		
</body>
</html>