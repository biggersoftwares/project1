<?php ?>
<!doctype html>
<html lang="en-US">
	<head>
		<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
		<?php	
		include("admin/config/constants.php");
		include("config/db_connection.php");
		include("includes/functions.php");
		include("DBFns.php");
		?>
		
	</head>
	
<?php 
$sid=session_id();
 if($_SESSION['sessionuser_id']=="")
 {
 	$user_id=0;
 }
 else
 {
 	$user_id=$_SESSION['sessionuser_id'];
 }
 if($_POST["update_cart"]=="Update Cart")
 {
 	$pids=$_POST['pids'];
 	if(count($pids)>0)
 	{
 
 		for($k=0;$k<count($pids);$k++)
 		{
 			$tid = $_POST['tids'][$k];
 			$qty="quantity_".$tid;
 			$updqty= $_POST[$qty];
 
 			$upd_cart="update temp_cart set user_id=".$user_id.",qty=".$updqty." where temp_id=".$tid;
 			$res=mysql_query($upd_cart);
 		}
 
 	}
 
 
 }
 if($_POST['act']=='DELETECART')
 {
 	$tid=strip_tags(trim($_REQUEST['tid']));
 	$del_cart="delete  from temp_cart where temp_id='".$tid."'";
 	mysql_query($del_cart);
 
 	$sql_cart_disp="select * from temp_cart where sid='".$sid."'";
 	$res_cart_disp=mysql_query($sql_cart_disp);
 	mysql_num_rows($res_cart_disp);
 	if(mysql_num_rows($res_cart_disp)==0)
 	{
 		header("Location:index.php");
 		
 		//exit;
 	}
 }
 //echo $sid;
 //$products=view_products_maincat(1);//for products is 1
 $db = new DBFns();
 if($_SESSION['sessionuser_id']=="")
 {
 	$cartItems = $db->get_cart_items($sid);
 }else{
 	$user_id=$_SESSION['sessionuser_id'];
 	$cartItems = $db->get_user_cart_items($user_id);
 }
 /* echo "<pre>";
  print_r($cartItems);
  echo "</pre>"; */
 
?>
<!-- cart display end -->
	<body id="page-top" data-spy="scroll"    >
		
<!-- cart display start -->
	<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->	

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->			

<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->			
		

<?php 


// echo "<pre>";
//  print_r($_POST);
//  echo "</pre>";

 if($_SESSION['sessionuser_id']=="")
 {
 	$user_id=0;
 }
 else
 {
 	$user_id=$_SESSION['sessionuser_id'];
 }
 if($_POST["update_cart"]=="Update Cart")
 {
 	$pids=$_POST['pids'];
 	if(count($pids)>0)
 	{
 
 		for($k=0;$k<count($pids);$k++)
 		{
 			$tid = $_POST['tids'][$k];
 			$qty="quantity_".$tid;
 			$updqty= $_POST[$qty];
 
 			$upd_cart="update temp_cart set user_id=".$user_id.",qty=".$updqty." where temp_id=".$tid;
 			$res=mysql_query($upd_cart);
 		}
 
 	}
 
 
 }
 //echo $sid;
 //$products=view_products_maincat(1);//for products is 1
 $db = new DBFns();
 $sid=session_id();
 if($_SESSION['sessionuser_id']=="")
 {
 	$cartItems = $db->get_cart_items($sid);
 }else{
 	$user_id=$_SESSION['sessionuser_id'];
 	$cartItems = $db->get_user_cart_items($user_id);
 }
 /* echo "<pre>";
  print_r($cartItems);
  echo "</pre>"; */
?>


		<div class="content-container">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div class="commerce">
									<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" name="frmcart" id="frmcart">
										<table class="table shop_table cart">
											<thead>
												<tr>
													<th class="product-remove hidden-xs">&nbsp;</th>
													<th class="product-thumbnail hidden-xs">&nbsp;</th>
													<th class="product-name">Product</th>
													<th class="product-price text-center">Price</th>
													<th class="product-quantity text-center">Quantity</th>
													<th class="product-subtotal text-center hidden-xs">Total</th>
												</tr>
											</thead>
											<tbody>
											<?php
											if(!empty($cartItems)){
												$total=0;
												$shipping=0;
												foreach ($cartItems as $ckey=>$items){
												$product=$items['product'][0];
												$product_images=$product['product_images'];
												$product_price=$product['product_prices'];
												$sale_price=$product_price[0]['sale_price'];
												$tot_price=($items['qty']*$sale_price);
												$total+=$tot_price;
												?>
												<tr class="cart_item">
													<td class="product-remove hidden-xs">
														<a href="#" onClick="return deletecart(<?php echo $items['temp_id'];?>)" class="remove" title="Remove this item" tid="<?php echo $items['temp_id'];?>">&times;</a>
													</td>
													<td class="product-thumbnail hidden-xs">
														<a href="#">
															<img src="<?php echo SITE_URL;?>prod_images/<?php echo $product_images['prodimage_original'];?>" alt="<?php echo $product[product_name];?>" class="cart-image" style="height:200px;width:200px;"/>
														</a>
													</td>
													<td class="product-name">
													<a href="#" onClick="return showprod(<?php echo $product['product_id'];?>)"> <?php echo trim(stripslashes($product['product_name'])); ?></a>
														<dl class="variation">
															<dt class="variation-Color">Kcal:</dt>
															<dd class="variation-Color"><p><?php echo $product['calories'];?></p></dd>
															<dt class="variation-Size">Size:</dt>
															<dd class="variation-Size"><p><?php echo $product_price[0]['size_name'];?></p></dd>
														</dl>
													</td>
													<td class="product-price text-center">
														<span class="amount">&#8360;<?php echo $sale_price;?></span>
													</td>
													<td class="product-quantity text-center">
														<div class="quantity">
															<input type="number" step="1" min="1" name="quantity_<?php echo $items['temp_id'];?>" value="<?php echo $items['qty'];?>" title="Qty" class="input-text qty text" size="4" max="9" style="width:60px;"/>
															<input type="hidden" name="pids[]" value="<?php echo $items['prod_id'];?>" />
															<input type="hidden" name="tids[]" value="<?php echo $items['temp_id'];?>" />
														</div>
													</td>
													<td class="product-subtotal hidden-xs text-center">
														<span class="amount">&#8360;<?php echo $tot_price;?></span>
													</td>
												</tr>
												<?php }?>
												
												<tr>
													<td colspan="6" class="actions">
														<div class="coupon">
															<label for="coupon_code">Coupon:</label> 
															<input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code"/> 
															<input type="submit" class="button" name="apply_coupon" value="Apply Coupon"/>
														</div>
														<input type="submit" class="button update-cart-button" name="update_cart" value="Update Cart"/>
													</td>
												</tr>
												<?php }else{
													?>
												<tr>
												<td colspan="6" align="center"><a  class="button wc-forward gotoshoping">GO TO SHOPING</a></td>
													
												</tr>
													<?php
												}?>
											</tbody>
										</table>
									</form>
									<?php if(!empty($cartItems)){?>
									<div class="cart-collaterals">
										<div class="cart_totals">
											<h2>Cart Totals</h2>
											<table>
												<tr class="cart-subtotal">
													<th>Subtotal</th>
													<td><span class="amount">&#8360; <?php echo $total;?></span></td>
												</tr>
												<?php 
												if($shipping=="")
												{
													$ship='Free';
													$cart_subtotal=$total;
												}
												else
												{
													$ship=$shipping."  % ";
												
													$grandtotal=($total*$shipping)/100;
													$cart_subtotal=$total+$grandtotal;
												}
												?>
												<tr class="shipping">
													<th>Shipping</th>
													<td><span class="amount">&#8360; <?php echo $ship;?></span></td>
												</tr>
												<tr class="order-total">
													<th>Total</th>
													<td><strong><span class="amount">&#8360; <?php echo $cart_subtotal;?></span></strong></td>
												</tr>
											</table>
											<div class="wc-proceed-to-checkout">
												<a href="checkout.php" class="checkout-button button alt wc-forward">Proceed to Payment</a>
											</div>
										</div>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
	<form name="frmcart" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

      <input type="hidden" name="pid" value="" />

	   <input type="hidden" name="act" value="" />

      </form>
      
	<form name="frmdelcart" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
      <input type="hidden" name="tid" value="" />
	   <input type="hidden" name="act" value="" />
      </form>
      
	  <form name="frmshow" method="post" action="productdetails.php">

      <input type="hidden" name="pid" value="" />

      </form>	
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		
		<script type="text/javascript">
		function addtocart(id)
		{	
		var frm=document.frmcart;

			frm.pid.value=+id;

			frm.act.value="ADDTOCART";

			frm.submit();

		}
		function deletecart(id)
		{
			var frm=document.frmdelcart;
			//alert(id);
			frm.tid.value=+id;
			frm.act.value="DELETECART";
			frm.submit();
		}
		function showprod(id)

		{	

		var frm=document.frmshow;

			frm.pid.value=+id;

			frm.submit();

		}
		</script>
		
			</body>
</html>                                                                                                                                                                                                                                                                       
<?php ?>
		
