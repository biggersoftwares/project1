<!doctype html>
<html lang="en-US">
	<head>
	<?php
	include_once("config/db_connection.php");
	include_once("includes/functions.php");
	include_once("DBFns.php");
	?>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->
						
<body data-spy="scroll">
	<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	
<!-- ---------------------------------------      ------------------------------------------------- -->
		<div id="wrapper" class="wide-wrap">
		
		<div class="content-container">
	</div>
		
		</div>
		
<!-- ----------------------------------------     ------------------------------------------------ -->
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		</body>
</html>