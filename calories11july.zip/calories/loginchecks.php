<?php
include_once("admin/config/constants.php");
include_once("config/db_connection.php");
include_once("includes/functions.php");
include_once("DBFns.php");

if($_POST['act']=='CHECKLOGIN')
{
$lmsg="";
$email_id=strip_tags(trim($_POST['lemail_id']));

$pwd=strip_tags(trim($_POST['lpwd']));	
$sql="select * from users where user_email='".$email_id."' and pwd='".$pwd."' and status=1";


                $res=mysql_query($sql);  

                if($res === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
		
                $cnt=  mysql_num_rows($res);
                
		if($cnt==1)

		{

			$row = mysql_fetch_array($res);

			$_SESSION['sessionuser_name']=$row['user_name'];
			$_SESSION['sessionuser_id']=$row['user_id'];

			if($_SESSION['redirect']=='aftercartlogin')
			{
			header("Location:checkout.php");

			exit;
			}
			else
			{
			//header("Location:myaccount.php");
                            $lmsg="succuss";
			}

		}

		else
		{
		$lmsg="Wrong Email Id  or Password.";
		}
                
                echo json_encode(array("lmsg"=>$lmsg));
}
?>
