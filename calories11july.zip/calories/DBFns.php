<?php

class DBFns {
	function get_all_products($pid=0,$psz_id="",$maincrt="",$fdtype="",$pname="") {
		
		$pid_con="";
		if($pid!=0){
			$pid_con="and p.product_id=".$pid;
		}
		
		$maincrt_con="";
		if($maincrt!=0){
			$maincrt_con="and p.maincat_id=".$maincrt;
		}
		
		$fdtype_con="";
		if($fdtype!=0){
			$fdtype_con="and p.food_type=".$fdtype;
		}
		
		$pname_con="";
		if(!empty($pname)){
		 $pname_con=" and p.product_name like '%".stripslashes(trim($pname))."%' ";
		}
		
		//echo "<br/><br/>";
	 $sql = "SELECT p.* ,pr.regular_price,pr.sale_price,pz.size_name,pd.prod_desc,pi.prodimage_original FROM products AS p 
				INNER JOIN product_prices AS pr ON pr.product_id = p.product_id
				INNER JOIN product_size AS pz ON pz.product_size_id = pr.product_size_id 
				INNER JOIN product_desc AS pd ON pd.product_id = p.product_id 
				INNER JOIN product_images AS pi ON pi.product_id = p.product_id 
				WHERE p.status = 1 $pid_con  $maincrt_con $fdtype_con $pname_con GROUP BY pr.product_id ORDER BY pr.product_size_id DESC";
		$res = mysql_query($sql);
		$return =  array();
		if(!empty($res)){
		while ($row=mysql_fetch_array($res,1)) {
			$return[] = $row;
		}
		for($i=0;$i<count($return);$i++) {
			$product_id = $return[$i]['product_id'];
			
			$sql1 = " SELECT AVG(rating) AS review FROM reviews AS r WHERE r.product_id = $product_id ";
			$res1 = mysql_query($sql1);
			$preview = 0;
			while ($row1=mysql_fetch_array($res1,1)) {
				$preview = $row1['review'];
			}
			$return[$i]['review'] = $preview;
			
			
			$sql1 = " SELECT prodimage_id,prodimage_original FROM product_images AS r WHERE r.product_id = $product_id ";
			$res1 = mysql_query($sql1);
			while ($row1=mysql_fetch_array($res1,1)) {
				$return[$i]['product_images'] = $row1;
			}
			
			$product_prices=$this->product_prices($product_id,$psz_id);
			$return[$i]['product_prices'] = $product_prices;
		}
	}
		//print json_encode($return);
		
		return  $return;
	}
	
	function product_prices($product_id,$psz_id="")
	{
	
		$psz_id_con="";
	if(!empty($psz_id)){
	 $psz_id_con="and pp.product_size_id=$psz_id ";
	}
	$product_prices=array();
	$sql1 = " SELECT pp.price_id,pp.product_size_id,pp.regular_price,pp.sale_price,ps.size_name FROM product_prices pp JOIN product_size ps on pp.product_size_id=ps.product_size_id Where pp.product_id = $product_id $psz_id_con";
	$res1 = mysql_query($sql1);
	while ($row1=mysql_fetch_array($res1,1)) {
	$product_prices[] = $row1;
	}
		return $product_prices;
	
	}
	
	function get_cart_items($sid,$pid=0) {
		
		$pid_con="";
		if($pid!=0){
			$pid_con="and prod_id=".$pid;
		}
	
		$sql = "select * from temp_cart where sid='".$sid."' $pid_con  ORDER BY prod_id DESC ";
		$res = mysql_query($sql);
		$return =  array();
		if(!empty($res)){
		while ($row=mysql_fetch_array($res,1)) {
			$return[] = $row;
		}
		
		//print_r($return);
		$products=array();
		foreach ($return as $tkey=>$tem_cart){
			$prod_id = $tem_cart['prod_id'];
			$psz_id = $tem_cart['product_size_id'];
			
			$return[$tkey]['product']=$this->get_all_products($prod_id,$psz_id);
			
		}
		
		}
		//print json_encode($return);
	
		return  $return;
	}
	
	function get_user_cart_items($uid,$pid=0) {
	
		$pid_con="";
		if($pid!=0){
			$pid_con="and prod_id=".$pid;
		}
	
		$sql = "select * from temp_cart where user_id='".$uid."' $pid_con  ORDER BY prod_id DESC ";
		$res = mysql_query($sql);
		$return =  array();
		if(!empty($res)){
			while ($row=mysql_fetch_array($res,1)) {
				$return[] = $row;
			}
	
			//print_r($return);
			$products=array();
			foreach ($return as $tkey=>$tem_cart){
				$prod_id = $tem_cart['prod_id'];
				$psz_id = $tem_cart['product_size_id'];
					
				$return[$tkey]['product']=$this->get_all_products($prod_id,$psz_id);
					
			}
	
		}
		//print json_encode($return);
	
		return  $return;
	}
}
?>