<?php

if(!empty($_REQUEST['is_ajax'])){
	session_start();
	include_once("admin/config/constants.php");
	include_once("config/db_connection.php");
	include_once("includes/functions.php");
	include_once("DBFns.php");
}

$db = new DBFns();
$pid="";
$psz_id="";
$maincrt="";
$fdtype="";
$pname="";

//print_r($_REQUEST);

if(!empty($_REQUEST["ppid"])){
	 $pid=$_REQUEST["ppid"];
}
if(!empty($_REQUEST["psz_id"])){
	$psz_id=$_REQUEST["psz_id"];
}
if(!empty($_REQUEST["maincrt"])){
	$maincrt=$_REQUEST["maincrt"];
}
if(!empty($_REQUEST["fdtype"])){
	$fdtype=$_REQUEST["fdtype"];
}
if(!empty($_REQUEST["pname"])){
	$pname=$_REQUEST["pname"];
}

 $pid." ===== ".$psz_id." ===== ".$psz_id." ==== ".$maincrt." === ".$fdtype." ==== ".$pname;


$products = $db->get_all_products($pid,$psz_id,$maincrt,$fdtype,$pname);

/* echo "<pre>";
print_r($products);
echo "</pre>"; */
?>

		<!-- include all js files -->
		<?php //include("includes/metatags.php"); ?>
		
<div class="content-container">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div data-layout="masonry" data-masonry-column="3" class="commerce products-masonry masonry">
									<div class="masonry-filter">
										<div class="filter-action filter-action-center">
											<ul data-filter-key="filter">
												<li>
													<a href="#" data-filter-value=".Veg">Veg</a>
												</li>
												<li>
													<a href="#" data-filter-value=".NonVeg">Non Veg</a>
												</li>
											</ul>
										</div>
									</div>
									<div class="products-masonry-wrap">
										<ul class="products masonry-products row masonry-wrap">
										<?php 
										foreach ($products as $key=>$product) {
											$review=$product['review'];
											$product_images=$product['product_images'];
											$product_prices=$product['product_prices'];
											$foodtype=$product['food_type'];
											if($foodtype==1){
												$class="main";
											}else if($foodtype==2){
												$class="dessert";
											}
											if($val['food_type']==1)
											{
												$tab="Veg";
												$class="veg";
												$text="Veg";
											}
											else
											{
												$tab="NonVeg";
												$class="non_veg";
												$text="Non Veg";
											}
										?>
										<li class="product masonry-item col-md-4 col-sm-6 <?php echo $tab;?>">
												<div class="product-container" pid=<?php echo $product[product_id]?>>
													<figure>
														<div class="product-wrap">
															<div class="product-images">
																<div class="shop-loop-thumbnail">
																	<span class="<?php echo $class;?>"><?php echo $text;?></span>
																	<a href="productdetails.php?pid=<?php echo stripslashes($product[product_id]);?>">
																		<img width="500px" height="400px" src="<?php echo SITE_URL;?>prod_images/<?php echo $product_images['prodimage_original'];?>" alt="product-2" class="product-image" style="height:300px;width:500px;"/>
																	</a>
																</div>
															</div>
														</div>
														<figcaption>
															<div class="shop-loop-product-info">
																<div class="" style="margin-top: -71px; z-index: 8;">
														<ul class="rupee"     style="background-color: rgba(0,0,0,0.5);text-align: center;color:white;    padding-top: 13px; padding-bottom:8px;"><li><span><i class="fa fa-inr"></i>&nbsp;<span class="prodict_price"><?php echo $product['sale_price']?></span></span></li>
														<li>SIZE&nbsp;<select class="product_size">
														<?php foreach ($product_prices as $ppkey=>$ppvalue){?>
															<option value="<?php echo $ppvalue['product_size_id']?>" price="<?php echo $ppvalue['sale_price']?>" rprice="<?php echo $ppvalue['regular_price']?>"><?php echo $ppvalue['size_name']?></option>
														<?php }?>
														</select>
														</li>
														
														
														<li>Qty:&nbsp; <input type="number" name="quantity" min="1" max="20" value="1" placeholder ="1" style="color: black;" class="quantity"> </li>
														</ul>
														</div>
																<div class="info-title">
																	<h3 class="product_title">
																		<a href="productdetails.php?pid=<?php echo stripslashes($product['product_id']);?>"><?php echo stripslashes($product['product_name']);?></a>
																	</h3>
																</div>
																<div class="info-rating" style="text-align:center;">
																<?php
																$atot=ceil($review);
																for($r=1;$r<=$atot;$r++)
																{
																	?>
																	<img src="images/rating-1.png"/>
																	<?php
																	}
																	for($p=1;$p<=(5-$atot);$p++)
																	{
																	?>
																	<img src="images/rating-0.png"/>
																	<?php
																	}
																	?>
																</div>
																<br/>
																<div class="info-meta">
																	<div class="info-price">
																		<span class="price">
																			<span class="amount">
																			<img src="images/cal_icon.png"/><?php echo $product['calories']?>
																			</span>
																		</span>
																		<span class="price">
																			<ins><span class="amount fa fa-inr">&nbsp;<span class="prodict_price"><?php echo $product['sale_price']?></span></span></ins>
																			<del><span class="amount"><i class="fa fa-inr"></i><span class="reguler_price"><?php echo $product['regular_price'];?></span></span></del>
																		</span>
																	</div>
																</div>
																<div class="shop-loop-actions">
																	<a class="button add-to-cart">Add to cart</a>
																	<div class="clear"></div>
																</div>
															</div>
														</figcaption>
													</figure>
												</div>
											</li>
										
										<?php 
										}?>
										</ul>
									</div>
<!-- 									<div class="loadmore-action"> -->
<!-- 										<button type="button" class="btn-loadmore">Load More</button> -->
<!-- 									</div> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php ?>
<?php  //include("includes/js.php");?>