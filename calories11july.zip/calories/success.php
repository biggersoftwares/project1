<?php 
include_once("admin/config/constants.php");
include_once("config/db_connection.php");
include_once("includes/functions.php");
include_once("DBFns.php");
include("includes/mail_function.php");

$db = new DBFns();
$sid=session_id();
$transaction_id=rand(1000000,9999999);
$order_date=date('Y-m-d');
if($_SESSION['sessionuser_id']=="")
{
	$cartItems = $db->get_cart_items($sid);
}else{
	$user_id=$_SESSION['sessionuser_id'];
	$cartItems = $db->get_user_cart_items($user_id);
}
if(empty($cartItems))
{
	header("Location:index.php");
	exit;
}
?>
<!doctype html>
<html lang="en-US">
	<head>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->
						
<body data-spy="scroll">
	<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->	
<!-- ---------------------------------------      ------------------------------------------------- -->

		<div id="wrapper" class="wide-wrap">
		
		<div class="content-container">
		<form name="frmEBSPay" id="frmEBSPay" method="post" action="success.php" >
				<div class="container">
				<div class="row">
						<div class="col-md-12">
                         <h3 class="heading"> Your order has been received, Please check your account page for order details.</h3>
                       
						</div>
						</div>
						<div class="row">
						<div class="col-md-12">
						<h5>Your order no: #<?php echo $transaction_id;?> <span style="float:right; padding-right:70px; color:#F60;">Date : <?php echo date('d/m/Y h:i:s');?></span></h5>
                       
						</div>
						</div>
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div class="commerce">
									
										<table class="table shop_table cart">
											<thead>
												<tr>
													
													<th class="product-thumbnail hidden-xs">Item Image</th>
													<th class="product-name">Product</th>
													<th class="product-price text-center">Price</th>
													<th class="product-quantity text-center">Quantity</th>
													<th class="product-subtotal text-center hidden-xs">Total</th>
												</tr>
											</thead>
											<tbody>
											<?php
												$cart_subtotal=0;
												$shipping=0;
												foreach ($cartItems as $ckey=>$items){
												$product=$items['product'][0];
												$product_images=$product['product_images'];
												$product_price=$product['product_prices'];
												$sale_price=$product_price[0]['sale_price'];
												$subtotal=($items['qty']*$sale_price);
												?>
												<tr>
											<td class="product-thumbnail hidden-xs">
														<a href="#">
															<img  src="<?php echo SITE_URL;?>prod_images/<?php echo $product['prodimage_original'];?>" alt="<?php echo trim(stripslashes($product['product_name']));?>"/>
														</a>
													</td>
													<td class="product-name">
														<a href="#" onClick="return showprod(<?php echo $product['product_id'];?>)"> <?php echo trim(stripslashes($product['product_name'])); ?></a>
														<dl class="variation">
															<dt class="variation-Color">Kcal:</dt>
															<dd class="variation-Color"><p><?php echo $product['calories'];?></p></dd>
														</dl>
														<dl class="variation">
															<dt class="variation-Color">Size:</dt>
															<dd class="variation-Color"><p><?php echo $product_price[0]['size_name'];?></p></dd>
														</dl>
													</td>
													<td class="product-price text-center">
														<span class="amount"><i class="fa fa-inr"></i> <?php echo $sale_price;?></span>
													</td>
													<td class="product-quantity text-center">
														<div class="quantity">
														<?php echo $items['qty'];?>
															
														</div>
													</td>
													<td class="product-subtotal hidden-xs text-center">
														<span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($subtotal);?>.00</span>
													</td>
											</tr>
												<?php 
												$cart_subtotal+=$subtotal;
												}?>
												
											</tbody>
										</table>
									
									<div class="cart-collaterals">
										
										<div class="cart_totals">
											<h2>Cart Totals</h2>
											<table>
												<tr class="cart-subtotal">
													<th>Subtotal</th>
													<td><span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($cart_subtotal, 2, '.', '');?></span></td>
												</tr>
												<?php 
												$shipping="";
												if($shipping=="")
												{
												$ship='Free';
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal*$shipping)/100;
												$cart_subtotal=$cart_subtotal+$grandtotal;
												}
												?>
												<tr class="shipping">
													<th>Shipping</th>
													<td><span class="amount"><i class="fa fa-inr"></i> <?php echo $ship;?></span></td>
												</tr>
												<tr class="order-total">
													<th>Total</th>
													<td><strong><span class="amount"><i class="fa fa-inr"></i> <?php echo number_format($cart_subtotal, 2, '.', '');?></span></strong></td>
												</tr>
											</table>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				</form>
			</div>
		
		</div>
		
<!-- ----------------------------------------     ------------------------------------------------ -->
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		
 <?php
	//--------------------------------------------------------------------------

$sid=session_id();


// ---------------------------------------------------   User ---------------------


$sel_user="select * from bill_ship_address where user_id=".$_SESSION['sessionuser_id'];
$res_user=mysql_query($sel_user);
$row_user=mysql_fetch_array($res_user);
//  -----------------------------------------------  Invoice -------------------------

$payment_status='1';

 $payment_method='COD';

 $ip=$_SERVER['REMOTE_ADDR'];
 


		  $ins_invoice="insert into invoice ( 
									transaction_id,
									user_id,
									total_amount,
									payment_method,
									PaymentID,
									MerchantRefNo,
									TransactionID,
									PaymentMethod,
									RequestID,
									ResponseCode,
									ip,
									invoice_date,
									payment_status
								)	
								values
								
								(
									'".$transaction_id."',
									'".$_SESSION['sessionuser_id']."',
									'".$cart_subtotal."',
									'".$payment_method."',
									'".$PaymentID."',
									'".$MerchantRefNo."',
									'".$TransactionID."',
									'".$PaymentMethod."',
									'".$RequestID."',
									'".$ResponseCode."',
									'".$ip."',
									'".$order_date."',
									'".$payment_status."'
								)";
mysql_query($ins_invoice);
$lid=mysql_insert_id();

//  -------------------------- TEMP CART Details  ------------------------
  //$sel_temp="select * from temp_cart where  transaction_id='".$_REQUEST['MerchantRefNo']."'";
$sel_temp="select * from temp_cart where  sid='".$sid."'";
$res_temp=mysql_query($sel_temp);
$res_cart1=mysql_query($sel_temp);
$res_cart2=mysql_query($sel_temp);
while($row_temp=mysql_fetch_array($res_temp))
{
extract($row_temp);


$sel_prodprice="select * from products where product_id=".$prod_id;

$res_prodprice=mysql_query($sel_prodprice);
$row_prodprice=mysql_fetch_array($res_prodprice);
    $ins_orders="insert into orders ( 
									prod_id,
									user_id,
									invoice_id,
									regular_price,
									sale_price,
									qty,
									order_date
								)	
								values
								
								(
									'".$prod_id."',
									'".$_SESSION['sessionuser_id']."',
									'".$lid."',
									'".$row_prodprice['regular_price']."',
									'".$row_prodprice['sale_price']."',
									'".$qty."',
									'".$order_date."'
								)";
$res=mysql_query($ins_orders);


}
//exit;
//  send email customer




   $sql_mailuser="select * from bill_ship_address where user_id='".$_SESSION['sessionuser_id']."'";
$res_mailuser=mysql_query($sql_mailuser);
$row_mailuser=mysql_fetch_array($res_mailuser);

$subject = 'Your Mr Colorie order receipt from '.date('F, d Y') ;

// message
  $msg1 = '<table cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="max-width:730px!important;width:100%">
       
      
      
        <tbody><tr>
          <td width="30" bgcolor="#f3f3f3" background="https://ci6.googleusercontent.com/proxy/IkNIBG8aK-8hAtYIXYMT69bTUagHzGjgVJYggOPjbs2uNDp3NAinMtvzW9sigSEHLvqZ_KBAdCgGzC1sZrgjzfOqhPBxstt8=s0-d-e1-ft#http://i4.sdlcdn.com/img/eventImage/10/pattern.png"><table width="80%" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:562px">
            
              <tbody><tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="88" bgcolor="#FFFFFF"><table width="100%" cellspacing="0" cellpadding="0" border="0">
                  
                    <tbody><tr>
                      <td height="3" bgcolor="#313131"></td>
                    </tr>
                    <tr>
                      <td valign="middle" height="88"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                        
                          <tbody><tr>
                            <td width="943" height="88" align="left"><a href="'.SITE_URL.'"><img src="'.SITE_URL.'images/logo.png" alt="My Calorie" title="My Calorie" width="120" height="80"></a></td>
                          </tr>
                        
                      </tbody></table></td>
                    </tr>
                    <tr>
                      <td height="1" bgcolor="#f2f2f2"></td>
                    </tr><tr>
                      <td style="font-family:Calibri;font-size:14px;color:#757575;font-weight:normal"><table width="92%" cellspacing="0" cellpadding="0" border="0" align="center" style="max-width:507px">
                        
                          <tbody><tr>
                            <td height="65" align="center" style="font-family:Calibri;font-size:21px;color:#000000;font-weight:normal"><img width="20" height="16" style="margin:0 10px 0 0" alt="" src="https://ci3.googleusercontent.com/proxy/j6EIsXuHmNiyiF6-OauXvKitHQsLqHK8xHElYayK65JH_4LobX83EKSSE5UypD8Vm5AeA-KCZ_y66aOCHejMIRqgzzD7CQTpkd0=s0-d-e1-ft#http://i3.sdlcdn.com/img/eventImage/10/tick-icon.jpg" class="CToWUd">Your order has been received,We will be deliver soon.</td>
                          </tr>
                          <tr>
                          	<td><table width="500" cellspacing="0" cellpadding="0" border="0" align="left">
                          	  <tbody>
                          	    <tr>
                          	      <td><strong>Hi '.$row_mailuser['b_firstname']."  ".$row_mailuser['b_lastname'].'</strong>,
                                  	<p><strong>Email:&nbsp;&nbsp;&nbsp;</strong>'.$row_mailuser['s_emailid'].'<br/><strong>Tel:&nbsp;&nbsp;&nbsp;</strong>'.$row_mailuser['s_mobileno'].'</p>
                          	        <p>your order no.  : <a style="color:#009aca">#'.$transaction_id.'</a> </p>
                                   
                                    </td>
                        	      </tr>
                        	    </tbody>
                        	  </table></td>
                          </tr>
                          <tr>
                            <td><table width="210" cellspacing="0" cellpadding="0" border="0" align="left" style="margin-left:10px">
                              
                              <tbody><tr>
                                    <td align="right"><table width="210" cellspacing="0" cellpadding="20" border="0" align="center">
                                      
                                        <tbody><tr>
                                          <td bgcolor="#f6f6f6" style="color:#545454"><strong>Billing address</strong><br>
                                            '.$row_mailuser['b_firstname']."  ".$row_mailuser['b_lastname']."<br>".$row_mailuser['b_address']."<br>".$row_mailuser['b_city']."-".$row_mailuser['b_zipcode'].'</td>
                                          </tr>
                                        
                                      </tbody></table></td>
                                    </tr>
                                  
                              </tbody></table>
                              <table width="210" cellspacing="0" cellpadding="20" border="0" align="center">
                                <tbody>
                                  <tr>
                                    <td bgcolor="#f6f6f6" style="color:#545454"><strong>Shipping address</strong><br />
                                     '.$row_mailuser['s_firstname']."  ".$row_mailuser['s_lastname']."<br>".$row_mailuser['s_address']."<br>". $row_mailuser['s_city']."-".$row_mailuser['s_zipcode']."<br>".$row_mailuser['landmark'].'</td>
                                  </tr>
                                </tbody>
                              </table></td>
                          </tr>
                        
                          <tr>
                            <td>&nbsp;
    </td>
                          </tr>
                          <tr>
                            <td><table width="100%" cellspacing="0" cellpadding="0" border="0">
                              
                                <tbody><tr>
                                  <td valign="bottom" height="20" style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal"><span style="font-family:Calibri;font-size:16px;color:#000000;font-weight:normal">PRODUCT(S)</span></td>
                                  </tr>
                                                                                          <tr>
                                                                                            <td style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal">&nbsp;</td>
                                                                                          </tr>
                                                                                          <tr>
                                    <td style="font-family:Calibri;font-size:14px;color:#5d5d5d;font-weight:normal"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                                      
                                        <tbody><tr>
                                          <td width="109" valign="middle" height="10" align="center">&nbsp;</td>
                                          <td width="343">&nbsp;</td>
                                          <td width="98">&nbsp;</td>
                                          <td width="191">&nbsp;</td>
                                          <td width="141">&nbsp;</td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="2" background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg" align="center"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          <td background="https://ci6.googleusercontent.com/proxy/l8UfAHSTj8UNQYj8TPwQ29XnApn42D4-DWgSBx-F5C4d7LyBbbflkz1ZZqx6f1j4tOsAS70jkrYwTrzOdfxipgyLn0x8srZh_WxC1g=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/dotted-back.jpg"></td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="29" align="center"><strong>Image</strong></td>
                                          <td><strong>Item Name </strong></td>
                                        
                                          <td align="center"><strong>Quantity</strong></td>
                                          <td><strong>Price</strong></td>
                                          </tr>
                                        <tr>
                                          <td width="109" valign="middle" height="2" bgcolor="#898989" align="center"></td>
                                          <td bgcolor="#898989"></td>
                                          <td bgcolor="#898989"></td>
                                         <td bgcolor="#898989"></td>
                                          <td bgcolor="#898989"></td>
                                          </tr>';
										
$cart_subtotal2=0;

while($cart_row2=mysql_fetch_array($res_cart2))
{
 $sql_prodimg1="select * from  product_images  where product_id=".$cart_row2['prod_id']." order by prodimage_id ASC limit 0,1";
$res_prodimg1=mysql_query($sql_prodimg1);
$row_prodimg1=mysql_fetch_array($res_prodimg1);

 $sql_prod2="select * from  products  where product_id=".$cart_row2['prod_id'];
$res_prod2=mysql_query($sql_prod2);
$row_prod2=mysql_fetch_array($res_prod2);

if($row_prod2['sale_price']!="")
{
$price=$row_prod2['sale_price'];
}
else
{
$price=$row_prod2['regular_price'];
}
$subtotal=$price*$cart_row2['qty'];




$msg1.='<tr>
                                          <td width="109" valign="middle" align="center"><span style="font-size:15px"><img src="'.SITE_URL.'prod_images/'.$row_prodimg1['prodimage_original'].' " width="70" height="50" /></span></td>
                                          <td valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;'.trim(stripslashes($row_prod2['product_name'])).'</td>
                                          
                                          <td align="center" valign="middle">'.$cart_row2['qty'].'</td>
                                          <td valign="middle">Rs.'.number_format($subtotal, 2, '.', '').'</td>
                                          </tr>';

$k++;
$cart_subtotal2 +=$subtotal;
}

             $msg1 .='</tbody></table></td>
                                    </tr>
                                                              <tr>
                                  <td valign="middle" height="2" background="https://ci3.googleusercontent.com/proxy/CEjYmBqEpsn-nuUjuuz32EUN-gDZuTjb76clMxOzF7-aSx5zdzK5pRLIg0LeMeg23fWQX2fXR86zOJPGVJzFYjtyqr30D_4Qcw=s0-d-e1-ft#http://i2.sdlcdn.com/img/eventImage/10/bg-light.jpg" align="center"></td>
                                </tr>
                                
                              </tbody></table>
                              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                  
                                    <tbody><tr>
                                      <td style="padding:10px;color:#5d5d5d"><table width="251" cellspacing="0" cellpadding="3" border="0" align="right">
                                        
                                          <tbody><tr>
                                            <td width="170" align="right"><strong>Cart Subtotal :
                                              </strong></td>
                                            <td align="left">Rs.'.number_format($cart_subtotal2, 2, '.', '').'</td>
                                            </tr>';  
												$shipping="";
												if($shipping=="")
												{
												$ship='Free ';
												
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal2*$shipping)/100;
												$cart_subtotal=$cart_subtotal2+$grandtotal;
												}
$msg1.='<tr>
                                              <td align="right"><strong>Shipping :</strong></td>
                                              <td >'.$ship.' </td>
                                            </tr>
                                            
                                            <tr>
                                            <td width="170" align="right"><strong>Order Total : </strong></td>
                                            <td align="left"> Rs.'.number_format($cart_subtotal, 2, '.', '').' </td>
                                        </tr>                                   
                                                                                    
                                        </tbody></table>
                                      </td>
                                    </tr>
                                    
                                  
                              </tbody></table>
                                                                                                              
                                </td>
                          </tr>
                          
                          <tr>
                            <td height="1" bgcolor="#f3f3f3"></td>
                          </tr>
                          <tr>
                            <td height="80" align="center" style="font-family:Calibri;font-size:12px;color:#636363;font-weight:normal"><p>MR Calorie</p></td>
                          </tr>
                        
                      </tbody></table></td>
                    </tr>
                  
                </tbody></table></td>            
              </tr>          
              <tr>
                <td>&nbsp;</td>
              </tr>
    
              
            
          </tbody></table></td>
        </tr>
      
    </tbody></table>';
	//echo  $msg1;
		






 $to = $row_account['s_emailid'];
$user_name=$row_account['s_firstname']." ".$row_account['s_lastname'];
$files = array();

$head = array(
       'to'      =>array($to=>$user_name),
       'from'    =>array('panthangibabu@gmail.com' =>'MR Calorie'),
       'cc'    =>array('panthangibabu@gmail.com' =>'MR Calorie'),
       
       );
mail::send($head,$subject,$msg1, $files);


if(!empty($_SESSION['sessionuser_id'])){
	$user_id=$_SESSION['sessionuser_id'];
	$del_temp="delete  from temp_cart where  user_id='".$user_id."'";
}else{
	$del_temp="delete  from temp_cart where  sid='".$sid."'";
	}
	
mysql_query($del_temp);


//------------------------------------------------------------------------------------
?>
<script type="text/javascript">
		$(document).ready(function(){
		 $("#display_cart").load("cartdisplay.php?is_ajax=1");
	        $.fn.cart_postLoad(); //here refress the cart.
		});
		</script>	
</body>
</html>