<?php
include_once("admin/config/constants.php");
include_once("config/db_connection.php");
include_once("includes/functions.php");
include_once("DBFns.php");
if($_SESSION['sessionuser_id']=="")
{
//header("Location:index.php");
//exit;
}

if($_POST['act']=='CHG')
{
$user_name=strip_tags(trim($_POST['user_name']));
$mobileno=strip_tags(trim($_POST['mobileno']));
$old_pwd=strip_tags(trim($_POST['old_pwd']));	
$new_pwd=strip_tags(trim($_POST['new_pwd']));



		if($old_pwd!="")
		{
			 $sql="select * from users where user_id='".$_SESSION['sessionuser_id']."' and pwd='".$old_pwd."'";
			$res=mysql_query($sql);
			$cnt=mysql_num_rows($res);
				if($cnt==1)
				{
					 $sql="update users set  pwd='".$new_pwd."',user_name='".$user_name."',mobileno='".$mobileno."'
					 where user_id=".$_SESSION['sessionuser_id'];
					mysql_query($sql);
					$msg="Updated Successfully";
				}
				else
				{
				$msg="Current Password Wrong";
				}
		}
		else
		{
		 $sql="update users set user_name='".$user_name."',mobileno='".$mobileno."'
					 where user_id=".$_SESSION['sessionuser_id'];
					mysql_query($sql);
					$msg="Updated Successfully";
		}
		
		
	}
	$vU=view_users($_SESSION['sessionuser_id']);
?>
<!doctype html>
<html lang="en-US">
	<head>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
	</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->
						
<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->

		<div id="preloader">
			<img class="preloader__logo" src="<?php echo SITE_URL;?>images/logo.png" alt="" width="100" height="100"/>
			<div class="preloader__progress">
				<svg width="60px" height="60px" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
					<path class="preloader__progress-circlebg" fill="none" stroke="#dddddd" stroke-width="4" stroke-linecap="round" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					<path id='preloader__progress-circle' fill="none" stroke="#fe6367" stroke-width="4" stroke-linecap="round" stroke-dashoffset="192.61" stroke-dasharray="192.61 192.61" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
				</svg>
			</div>
		</div>
		<div id="wrapper" class="wide-wrap">

                    <div class="content-container">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div class="tabbable tabs-warning tabs-left">
                                            <ul class="nav nav-tabs" role="tablist">
											
                                                <li class="active">
                                                    <a href="#tab-13" role="tab" data-toggle="tab">
                                                    	My Account
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#tab-14" role="tab" data-toggle="tab">
                                                        Orders History
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#tab-15" role="tab" data-toggle="tab">
                                                        My CHR
                                                    </a>
                                                </li>
                                            </ul>
                                            <div class="tab-content">
											<!--<div class="tab-pane fade active in" id="tab-12">
                                                    <div class="text-block">
                                                        <p>
                                                        Welcome  <?php //echo $_SESSION['sessionuser_name'];?>
                                                        </p>
                                                        
                                                    </div>
                                                </div>-->
                                                <div class="tab-pane fade active in" id="tab-13">
                                                    <div class="text-block">
													<?php
													if($msg!="")
													{
													echo '<font color="#0000FF">'.$msg.'</font>';
													}
													?>
													
													
                          <h1>My Details</h1>                              
   <form action="<?php echo $_SERVER['PHP_SELF'];?>" name="frmedit" method="post" class="form my_account" role="form" onSubmit="return funChgPassword();">
   <input type="hidden" name="act" value="">
   
														 <input class="form-control" name="user_name" type="text" value="<?php echo $vU[0]['user_name'];?>">
                   <!-- <div class="row">
                        <div class="col-xs-6 col-md-6">
                            <input class="form-control" name="firstname" placeholder="First Name" type="text" required="" autofocus="">
                        </div>
                        <div class="col-xs-6 col-md-6">
                            <input class="form-control" name="lastname" placeholder="Last Name" type="text" required="">
                        </div>
                    </div>-->
                    <input class="form-control" name="user_email" type="email" value="<?php echo $vU[0]['user_email'];?>" readonly="">
                    <input class="form-control" name="mobileno"  type="text" value="<?php echo $vU[0]['mobileno'];?>"  onKeyUp="checkNumber(this);">
                    <label>Change Password</label>
                    <input class="form-control" name="old_pwd" placeholder="Current Password" type="password">
                    <input class="form-control" name="new_pwd" placeholder="New Password" type="password">
                    <input class="form-control" name="cpwd" placeholder="Retype Password" type="password">
                    <br>
                    <br>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Save</button>
                </form>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="tab-14">
                                                    <div class="text-block">
                                                        <table style="width:808px;" class="table table-bordered table-responsive table-striped">
                                  <thead>
                                      <tr>
                                        <th>Txn No</th>
                                        <th>Order Date</th>
                                        <th>Amount</th>
										<th> Order Status</th>
										<th>Pay Status</th>
                                        <th>Pay Method</th>
										<th>View</th>
                                      </tr>
                                  </thead>
                                  <tbody>
								  <?php
								   $sql="select * from invoice where  user_id=".$_SESSION['sessionuser_id'];
								   $res_invoice=mysql_query($sql);
								   if(mysql_num_rows($res_invoice)>0)
{
	
while($row_invoice=mysql_fetch_array($res_invoice))
{
extract($row_invoice);
		   
		$sql_orders="select * from orders where invoice_id=".$invoice_id;
$res_orders=mysql_query($sql_orders);
$items=mysql_num_rows($res_orders);		  
	
	 $sql_paystat="select * from  payment_status  where id=".$payment_status;
$res_paystat=mysql_query($sql_paystat);
$row_paystat=mysql_fetch_array($res_paystat);

	$sql_ord="select * from  order_status  where id=".$order_status;
	$res_ord=mysql_query($sql_ord);
$row_ordstat=mysql_fetch_array($res_ord);
							   ?>
								   <tr>
								  		
						<td>#<?php echo $transaction_id;?></td>
						
						<td><?php echo date("jS F, Y", strtotime($invoice_date)); ?></td>
						
						<td><?php echo number_format($total_amount, 2, '.', '');?></span> for <?php echo $items;?> item(s)</td>		
						<td><?php echo $row_ordstat['name'];?></td>			
						<td><?php echo $row_paystat['name'];?></td>
						<td><?php echo $payment_method;?></td>
						 <td><a href="order_details.php?id=<?php echo $invoice_id; ?>"  class="btn btn-xs btn-primary" target="_blank"> <i class="glyphicon glyphicon-eye-open"></i> Invoice</a></td>
								</tr>		  
									  <?php
									  }
									  }
									  else
									  {
									  ?>
                                       <tr>
                                        <td colspan="6" align="center"><font color="#FE5E0A"> No Orders</font></td>
                                        
                                      </tr>
									   <?php
									   }
									   ?>                                      
                                  </tbody>
                                </table>
                                                    </div>
                                                </div>
                                                <div class="tab-pane fade" id="tab-15">
												<h1>BMR Calculator</h1>
                                                    <form action="#" method="post" class="form my_account col-xs-6 col-md-6" role="form" >
                                                    <label>Height </label>
                    <input class="form-control" name="height" id="height" placeholder="Height" type="text" required="" value="<?php echo $vU[0]['height'];?>" autofocus="" onKeyUp="checkNumber(this);">
                    <label>Current Weight (in KGs)</label>
                    <input class="form-control" name="weight" id="weight" placeholder="Weight" type="text" value="<?php echo $vU[0]['weight'];?>" required="" onKeyUp="checkNumber(this);">
                    <label>Current Age (in Years)</label>
                    <input class="form-control" name="age" id="age" placeholder="Age" type="text" value="<?php echo $vU[0]['age'];?>" required="" onKeyUp="checkNumber(this);">
                    <label>Gender</label>
					
                    <div class="row">
                        <div class="col-xs-6 col-md-6">
                            <label  class="inline form-flat-radio">
												<input name="gender" type="radio" id="gender" value="1" <?php if($vU[0]['gender']==1) echo 'checked="checked"';?>>
												<i></i>Male
											</label>
                        </div>
                        <div class="col-xs-6 col-md-6">
                            <label class="inline form-flat-radio">
												<input name="gender" type="radio" id="gender" value="2" <?php if($vU[0]['gender']==2) echo 'checked="checked"';?>>
												<i></i>FeMale
											</label>
                        </div>
                    </div>
                    <br>
                    <br>
                    <button class="btn btn-lg btn-primary btn-block" type="button" id="calculate">Calcuate</button>
                   <br>
				   <?php
				   $height=strip_tags(trim($vU[0]['height']));
$weight=strip_tags(trim($vU[0]['weight']));
$age=strip_tags(trim($vU[0]['age']));
$gender=strip_tags(trim($vU[0]['gender']));
if( $height!="")
{
if($gender==1)
 $bmr= 10 * $weight + 6.25 * $height - 5 * $age + 5 ;  
else
 $bmr= 10 * $weight + 6.25 * $height - 5 * $age + 161 ; 
 }
 else
 {
 $bmr="0";
 }
				   ?>
                    <h3>Result : <span style="font-weight:bold;color:#2cabbf"><span id="calculatordiv"><?php echo $bmr;?></span> Calories/day</span></h3>
                </form>
                    
               
                                                </div>
                                            </div>
                                        </div>
							</div>
						</div>
					</div>
				</div>
			</div>
                </div>
<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
<script language="javascript" type="text/javascript">
function checkNumber(textBox)

{

	while (textBox.value.length > 0 && isNaN(textBox.value)) {

		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	}

	

	textBox.value = textBox.value;

/*	if (textBox.value.length == 0) {

		textBox.value = 0;		

	} else {

		textBox.value = parseInt(textBox.value);

	}*/

}
	function AlphaNumeric_space(textBox)
{

	
	var regEx = new RegExp("^[a-zA-Z0-9 ]+$");
	 if (!$("#user_name").val().match(regEx))
	 {
		
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	 }

textBox.value = textBox.value;
}
function AlphaNumeric_special(textBox)
{
	
	
	var regEx = new RegExp("^[a-zA-Z0-9._@]+$");
	 if (!$("#remail_id").val().match(regEx))
	 {
		
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	 }

textBox.value = textBox.value;
}
</script>
<script type="text/javascript"  language="javascript">

$( document ).ready(function() {
$("#calculate").click(function(){

var height = $('#height').val();

        if ($.trim(height).length == 0) {

		$("#height").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }


var weight = $('#weight').val();



        if ($.trim(weight).length == 0) {

		$("#weight").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }
				
		
var age = $('#age').val();

        if ($.trim(age).length == 0) {

		$("#age").css({"border": "1px solid","color":"#F00"});	

			return false;

		        }
	
	var radioValue = $("input[name='gender']:checked").val()
	var dataString = "height="+$("#height").val()+"&weight="+$("#weight").val()+"&age="+$("#age").val()+"&gender="+radioValue;  
			$.ajax({
				  type: "POST",
				  url: "bmrcalculator_save_jq.php",
				  data: dataString,
				  success: function(data)
				  { 
				   $("#calculatordiv").html(data);
				    },
				  //error: function(XMLHttpRequest, textStatus, errorThrown){alert(XMLHttpRequest.status);}
				});
				return false;
	});	
		
});
function funChgPassword()
{
var frm=document.frmedit;
	 if(frm.new_pwd.value!="")
	{
		if( frm.old_pwd.value == '')
		{
			frm.old_pwd.focus();
			return false;
		}
		if( frm.new_pwd.value != frm.cpwd.value)
		{
			frm.cpwd.focus();
			return false;
		}
	}
	frm.act.value='CHG';
frm.submit();
}
</script>
<script language="javascript" type="text/javascript">
function checkNumber(textBox)

{

	while (textBox.value.length > 0 && isNaN(textBox.value)) {

		textBox.value = textBox.value.substring(0, textBox.value.length - 1)

	}

	

	textBox.value = textBox.value;

/*	if (textBox.value.length == 0) {

		textBox.value = 0;		

	} else {

		textBox.value = parseInt(textBox.value);

	}*/

}
</script>
