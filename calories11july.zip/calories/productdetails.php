<?php
include("admin/config/constants.php");
include("config/db_connection.php");
include("includes/functions.php");
$pid=strip_tags(trim($_REQUEST['pid']));
$vP=view_products($pid);
$vPIS=view_product_image_single($pid);
$vPI=view_product_images($pid);
$vPD=view_product_desc($pid);
$vPL=view_products_maincat_limit($vP[0]['maincat_id'],3);
$vR=view_reviews($pid);
// For Reviews
$msgreview="";
if($_SESSION['sessionuser_id']=="")
{
$user_id=0;
}
else
{
$user_id=$_SESSION['sessionuser_id'];
}
if($_POST['act']=='REVIEW')
{

$pid=strip_tags(trim($_REQUEST['pid']));
$post_date=date('Y-m-d');
$rating=addslashes(trim($_REQUEST['rating']));
$review=addslashes(trim($_REQUEST['comment']));
 $ins_review="insert into reviews ( 

									product_id,
									user_id,
									rating,
									review,
									post_date
								)	

								values
								(
									'".$pid."',
									'".$user_id."',
									'".$rating."',
									'".$review."',
									'".$post_date."'
								)";

$res=mysql_query($ins_review);
$msgreview="Your review has been sent successfully . Admin will approve soon";
}
if($_POST['act']=='ADDTOCART')
{
	if(isset($_POST['quantity']))
	{
		$quantity=$_POST['quantity'];
	}
	else
	{
		$quantity=1;
	}

	$post_date=date('Y-m-d');

	$sid=session_id();
	$pid=$_POST['pid'];
	$sql_cart="select * from temp_cart where sid='".$sid."' and prod_id=".$pid;

	$res_cart=mysql_query($sql_cart);

	if(mysql_num_rows($res_cart)==0)
	{

		$ins_temp="insert into temp_cart (

									prod_id,

									user_id,
									qty,
									sid,
									post_date
								)

								values
								(
									'".$pid."',
									'".$user_id."',
									'".$quantity."',
									'".$sid."',
									'".$post_date."'
								)";

		$res=mysql_query($ins_temp);
	}
	else
	{
		$row=mysql_fetch_array($res_cart);
		$qty=$row['qty']+$quantity;
		$upd_cart="update temp_cart set qty=".$qty." where sid='".$sid."' and prod_id=".$pid;
		$res=mysql_query($upd_cart);
	}
	if($res)
	{
		header("Location:cart.php");
		exit;
	}



}
?>
<!doctype html>
<html lang="en-US">
	<head>
	<?php //include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
	<?php	
		include("config/db_connection.php");
//		include("includes/functions.php");
		include("DBFns.php");
		?>
	</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php include("maincat.php");?>
	<!-- maincat end -->

		<div id="preloader">
			<img class="preloader__logo" src="<?php echo SITE_URL;?>images/logo.png" alt="" width="100" height="100"/>
			<div class="preloader__progress">
				<svg width="60px" height="60px" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
					<path class="preloader__progress-circlebg" fill="none" stroke="#dddddd" stroke-width="4" stroke-linecap="round" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					<path id='preloader__progress-circle' fill="none" stroke="#fe6367" stroke-width="4" stroke-linecap="round" stroke-dashoffset="192.61" stroke-dasharray="192.61 192.61" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
				</svg>
			</div>
		</div>
<!-- ----------------------------------------      ------------------------------------------------------ -->
<div id="wrapper" class="wide-wrap">


			<div class="content-container">
				<div class="container">
					<div class="row">
						<div class="commerce page-layout-right-sidebar">
						<div class="col-md-12">
							<h1 class="product_title entry-title inner_title"><?php echo stripslashes($vP[0]['product_name']);?></h1>
						</div>
							<div class="col-md-12">
								<div class="main-content">
									<div class="product">
										<div class="row">
											<div class="col-md-4 col-sm-4 entry-image">
												<div class="single-product-images">
												<?php
												if($val['food_type']==1)
											{
												$class="veg";
												$text="Veg";
											}
											else
											{
												$class="non_veg";
												$text="Non Veg";
											}
											
												?>
													<span class="<?php echo $class;?>"><?php echo $text;?></span>
													<div class="single-product-images-slider">
														<div class="caroufredsel product-images-slider" data-height="variable" data-visible="1" data-responsive="1" data-infinite="1">
															<div class="caroufredsel-wrap">
																<ul class="caroufredsel-items">
																<?php
																foreach($vPI as $val)
																{
																?>
																	<li class="caroufredsel-item">
																		<a href="<?php echo SITE_URL;?>prod_images/<?php echo $val['prodimage_original'];?>" data-rel="magnific-popup" title="product-11">
																			<img  src="<?php echo SITE_URL;?>prod_images/<?php echo $val['prodimage_original'];?>" alt="product-11" title="product-11"/>
																		</a>
																	</li>
																	<?php
																	}
																	?>
																	<!--<li class="caroufredsel-item">
																		<a href="images/restaurant/product-12.jpg" data-rel="magnific-popup" title="product-12">
																			<img width="700" height="550" src="images/restaurant/product-12.jpg" alt="product-11" title="product-12"/>
																		</a>
																	</li>-->
																</ul>
																<a href="#" class="caroufredsel-prev"></a>
																<a href="#" class="caroufredsel-next"></a>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-8 col-sm-8 entry-summary">
												<div class="summary">
												<div class="info-rating">
																<?php
															$cnt=view_prod_reviews_count($vP[0]['product_id']);
															$tot=view_prod_reviews_total($vP[0]['product_id']);
																 $atot=ceil($tot/$cnt);
																for($r=1;$r<=$atot;$r++)
																{
																?>
																<img src="images/rating-1.png">
																<?php
																}
																for($p=1;$p<=(5-$atot);$p++)
																{
																?>
																<img src="images/rating-0.png">
																<?php
																}
																?>
																	<!--<div class="star-rating">
																		<span style="width:0%"></span>
																	</div>-->
																</div>
													<div class="price">
													
													<?php

										   if($vP[0]['sale_price']!="")

										   {

										   ?>
<del><span class="amount"><i class="fa fa-inr"></i>&nbsp;<?php echo $vP[0]['regular_price'];?></span></del> 
														<ins><span class="amount"><i class="fa fa-inr"></i>&nbsp;<?php echo $vP[0]['sale_price'];?></span></ins>
										

											<?php

										   }

										   ?>

										   <?php

										   if($vP[0]['sale_price']=="")

										   {

										   ?>

										
<ins><span class="amount"><i class="fa fa-inr"></i>&nbsp;<?php echo $vP[0]['regular_price'];?></span></ins>
										   

                                          <!--  <span class="realprice"><i class="fa fa-inr"></i> <?php echo $vP[0]['regular_price'];?></span>-->
										  <?php

										   }

										   ?>
														<!--<del><span class="amount">&#36;20.50</span></del> 
														<ins><span class="amount">&#36;19.00</span></ins>-->
													</div>
													<!--<div class="product-excerpt">
														<p>
															Proin malesuada enim nulla, nec bibendum justo vestibulum non. Duis et ipsum convallis, bibendum enim a, hendrerit diam. Praesent tellus mi, vehicula et risus eget, laoreet tristique tortor. Fusce id metus eget nibh imperdiet fermentum non in metus.
														</p>
													</div>-->
													<form class="cart"  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

										<input type="hidden" name="pid" value="<?php echo $_REQUEST['pid'];?>" />

	  <input type="hidden" name="act" value="ADDTOCART" />
													
														<div class="quantity">
															<input type="number" step="1" min="1" name="quantity" value="1" title="Qty" class="input-text qty text" size="4" onKeyUp="checkNumber(this);"/>
														</div>
														<button type="submit" class="button alt">Add to cart</button>
														<!--<button style="margin-left: 15px;" type="submit" class="button alt">Buy Now</button>-->
													</form>
													<div class="clearfix"></div>
													<div class="product_meta">
														<span class="posted_in">
														<ul class="inner_cal">
														<?php
														if($vP[0]['calories']!="")
														{
														?>
															<li><span>Calories :</span> <b><?php echo $vP[0]['calories'];?></b></li>
															<?php
															}
															?>
																<?php
														if($vP[0]['fat']!="")
														{
														?>
															<li><span>Fat :</span> <b><?php echo $vP[0]['fat'];?></b></li>
															<?php
															}
															?>
																<?php
														if($vP[0]['proteins']!="")
														{
														?>
															<li><span>Protein :</span> <b><?php echo $vP[0]['proteins'];?></b></li>
															<?php
															}
															?>
																<?php
														if($vP[0]['sugar']!="")
														{
														?>
															<li><span>Sugar :</span> <b><?php echo $vP[0]['sugar'];?></b></li>
															<?php
															}
															?>
															<!--<li><span>Fat :</span> <b>350</b></li>
															<li><span>Protein :</span> <b>350</b></li>
															<li><span>Sugar :</span> <b>350</b></li>-->
														</ul>
														</span>
													</div>
													
												</div> 
											</div>
										</div>
										<div class="tabbable tabs-primary tabs-top commerce-tabs">
											<ul class="nav nav-tabs" role="tablist">
												<li class="active">
													<a data-toggle="tab" role="tab" href="#tab-description">Description</a>
												</li>
												<li class="">
													<a data-toggle="tab" role="tab" href="#tab-reviews">Reviews (<?php echo count($vR);?>)</a>
												</li>
											</ul>
											<div class="tab-content">
												<div class="tab-pane active" id="tab-description">
													<h2>Product Description</h2>
													<?php
													echo stripslashes($vPD[0]['prod_desc']);
													?>
												</div>
												<div class="tab-pane" id="tab-reviews">
													<div id="comments" class="comments-area">
														<h2 class="comments-title">There are <span><?php echo count($vR);?></span> Reviews</h2>
														<ol class="comments-list">
														<?php
														foreach($vR as $val)
														{
														$vU=view_users($val['user_id']);
														?>
															<li class="comment">
																<div class="comment-wrap">
																	<div class="comment-img">
																		<img alt="" src="http://placehold.it/80x80" class='avatar' height='80' width='80'/>
																	</div>
																	<div class="comment-block">
																		<header class="comment-header">
																			<cite class="comment-author">
																				<?php echo $vU[0]['user_name'];?>
																			</cite>
																			<div class="comment-meta">
																				<span class="time"><?php echo date("jS F, Y", strtotime($val['post_date'])); ?></span>
																			</div>
																		</header>
																		<div class="comment-content">
																			<p>
																				<?php echo stripslashes($val['review']);?>
																			</p>
																			
																		</div>
																	</div>
																</div>
															</li> 
															<?php
															}
															?>
														</ol>
														<?php
														if($_SESSION['sessionuser_id']!="")
														{
														?>
														
														<?php
														if($msgreview!="")
														{
														?>
														<div class="comment-respond">
															<h3 class="comment-reply-title">
																<span><font color="#0000FF"><?php echo stripslashes($msgreview);?></font></span>
															</h3>
															</div>
															<?php
															}
															else
															{
															?>
														<div class="comment-respond">
															<h3 class="comment-reply-title">
																<span>Leave your thought</span>
															</h3>
															<form class="comment-form" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
															<input type="hidden" name="act" value="REVIEW">
															<input type="hidden" name="pid" value="<?php echo $_REQUEST['pid'];?>">
																<div class="row">
																	<div class="comment-form-author col-sm-12">
																	<select name="rating" class="form-control" required>
																	<option value=""> Select</option>
																	<option value="1">1</option>
																	<option value="2">2</option>
																	<option value="3">3</option>
																	<option value="4">4</option>
																	<option value="5">5</option>
																	</select>
																		<!--<input id="author" name="user_name" type="text" placeholder="Name*" class="form-control" value="" size="30" required />-->
																	</div>
																<div class="comment-form-email col-sm-12">
											&nbsp;
																	</div>
																	<div class="comment-form-comment col-sm-12">
																		<textarea class="form-control" placeholder="Review" id="comment" name="comment" cols="40" rows="6" ></textarea>
																	</div>
																</div>
																<div class="form-submit">
																	<input name="submit" type="submit" id="submit" class="submit" value="Submit"/>
																</div>
															</form>
														</div>
														<?php
														}//else
														}
														?>
													</div>
												</div>
											</div>
										</div>
										<div class="related products">
											<div class="related-title">
												<h3><span>Related Products</span></h3>
											</div>
										</div>
										<?php include_once ('products.php');?>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>


</div>
<!-- ----------------------------------------      ------------------------------------------------------ -->
<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js1.php");?>	
		<script type="text/javascript">
		function checkNumber(textBox)

		{

			while (textBox.value.length > 0 && isNaN(textBox.value)) {

				textBox.value = textBox.value.substring(0, textBox.value.length - 1)

			}

			

			textBox.value = textBox.value;

		/*	if (textBox.value.length == 0) {

				textBox.value = 0;		

			} else {

				textBox.value = parseInt(textBox.value);

			}*/

		}
		</script>