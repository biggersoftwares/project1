<?php




define("MAIL_HOST", "mail.stellarcw.com"); //Hostname of the mail server//smtp.gmail.com//
define("MAIL_PORT", "587"); //Port of the SMTP like to be 25, 80, 465 or 587
define("MAIL_UNAME", "support@stellarcw.com"); //Username for SMTP authentication any valid email created in your domain
define("MAIL_PWORD", "stellar13"); //Password for SMTP authentication
define("MAIL_SECURE", "ssl");

define('mail_from', '');
?>