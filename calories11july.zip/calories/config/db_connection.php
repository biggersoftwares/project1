<?php
ob_start();
session_start();
error_reporting(0);
if($_SERVER['SERVER_NAME']=='localhost')
{
define('DB_SERVER', 'localhost');

define('DB_USERNAME', 'root');

define('DB_PASSWORD', '');

define('DB_DATABASE', 'calories');
}
else
{
//define('DB_SERVER', 'localhost');

//define('DB_USERNAME', 'propfirs_root');

//define('DB_PASSWORD', 'LOxxOWBsS^_K');

//define('DB_DATABASE', 'propfirs_calories');

define('DB_SERVER', 'localhost');

define('DB_USERNAME', 'arkaitso_fit');

define('DB_PASSWORD', 'fit@1234');

define('DB_DATABASE', 'arkaitso_fit_revolution');
	
	
}
define('DBEXT',"");
//echo DB_SERVER.' -- '.DB_USERNAME.' -- '.DB_PASSWORD.'>>'.DB_DATABASE;
$connection = mysql_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD,DB_DATABASE);
//if($connection == false){
//    echo "success";
//}else{
//echo "not success";
//}
$database = mysql_select_db(DB_DATABASE);

?>
