<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include("config/dbpdo.php");

if ($_POST['act'] == 'REGISTER') {
    $email_id = strip_tags(trim($_POST['youremail']));

    $pwd = strip_tags(trim($_POST['password']));
    $user_name = strip_tags(trim($_POST['firstname'])) . " " . strip_tags(trim($_POST['lastname']));

    $mobileno = strip_tags(trim($_POST['mobileno']));

    $activation = rand(100000, 999999);

    if ($user_name != 'undefined') {

        $sql = "select * from users where user_email='" . $email_id . "' and pwd='" . $pwd . "'";

        $res = mysql_query($sql);



        $cnt = mysql_num_rows($res);

        if ($cnt == 1) {
            $rmsg = "Email Already Existed.";
        } else {
            $post_date = date('Y-m-d');

             $ins = "insert into users(	

	 										user_name,
											user_email,
											pwd,
											mobileno,
											post_date,
											activation
										 )

											values

										(

											'" . $user_name . "',
											'" . $email_id . "',
											'" . $pwd . "',
											'" . $mobileno . "',
											'" . $post_date . "',
											'" . $activation . "'
										)";

             $res = mysql_query($ins);


            //   ***************************  EMAIL  START**************************



            $lid = mysql_insert_id();

            $verify = $lid;

            $subject = 'Your account on My Calorie';

// message

            $body = '

 

 <div style="margin: 0 auto; width: 600px; background:#fff; box-shadow:0px 1px 1px 1px #428bca;">

	             <div style="background:#FFFFFF; padding: 20px; color:#fff"> <a href="' . SITE_URL . '"><img src="' . SITE_URL . 'images/logo.png" alt="My Calorie" title="My Calorie" width="120" height="80"></a>

	              </div>

	       <div style="clear: left; padding: 20px;">

    

		<h3 style="color:#000; font-size: 14px; margin:3px 0;">

			

            <p>Dear ' . $user_name . ',</p>

		</h3>

		

        <p>Thank You for showing inerest to register with us  </p>

	

 

	</div>

    

   <div style="clear: left; padding: 10px; border-top:1px solid #ccc; width:90%; margin-left:8px;">

    <table width="90%"  cellspacing="2" cellpadding="5" align="center" bgcolor="#f2f2f2">

      

      <tr>

        <td height="30" align="left"><strong>Activation Code</strong></td>

        <td> :  ' . $activation . '</td>

      </tr>     

    </table>

    </div>

	<div style="background:#428bca; text-align:left; padding: 8px 20px; color:#fff;"><p><strong>Warms Regards</strong>,<br />

                                                                                My Calorie<br />

                                                                                www.mycalories.com</p>

 </div>

</div> ';

//$from_mail=$row_sett5['value'];

            $to = $email_id;


            $files = array();

            $head = array(
                'to' => array($to => $user_name),
                'from' => array('pavankumarraju.n@gmail.com' => 'My Calorie'),
                    /* 'bcc'      =>array('reitake.com@gmail.com'=>'Admin'), */
            );
            //mail::send($head, $subject, $body, $files);
//   ***************************  EMAIL   END **************************


            if ($res) {

                header("Location:verification.php?key=" . $verify);

                exit;
            }
        }
    }
}
?>
<!-- ------------------------------------        ----------------------------------------- -->
<!doctype html>
<html lang="en-US">
	<head>
		<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
		<?php	
		include("config/db_connection.php");
		include("includes/functions.php");
		include("DBFns.php");
		
		//include_once('social/config.php');
		include_once('social/facebook_login.php');
		include_once('social/google_login.php');
		?>
		
	</head>
	
	<body id="page-top" data-spy="scroll"    >
		
<!-- cart display start -->
	<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			

<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->			

<!-- maincat start -->
	<?php include("preloader.php");?>
<!-- maincat end -->			

<!-- ------------------------------------        ----------------------------------------- -->

        <section class="login_section">
            <div class="container">
                <div class="row">

                    <div class="col-md-3">&nbsp;</div>
                    <div class="col-md-6">





                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="frmlogin" id="frmlogin" method="post">

                            <input type="hidden" name="act" value="REGISTER">

                            <input type="hidden" name="user_logintype" id="user_logintype" value="1">
                            <h1 style="text-align:center;">Register Here</h1>


                            <div class="row" >
                                <div class="col-xs-6 col-md-6" >
                                    <a><img src="images/fb.png" alt="facebook" style="float: right;" id="facebook" class="social" onclick="social_login(this)"></a>
                                </div>
                                <div class="col-xs-6 col-md-6"  >
                                    <a><img src="images/gplus.png" alt="gplus"  id="gplus" class="social" onclick="social_login(this)"></a>
                                </div>
                            </div>
                            <div><h2 style="text-align:center;">Or</h2></div>
                            <div class="row">
                                <div class="col-xs-6 col-md-6">
                                    <input class="form-control" name="firstname" placeholder="First Name" type="text" required="" autofocus="">
                                </div>
                                <div class="col-xs-6 col-md-6">
                                    <input class="form-control" name="lastname" placeholder="Last Name" type="text" required="">
                                </div>
                            </div>
                            <input class="form-control" name="youremail" placeholder="Your Email" type="email">
                            <input class="form-control" name="mobileno" placeholder="Mobile No" type="text">
                            <input class="form-control" name="password" placeholder="Password" type="password">
                            <input class="form-control" name="password" placeholder="Retype Password" type="password">
                            <b style="color:red">Note:</b> Verification link will send to Email Id .
                            <br>
                            <br>
                            <button class="btn btn-lg btn-primary btn-block" id="sbtregister" type="submit" data-toggle="modal" data-target="#myModal2">
                                Sign up</button>

                        </form>
                    </div>
                    <div class="col-md-6">&nbsp;</div>
                </div>
            </div>		
        </section>
       
       <FORM name="facbook" method="post" action="<?php echo $loginUrl;?>" id="facebookfrm">
       <input type="hidden" name="act" value="social_login" />
       <input type="hidden" name="type" value="facebook" />
       </FORM>
       
       <FORM name="gplus" method="post" action="<?php echo $authUrl;?>" id="gplusfrm">
       <input type="hidden" name="act" value="social_login" />
       <input type="hidden" name="type" value="gplus" />
       </FORM>
<!-- ------------------------------------        ----------------------------------------- -->
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
	<script language="javascript" type="text/javascript">
    function checkNumber(textBox)

    {

        while (textBox.value.length > 0 && isNaN(textBox.value)) {

            textBox.value = textBox.value.substring(0, textBox.value.length - 1)

        }
   textBox.value = textBox.value;

        /*	if (textBox.value.length == 0) {
         
         textBox.value = 0;		
         
         } else {
         
         textBox.value = parseInt(textBox.value);
         
         }*/

    }
    function AlphaNumeric_space(textBox)
    {


        var regEx = new RegExp("^[a-zA-Z0-9 ]+$");
        if (!$("#user_name").val().match(regEx))
        {

            textBox.value = textBox.value.substring(0, textBox.value.length - 1)

        }

        textBox.value = textBox.value;
    }
    function AlphaNumeric_special(textBox)
    {


        var regEx = new RegExp("^[a-zA-Z0-9._@]+$");
        if (!$("#remail_id").val().match(regEx))
        {

            textBox.value = textBox.value.substring(0, textBox.value.length - 1)

        }

        textBox.value = textBox.value;
    }
</script>
<script type="text/javascript"  language="javascript">

    $(document).ready(function () {

        function validateEmail(sEmail) {

            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

            if (filter.test(sEmail)) {

                return true;

            } else {

                return false;

            }

        }

        $("#sbtregister").click(function () {
             var vuser_name = $('#user_name').val();

            if ($.trim(vuser_name).length == 0) {

                $("#user_name").css({"border": "1px solid", "color": "#F00"});

                return false;

            }


            var vrpwd = $('#rpwd').val();

            if ($.trim(vrpwd).length == 0) {

                $("#rpwd").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            var vmobileno = $('#mobileno').val();

            if ($.trim(vmobileno).length == 0) {

                $("#mobileno").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            //  Email Validation

            var sEmail = $('#remail_id').val();

            if ($.trim(sEmail).length == 0) {

                $("#remail_id").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            if ($.trim(vmobileno).length < 10) {

                $("#mobileno").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            if (!validateEmail(sEmail)) {

                $("#remail_id").css({"border": "1px solid", "color": "#F00"});

                return false;

            }

            /*if(!$("input[name='smsalert']:checked").val())
             {
             alert("Please check  accept sms alerts");
                             
             return false;
             }
             */
            //var radioValue = $("input[name='user_type']:checked").val();

            //var usertype = $('#user_type').val();

            //$('#user_registertype').val(radioValue);

            $('#frmregister').submit();

            return true;

        });

    });

    function social_login(obj)
    {
        type=$.trim($(obj).attr("id"));
        //alert(type);
        if(type=="facebook"){
				$("#facebookfrm").submit();
            }else{
            	$("#gplusfrm").submit();
            }
    	
//     	frm.act.value="social_login";
//     	frm.type.value=type;
//     	frm.submit();
    }

</script>
		

<!-- ------------------------------------        ----------------------------------------- -->
</body>
</html>