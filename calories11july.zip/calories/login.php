<?php ?>
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<script type="text/javascript"> 
$(document).ready(function(){
    
    $.fn.checkLogin = function( options ) {
        // This is the easiest way to have default options.
        var settings = $.extend({
        	'act':'CHECKLOGIN'
        }, options );
        
       // alert(JSON.stringify(settings));

        $.post('loginchecks.php',settings, function(data)
            {
              data=JSON.parse(data);
              //alert(JSON.stringify(data));
              //alert(data["lmsg"]);
              if(data.lmsg=="succuss"){
                  var url=window.location.href;
                  //alert(url);
                  url=url.substr(0,url.lastIndexOf("/"));
                  //alert(url);
                    window.location.href= url+"/myaccount.php";
              }else{
                  
              }
             });
    };
    
        $('#login').click(function(){
        var usr = "";
        var pwd = "";
        var usr = $.trim($('#user_name').val());
        var pwd = $.trim($('#password').val());
        if(usr == "" ) {
            alert(" Enter USERNAME ");
            return false;
        };
        if(pwd == "" ) {
            alert(" Enter PASSWORD ");
            return false;
        };
      var  json={"lemail_id":usr,"lpwd":pwd}
        
        $.fn.checkLogin(json);
    });
});  
</script>
<?php 
//print_r($_SESSION);
if(empty($_SESSION['sessionuser_id'])){
?>
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document" style=" margin-right: 240px; /* margin-bottom: 150px; */">
<div class="modal-content" style="width: 350px;margin-top: 150px;">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel" style="text-align: center; color:white;">LOGIN</h4>
</div>
<div class="modal-body">
 
<div class="form-group">
 
<input type="text" class="form-control" id="user_name" placeholder="USERNAME">
</div>
<div class="form-group">

<input type="password" class="form-control" id="password" placeholder="PASSWORD">
</div>

<input type="button" class="btn btn-success" value="LOGIN" id="login">
</div>
<div class="modal-footer">
<a href="login1.php" hspace="5" style="border-right: 1px solid white;    padding-right: 5px;">REGISTER</a>
<a href="forgot_password.php">FORGOT PASSWORD?</a>
</div>
</div>
</div>
</div>
<?php }else{
?>
<div class="modal fade cart-display" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="container">
  <div class="shopping-cart">
	<ul>
	<li class="clearfix">
        <a href="myaccount.php"><b>My Account</b></a>
      </li>
        <li class="clearfix">
        <a href="logout.php"><b>logout</b></a>
      </li>
	</ul>
		
	
  </div> <!--end shopping-cart -->
</div> <!--end container -->	
</div>
<?php	
}?>
