<?php
include_once("admin/config/constants.php");
include_once("config/db_connection.php");
include_once("config/dbpdo.php");

include_once("includes/functions.php");
include_once("DBFns.php");
if($_SESSION['sessionuser_id']=="")
{
//header("Location:index.php");
//exit;

    
}

$sql_cart="select * from orders where invoice_id='".$_REQUEST['id']."'";
$res_cart=mysql_query($sql_cart);



$sql_invoice="select * from invoice where invoice_id='".$_REQUEST['id']."'";
$res_invoice=mysql_query($sql_invoice);
$row_invoice=mysql_fetch_array($res_invoice);
$transaction_id=$row_invoice['transaction_id'];



 $sql_account="select * from bill_ship_address where user_id='".$row_invoice['user_id']."'";
$res_account=mysql_query($sql_account);
$row_account=mysql_fetch_array($res_account);



try {
        $db->beginTransaction();
	 $sql="select * from orders  where invoice_id=".$_REQUEST['id'];
	$stmt=$db->prepare($sql);	
	$stmt->execute();
	$norows=$stmt->rowCount();
	
	$sql_in="select * from invoice  where invoice_id=".$_REQUEST['id'];
	$stmt_in=$db->prepare($sql_in);	
	$stmt_in->execute();
	$row_in= $stmt_in->fetch(PDO::FETCH_ASSOC);
	
	 $sql3="select * from bill_ship_address  where user_id=".$row_in['user_id'];
	$stmt3=$db->prepare($sql3);	
	$stmt3->execute();
	$row3= $stmt3->fetch(PDO::FETCH_ASSOC);
        $db->commit();
} 
catch(PDOException $ex)
{
    //Something went wrong rollback!
    $db->rollBack();
    writeLog($ex->getMessage().'\n'); 
	writeLog($ex->getLine().'\n'); 
}


?>
<!doctype html>
<html lang="en-US">
	<head>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
	</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			
				
<div class="navbar-container">
	<div class="navbar navbar-default navbar-scroll-fixed">
						
	</div>
</div>

<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->
						
<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->

		<div id="preloader">
			<img class="preloader__logo" src="<?php echo SITE_URL;?>images/logo.png" alt="" width="100" height="100"/>
			<div class="preloader__progress">
				<svg width="60px" height="60px" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
					<path class="preloader__progress-circlebg" fill="none" stroke="#dddddd" stroke-width="4" stroke-linecap="round" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					<path id='preloader__progress-circle' fill="none" stroke="#fe6367" stroke-width="4" stroke-linecap="round" stroke-dashoffset="192.61" stroke-dasharray="192.61 192.61" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
				</svg>
			</div>
		</div>
<div id="wrapper" class="wide-wrap">
                    <div class="content-container">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-content">
								<div class="tabbable tabs-warning tabs-left">
                                            <ul class="nav nav-tabs" role="tablist">
											<li class="active">
                                                    <a href="myaccount.php">
                                                    	My Account
                                                    </a>
                                                </li>
                                                
                                            </ul>
                                          
                            <div class="box">
                                <div class="box-header">
                            <table  class="table" style="width:90%;">
		<tr><th>Transaction ID</th><td> #<?php echo $row_in['transaction_id'];?></td> <th>Name</th><td><?php echo $row3['s_firstname']." ".$row3['s_lastname'];?></td><th>Amount</th><td><?php echo number_format($row_in['total_amount'], 2, '.', '');?></td><th>Date</th><td>	<?php echo date("jS F, Y", strtotime($row_in['invoice_date'])); ?></td></tr>
							</table>
									 
                                </div><!-- /.box-header -->
                                <div class="box-body table-responsive">
								<FORM name="pform" method="post" action="#">
       <input type="hidden" name="act" value="" />
                                 <table width="100%" border="0" cellspacing="1">
								  <tr>
									<td><table width="100%" border="2" style="border-collapse:collapse" cellspacing="5">
									  <tr>
										<td height="30"><strong>&nbsp;Product</strong></td>
										<td><strong>&nbsp;Quantity</strong></td>
										<td><strong>&nbsp;Price</strong></td>
									  </tr>
									  <?php
$cart_subtotal=0;
$k=0;
while($cart_row=mysql_fetch_array($res_cart))
{

$sql_prod1="select * from  products  where product_id=".$cart_row['prod_id'];
$res_prod1=mysql_query($sql_prod1);
$row_prod1=mysql_fetch_array($res_prod1);

if($row_prod1['sale_price']!="")
{
$price=$row_prod1['sale_price'];
}
else
{
$price=$row_prod1['regular_price'];
}
$subtotal=$price*$cart_row['qty'];



?>
									  <tr>
										<td>&nbsp;<?php echo trim(stripslashes($row_prod1['product_name']))."  ".$row_prod1['sku']; ?></td>
										<td>&nbsp;<?php echo $cart_row['qty'];?></td>
										<td>&nbsp;Rs.<?php echo number_format($subtotal, 2, '.', '');?></td>
									  </tr>
									  <?php
													$k++;
													$cart_subtotal +=$subtotal;
													}
													?>
									  
									  <tr>
									    <td colspan="2" height="30"><strong>Cart Subtotal:</strong></td>
									    <td>&nbsp;Rs.&nbsp;<?php echo number_format($cart_subtotal, 2, '.', '');?></td>
								      </tr>
									  
									
												<?php 
												$shipping="";
												if($shipping=="")
												{
												$ship='Free';
												
												}
												else
												{
												$ship=$shipping."  % ";
												
												$grandtotal=($cart_subtotal*$shipping)/100;
												$cart_subtotal=$cart_subtotal+$grandtotal;
												}
												?>
									  <tr>
									    <td colspan="2" height="30"><strong>Shipping:</strong></td>
									    <td>&nbsp;<?php echo $ship;?></td>
									  
								      </tr>
									  <tr>
									    <td colspan="2" height="30"><strong>Payment Method:</strong></td>
									    <td>&nbsp;<?php echo $row_in['payment_method'];?></td>
									    
								      </tr>
									  <tr>
									    <td colspan="2" height="30"><strong>Order Total:</strong></td>
									    <td>&nbsp;Rs.&nbsp;<?php echo number_format($cart_subtotal, 2, '.', '');?></td>
									   
								      </tr>
									</table>
									</td>
								  </tr>
								  <tr>
									<td>&nbsp;</td>
								  </tr>
								</table>

										 <h2 style="color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;text-align:left;line-height:150%">Customer details</h2>
										 <p><b>Email: </b><?php echo $row_account['s_emailid'];?></p>
										 <p><b>Tel: </b><?php echo $row_account['s_mobileno'];?></p>
										 <table cellspacing="0" cellpadding="0" border="0" style="width:100%;vertical-align:top">
                                	<tbody>
                                    	<tr>
                                        	<td width="50%" valign="top">
                							<h3 style="color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;text-align:left;line-height:150%">Billing address</h3>
											<p><?php 
															echo $row_account['b_firstname']."  ".$row_account['b_lastname']."<br>";
														echo $row_account['b_address']."<br>";
														echo $row_account['b_city']." - ".$row_account['b_zipcode'];
															?></p>
											
    
           									</td>
            								<td width="50%" valign="top">
                							<h3 style="color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;text-align:left;line-height:150%">Shipping address</h3>
                                        <p><?php
															echo $row_account['s_firstname']."  ".$row_account['s_lastname']."<br>";
														echo $row_account['s_address']."<br>";
														echo $row_account['s_city']." - ".$row_account['s_zipcode'];
														?></p><span>
                                           </span>
                                            </td>
                                      </tr>
                                       </tbody>
                                    </table>
								  </FORM>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
							
							
                                        </div>
							</div>
						</div>
					</div>
				</div>
                    </div>
			</div>
<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
			