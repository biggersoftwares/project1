<?php
include("../config/db_connection.php");
include("../includes/mail_function.php");


$username=strip_tags(trim($_POST['username']));
$user_email=strip_tags(trim($_POST['user_email']));
$pwd=strip_tags(trim($_POST['pwd']));
$mobileno=strip_tags(trim($_POST['mobileno']));	

$status=1;
// Billing  Details
$b_firstname=strip_tags(trim($_POST['b_firstname']));
$b_lastname=strip_tags(trim($_POST['b_lastname']));
$b_address=strip_tags(trim($_POST['b_address']));
$b_address1=strip_tags(trim($_POST['b_address1']));


$b_city=strip_tags(trim($_POST['b_city']));
$b_zipcode=strip_tags(trim($_POST['b_zipcode']));
$b_emailid=strip_tags(trim($_POST['b_emailid']));
$b_mobileno=strip_tags(trim($_POST['b_mobileno']));
  

// Shipping Details


$s_firstname=strip_tags(trim($_POST['s_firstname']));
$s_lastname=strip_tags(trim($_POST['s_lastname']));
$s_address=strip_tags(trim($_POST['s_address']));
$s_address1=strip_tags(trim($_POST['s_address1']));


$s_city=strip_tags(trim($_POST['s_city']));
$s_zipcode=strip_tags(trim($_POST['s_zipcode']));
$s_emailid=strip_tags(trim($_POST['s_emailid']));
$s_mobileno=strip_tags(trim($_POST['s_mobileno']));
$landmark=strip_tags(trim($_POST['landmark']));	



$v=1;


	try
	{ 
		//$db->beginTransaction();
		
		 $sql="select * from users where  user_email='".$user_email."'";
		$res = mysql_query($sql);
		$cnt = mysql_num_rows($res);
		if($cnt==1)
		{			
			
				$v=2;
		}
		else
		{
		$post_date=date('Y-m-d');
		   $ins="insert into users(	
	 										user_name,
											pwd,
											user_email,
											mobileno,
											status,
											post_date
										 )
											values
										(
											'".$username."',
											'".$pwd."',
											'".$user_email."',
											'".$mobileno."',
											'".$status."',
											'".$post_date."'
										)";
			$stmt=mysql_query($ins);
				
			$lid = mysql_insert_id();
				
				 $ins_bill_ship="insert into bill_ship_address(	
	 										user_id,
											b_firstname,
											b_lastname,
											b_address,
											b_address1,
											b_city,
											b_zipcode,
											b_emailid,
											b_mobileno,
											s_firstname,
											s_lastname,
											s_address,
											s_address1,
											s_city,
											s_zipcode,
											s_emailid,
											s_mobileno,
											landmark
										 )
											values
										(
											'".$lid."',
											'".$b_firstname."',
											'".$b_lastname."',
											'".$b_address."',
											'".$b_address1."',
											'".$b_city."',
											'".$b_zipcode."',
											'".$b_emailid."',
											'".$b_mobileno."',
											'".$s_firstname."',
											'".$s_lastname."',
											'".$s_address."',
											'".$s_address1."',
											'".$s_city."',
											'".$s_zipcode."',
											'".$s_emailid."',
											'".$s_mobileno."',
											'".$landmark."'
										)";
			$res = mysql_query($ins_bill_ship);
						
			$_SESSION['sessionuser_name']=$username;
			$_SESSION['sessionuser_id']=$lid;
			
			
			//   ***************************  EMAIL  START**************************
			
			$subject = 'Your account on My Calorie';

// message

   $message = '
 
 <div style="margin: 0 auto; width: 600px; background:#fff; box-shadow:0px 1px 1px 1px #428bca;">
	             <div style="background:#FFFFFF; padding: 20px; color:#fff"> <a href="'.SITE_URL.'"><img src="'.SITE_URL.'images/logo.png" alt="My Calorie" title="My Calorie" width="120" height="80"></a>
	              </div>
	       <div style="clear: left; padding: 20px;">
    
		<h3 style="color:#000; font-size: 14px; margin:3px 0;">
			
            <p>Dear '.$username.',</p>
		</h3>
		
        <p>Thank You for showing interest to register with us  </p>
	
 
	</div>
    
   <div style="clear: left; padding: 10px; border-top:1px solid #ccc; width:90%; margin-left:8px;">
    <table width="90%"  cellspacing="2" cellpadding="5" align="center" bgcolor="#f2f2f2">
      
      <tr>
        <td height="30" align="left"><strong>User Name</strong></td>
        <td> :  '.$user_email.'</td>
      </tr> 
	  <tr>
        <td height="30" align="left"><strong>Password</strong></td>
        <td> :  '.$pwd.'</td>
      </tr>      
    </table>
    </div>
	<div style="background:#428bca; text-align:left; padding: 8px 20px; color:#fff;"><p><strong>Warms Regards</strong>,<br />

                                                                                My Calorie<br />

                                                                                www.mycalories.com</p>

 </div>

</div> ';
$to = $user_email;


$files = array();

$head = array(
       'to'      =>array($to=>$username),
       'from'    =>array('pavankumarraju.n@gmail.com' =>'My Calorie'),
       /*'bcc'      =>array('reitake.com@gmail.com'=>'Admin'),*/
       
       );
// mail::send($head,$subject,$body, $files);


//   ***************************  EMAIL   END **************************
			// ----------------------------------------------------	
				$v=3;
			
		}
		
	}
	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=4;
		   }
	

echo $v;
?>