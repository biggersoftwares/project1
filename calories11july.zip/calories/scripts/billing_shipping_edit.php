<?php
include("../config/db_connection.php");
// Billing  Details
$b_firstname=strip_tags(trim($_POST['b_firstname']));
$b_lastname=strip_tags(trim($_POST['b_lastname']));
$b_address=strip_tags(trim($_POST['b_address']));
$b_address1=strip_tags(trim($_POST['b_address1']));


$b_city=strip_tags(trim($_POST['b_city']));
$b_state=strip_tags(trim($_POST['b_state']));
$b_zipcode=strip_tags(trim($_POST['b_zipcode']));
$b_emailid=strip_tags(trim($_POST['b_emailid']));
$b_mobileno=strip_tags(trim($_POST['b_mobileno']));
  

// Shipping Details

$s_firstname=strip_tags(trim($_POST['s_firstname']));
$s_lastname=strip_tags(trim($_POST['s_lastname']));
$s_address=strip_tags(trim($_POST['s_address']));
$s_address1=strip_tags(trim($_POST['s_address1']));


$s_city=strip_tags(trim($_POST['s_city']));
$s_state=strip_tags(trim($_POST['s_state']));
$s_zipcode=strip_tags(trim($_POST['s_zipcode']));
$s_emailid=strip_tags(trim($_POST['s_emailid']));
$s_mobileno=strip_tags(trim($_POST['s_mobileno']));
$landmark=strip_tags(trim($_POST['landmark']));	


$v=1;


	try
	{		
			   $upd="update bill_ship_address set 
											
											b_firstname='".$b_firstname."',
											b_lastname='".$b_lastname."',
											b_address='".$b_address."',
											b_address1='".$b_address1."',
											b_city='".$b_city."',
											b_zipcode='".$b_zipcode."',
											b_emailid='".$b_emailid."',
											b_mobileno='".$b_mobileno."',
											s_firstname='".$s_firstname."',
											s_lastname='".$s_lastname."',
											s_address='".$s_address."',
											s_address1='".$s_address1."',
											s_city='".$s_city."',
											s_zipcode='".$s_zipcode."',
											s_emailid='".$s_emailid."',
											s_mobileno='".$s_mobileno."',
											landmark='".$landmark."'
																							
												where user_id=".$_SESSION['sessionuser_id'];
	
												
		$res = mysql_query($upd);
				
		$v=3;
	}
	catch(PDOException $ex)
		   {
				$db->rollBack();
				writeLog($ex->getMessage().'\n'); 
				writeLog($ex->getLine().'\n'); 
				$v=4;
		   }
	

echo $v;
?>