<?php
/*http://www.calculator.net/bmr-calculator.html*/

/*
**********************************************************************************
 Lean Body Mass

LBM for Men = (0.32810 * W ) + ( 0.33929 * H ) - 29.5336

LBM for WoMen = (0.29569 * W ) + ( 0.41813 * H ) - 43.2933

********************************************************************************

Resting Daily Energy Expenditure

For Males

    RDEE = 66 + (13.7 x weight) + (5 x height) - (6.8 x age)

For Females

    RDEE = 655 + (9.6 x weight) + (1.85 x height) - (4.7 x age)
	
*****************************************************************************


	*/



$height=strip_tags(trim($_POST['height']));
$weight=strip_tags(trim($_POST['weight']));
$age=strip_tags(trim($_POST['age']));
$gender=strip_tags(trim($_POST['gender']));

$waist_fullest=strip_tags(trim($_POST['waist_fullest']));
$waist_naval=strip_tags(trim($_POST['waist_naval']));
$hip_fullest=strip_tags(trim($_POST['hip_fullest']));
$forearm_fullest=strip_tags(trim($_POST['forearm_fullest']));

$weight_lifted=strip_tags(trim($_POST['weight_lifted']));
$reps=strip_tags(trim($_POST['reps']));
$daily_workouttime=strip_tags(trim($_POST['daily_workouttime']));
$goal=strip_tags(trim($_POST['goal']));
$activity_level=strip_tags(trim($_POST['activity_level']));



$height_meters=$height/100;
$bmi=$weight/($height_meters*$height_meters);
if($gender==1)
{
 $bmr= 10 * $weight + 6.25 * $height - 5 * $age + 5 ;  
 
$factor1=($weight*1.082)+94.42;
$factor2=$waist_naval*4.15;

$leanbodymass=$factor1-$factor2;
$bodyfatweight=$weight-$leanbodymass;
$bodyfatpercentage=($bodyfatweight*100)/$weight;

// ******************  Lean Body Mass  *******************

$LBM=(0.32810 * $weight ) + ( 0.33929 * $height ) - 29.5336;

// ******************   Resting Daily Energy Expenditure  *******************

$rdee=66 + (13.7 * $weight) + (5 * $height) - (6.8 * $age);

 // ********************   PROTEIN INTAKE  && FAT INTAKE && CARBOHYDRATE INTAKE CALCULATORS  **********************
 
  $calories = (($weight * 10) + ($height * 6.25) - ($age * 5) + 5);

}
else
{
$bmr= 10 * $weight + 6.25 * $height - 5 * $age + 161 ;  


$factor1=($weight*0.732)+8.987;
$factor2=$waist_fullest/3.140;
$factor3=$waist_naval*0.157;
$factor4=$hip_fullest*0.249;
$factor5=$forearm_fullest*0.434;

$leanbodymass=$factor1+$factor2-$factor3-$factor4+$factor5;
$bodyfatweight=$weight-$leanbodymass;
$bodyfatpercentage=($bodyfatweight*100)/$weight;

// ******************  Lean Body Mass  *******************
$LBM=(0.29569 * $weight ) + ( 0.41813 * $height ) - 43.2933;

// ******************   Resting Daily Energy Expenditure  ******************* 
$rdee=655 + (9.6 * $weight) + (1.85 * $height) - (4.7 * $age);

 // ********************   PROTEIN INTAKE CALCULATOR  **********************
   $calories = (($weight * 10) + ($height * 6.25) - ($age * 5) - 161);
   
}


//  ******************   Max Heart Rate  *******************
$hearttate=220-$age;

  //  ****************** One-Rep Max (one-rm) *******************  
  $onerepmax= round($weight / $reps);


// *****************************  Water Intake   *************************

 $water_weight = ($weight * 2.20462);
 
 if($daily_workouttime=='L')
 {
	   $water = round($water_weight * 0.6 + 12); 
 }
 else if($daily_workouttime=='M')
 {
	   $water = round($water_weight * 0.6 + 24); 
 }
  else if($daily_workouttime=='V')
 {
	   $water = round($water_weight * 0.6 + 36); 
 }
 else
 {
	 $water=0;
 }
 
// ********************   PROTEIN INTAKE  && FAT INTAKE && CARBOHYDRATE INTAKE CALCULATORS  **********************

 if($activity_level=='L')
 {
	   $calories = round($calories * 1.1); 
 }
 else if($activity_level=='M')
 {
	    $calories = round($calories * 1.3); 
 }
  else if($activity_level=='V')
 {
	   $calories = round($calories * 1.5); 
 }
  else if($activity_level=='E')
 {
	   $calories = round($calories * 1.7); 
 }
 else
 {
	 $calories=0;
 }
 
 if($goal=='fat-loss')
 {
	   	   
	   if ( $calories <= 2000) 
	    $calories = 0.9 *  $calories;
		
        if ( $calories > 2000)
		 $calories = 0.8 *  $calories;
		 
         $proteins = round(0.40 *  $calories / 4);
		 
		 $fats = round(0.20 * $calories / 9);
		   $carbs = round(0.40 * $calories / 4);
 }
 else if($goal=='maintenance')
 {

		 
         $proteins =  round(0.30 * $calories / 4);
		  $fats = round(0.25 * $calories / 9);
		   $carbs = round(0.45 * $calories / 4);
 }
   else if($goal=='gainz')
 {

		 $calories += 500;
       $proteins = round(0.30 * $calories / 4);
	   $fats = round(0.25 * $calories / 9);
	   $carbs = round(0.45 * $calories / 4);
        
 }
 else
 {
	  $proteins=0;
	  $fats=0;
	  $carbs=0;
 }

 // ********************  CREATINE INTAKE CALCULATOR  **********************
 $creatine_weight = ($weight *  2.20462);
 
		if ($creatine_weight < 120) 
			$creatine = 3;
		else if ($creatine_weight > 119 && $creatine_weight < 201)
			$creatine = 5;
		else if ($creatine_weight> 200)
			$creatine = 8;
		else
			$creatine = 0;
			
	// *****************************  CARBOHYDRATE INTAKE CALCULATOR  *********************		

echo round($bmr)." Calories/day_".round($bmi)."_".round($LBM)."_".round($bodyfatweight)."_".round($bodyfatpercentage)."_".round($rdee)." Calories_".round($hearttate)." BPM_".round($onerepmax)." RM_".round($water)." OZ_".round($proteins)." G_".round($fats)." G_".round($creatine)." G_".round($carbs)." G";
?>
