<?php if(!empty($_REQUEST['is_ajax'])){ ?>
<!doctype html>
<html lang="en-US">
<head>
	<?php
	include_once ("config/db_connection.php");
	include_once ("includes/functions.php");
	include_once ("DBFns.php");
	?>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
			</head>
<body id="page-top" data-spy="scroll">

	<!-- cart display start -->
	<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
	<!-- cart display end -->

	<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->

	<div class="navbar-container">
		<div class="navbar navbar-default navbar-scroll-fixed"></div>
	</div>

	<!-- videos display start -here -->
	<?php //include("videos.php");?>
<!-- videos display end -here -->

	<!-- search bar start -here -->
	<?php //include("search_nutrition.php");?>
<!-- search bar end -here -->

	<!-- maincat start -->
	<?php include("maincat.php");?>
<!-- maincat end -->


<body data-spy="scroll">
	<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->
	<!-- ---------------------------------------      ------------------------------------------------- -->
	<?php }?>
		<!-- calc -->
<section class="facts_table" id="call1">	
	<div id="wrapper" class="wide-wrap">

		<div class="content-container backg">
			<div class="container">
				<div class="row">
					<h1 class="searched_">Calculators</h1>
					<br clear="all">
					<div class="col-sm-6">
						<form action="#" method="post" class="form my_account" role="form" >
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="height">Height(in Feets)</label>
										<input class="form-control" name="height" id="height" placeholder="In Cm's " type="text" required="" autofocus="" onKeyUp="checkNumber(this);" id="usr">
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="weight">Current Weight(in KGs):</label>
								<input class="form-control" name="weight" id="weight" placeholder="Kg's" type="text" required="" onKeyUp="checkNumber(this);">
									</div>
								</div>

								<div class="col-sm-4">
									<div class="form-group">
										<label for="age">Current Age(in Years)</label>	
								<input class="form-control" name="age" id="age" placeholder="Age" type="text" required="" onKeyUp="checkNumber(this);">
									</div>

								</div>
							</div>
							<div class="row">
								<div class="col-sm-6">
									<label class="inline form-flat-radio">
									
									 <input type="radio"
										checked="checked" value="1" id="gender" name="gender"> <i></i>Male
									</label>
								</div>
								<div class="col-sm-6">
									<label class="inline form-flat-radio"> 
									<input type="radio"
										value="2" id="gender" name="gender"> <i></i>FeMale
										
									</label>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<label for="waist_fullest">Wrist Measurement (at fullest point)</label>	
						<input class="form-control" name="waist_fullest" id="waist_fullest" placeholder="In Cm's " type="text" required="" onKeyUp="checkNumber(this);">
									</div>
								</div>

								<div class="col-sm-6">
									<div class="form-group">
										<label for="forearm_fullest">Waist Measurement (at naval) </label>
								<input class="form-control" name="forearm_fullest" id="forearm_fullest" placeholder="In Cm's " type="text" required="" onKeyUp="checkNumber(this);">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<label for="hip_fullest">Hip Measurement (at fullest point)</label>
					<input class="form-control" name="hip_fullest" id="hip_fullest" placeholder="In Cm's " type="text" required="" onKeyUp="checkNumber(this);">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label for="usr">Waist Measurement (at naval)</label>
											<input class="form-control" name="waist_naval" id="waist_naval" placeholder="In Cm's " type="text" required="" onKeyUp="checkNumber(this);">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="weight_lifted">Weight Lifted</label>
											<input class="form-control" id="weight_lifted" name="weight_lifted" placeholder="KGs" type="text" onKeyUp="checkNumber(this);">
									</div>
								</div>
								<div class="col-sm-8">
									<div class="form-group">
										<label for="activity_level">Activity Level</label> 
										<select
											name="activity_level" name="activity_level" id="activity_level"class="form-control">
											<option value="L">Lightly active (moderate exercise but
												sedentary job)</option>
											<option value="M">Moderately active (intense exercise but
												sedentary job)</option>
											<option value="V">Very active (moderate exercise and active
												job)</option>
											<option value="E">Extra active (intense exercise and active
												job)</option>
										</select>
									</div>

								</div>
							</div>

							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="goal">Goal</label> 
										<select name="goal" id="goal"
											class="form-control">
											<option>Fat Loss</option>
											<option>Maintenance</option>
											<option>Muscle GainZ</option>

										</select>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="daily_workouttime">Total Daily Workout Time</label> 
										<select
											id="daily_workouttime" name="daily_workouttime" 
											class="form-control">
											<option>One hour</option>
											<option>Less than an hour</option>
											<option>More than an hour</option>

										</select>
									</div>

								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="usr">Reps</label> 
										<select placeholder="Reps"
											id="reps" name="reps" class="form-control">
											<?php
						  for($k=1;$k<=12;$k++)
						  {
							  ?>
                          <option value="<?php echo $k;?>"><?php echo $k;?></option>
                          <?php
						  }
						  ?>
										</select>
									</div>
								</div>
							</div>
							<br>
							
							<button class="btn btn-lg btn-primary btn-block" type="button" id="calculate">Calculate</button>
							
						</form>
					</div>
			  
			 <div class="col-md-6">
              <h4 class="searched_">BMR Result : <span style="font-weight:bold;color:#2cabbf"><span id="bmrdiv">?</span> </span></h4>
              <h4 class="searched_">BMI Result : <span style="font-weight:bold;color:#2cabbf"><span id="bmidiv">?</span> </span></h4>
              <h4 class="searched_">Lean Body Mass : <span style="font-weight:bold;color:#2cabbf"><span id="leanbodymassdiv">?</span> </span></h4>
               <h4 class="searched_">Body Fat Weight : <span style="font-weight:bold;color:#2cabbf"><span id="bodyfatweightdiv">?</span> </span></h4>
                <h4 class="searched_">Body Fat Percentage : <span style="font-weight:bold;color:#2cabbf"><span id="bodyfatpercentagediv">?</span> </span></h4>
                
                
              
               <h4 class="searched_">Resting Daily Energy Expenditure : <span style="font-weight:bold;color:#2cabbf"><span id="rdeediv">?</span> </span></h4>
             
              <h4 class="searched_"> Max Heart Rate  : <span style="font-weight:bold;color:#2cabbf"><span id="heartratediv">?</span> </span></h4>
                  
             <h4 class="searched_">One-Rep Max (one-rm)  : <span style="font-weight:bold;color:#2cabbf"><span id="onerepmaxdiv">?</span> </span></h4>
             
              <h4 class="searched_">Daily Water Intake: <span style="font-weight:bold;color:#2cabbf"><span id="waterintakediv">?</span> </span></h4>
                
               <h4 class="searched_">Daily Protein Intake  : <span style="font-weight:bold;color:#2cabbf"><span id="proteinintakediv">?</span> </span></h4>
                
                  <h4 class="searched_">Daily Fat Intake  : <span style="font-weight:bold;color:#2cabbf"><span id="fatintakediv">?</span> </span></h4>
                  
             <h4 class="searched_">Daily Creatine Intake  : <span style="font-weight:bold;color:#2cabbf"><span id="creatineintakediv">?</span> </span></h4>
                
               <h4 class="searched_">Daily Carbohydrate Intake  : <span style="font-weight:bold;color:#2cabbf"><span id="carbohydratediv">?</span> </span></h4>
                
                
			   <!--<h6>This is the World Health Organization's (WHO) recommended body weight based on BMI values for adults. It is used for both men and women, age 18 or older.</h6>
			  <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        
        <th>Category</th>
        <th>BMI range - kg/m2</th>
      </tr>
    </thead>
    <tbody>

        <tr><td>Severe Thinness</td>
        <td>< 16</td>      </tr>
		
		<tr><td>Mild Thinness</td>
        <td>17 - 18.5</td>      </tr>
		
		<tr><td>Overweight</td>
        <td>25 - 30</td>      </tr>
		
		
		
		<tr><td>Obese Class I</td>
        <td>30 - 35</td>      </tr>
		
		<tr><td>Obese Class II</td>
        <td>35 - 40</td>      </tr>
		
		<tr><td>Obese Class III</td>
        <td>> 40</td>      </tr>
    </tbody>
  </table>
  </div>-->
</div>
					<div class="col-md-6"></div>








				</div>
			</div>


		</div>
<script type="text/javascript" src="js/userjs/general.js"></script>
<script type="text/javascript" src="js/userjs/calculator.js"></script>
	</div>
	</section>
<?php if(!empty($_REQUEST['is_ajax'])){ ?>
	<!-- ----------------------------------------     ------------------------------------------------ -->
	<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->

	<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->

	<!-- include all js files -->
		<?php include("includes/js.php");?>
</body>
</html>
<?php }?>