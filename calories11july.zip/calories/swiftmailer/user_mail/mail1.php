<?php
require_once '../../admin/config/mailconfig.php';
require_once '../swift_required.php';

// Create the SMTP configuration
$transport = Swift_SmtpTransport::newInstance(MAIL_HOST, MAIL_PORT);
$transport->setUsername(MAIL_UNAME);
$transport->setPassword(MAIL_PWORD);

// Create the message
$message = Swift_Message::newInstance();
$message->setTo(array(
   "panthangibabu@gmail.com" => "Aurelio De Rosa",
   "panthangibabu@gmail.com" => "Audero"
));
$message->setCc(array("panthangibabu@gmail.com" => "Aurelio De Rosa"));
$message->setBcc(array("panthangibabu@gmail.com" => "Bank Boss"));
$message->setSubject("This email is sent using Swift Mailer");
$message->setBody("You're our best client ever.");
$message->setFrom(MAIL_FROM,"FROM");
//$message->attach(Swift_Attachment::fromPath("path/to/file/file.zip"));

// Send the email
$mailer = Swift_Mailer::newInstance($transport);
$mailer->send($message, $failedRecipients);

// Show failed recipients
print_r($failedRecipients);