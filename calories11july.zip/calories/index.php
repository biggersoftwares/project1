<!doctype html>
<html lang="en-US">
	<head>
	<?php include("admin/config/constants.php");?>
		<?php include("includes/metatags.php"); ?>
		<?php include("includes/menubar.php"); ?>
		
	<?php	
		//include("admin/config/constants.php");
		include("config/db_connection.php");
		include("includes/functions.php");
		include("DBFns.php");
		?>
	</head>
	<body id="page-top" data-spy="scroll"    >

<!-- cart display start -->
<div id="display_cart">
	<?php include("cartdisplay.php");?>
</div>
<!-- cart display end -->			

<!-- Login start -->
	<?php include("login.php");?>
<!-- Login end -->			

<!-- videos display start -here -->
	<?php include("videos.php");?>
<!-- videos display end -here -->

<!-- search bar start -here -->
	<?php include("search_nutrition.php");?>
<!-- search bar end -here -->

<!-- maincat start -->
	<?php //include("maincat.php");?>
	<section id="menu">
	<div class="con tabs_section1">
	<div class="container ">
	
		<div id="menub" style="text-align:center;" class="row">
					<h4>MENU</h4>
          <div id="daily" class="col-md-4"><a href="index.php#daily">DAILY</a></div>
          <div class="col-md-4"> <a href="weekly.html">WEEKLY</a></div>
          <div class="col-md-4"> <a href="customize.html">CUSTOMIZE MENU</a></div>

		</div>
	</div>
	</div>

	
</section>
	
<!-- maincat end -->			

<!-- preloader start -->
	<?php include("preloader.php");?>
<!-- preloader end -->			

					
<!-- products details start -here displaying the products -->
<div id="products_display_div" name="products_display_div">
<?php include("products.php"); ?>
<!-- products details start -->
</div>
			
	<!-- calc start-->
	<?php include("calculator.php"); ?>
	<!-- calc end-->
	<br/>
	<br/>
	<br/>
	<br/>
	<br/>		
			
			
<!-- OUR STORY Start-->		
<?php include("ourstory.php"); ?>
<!-- OUR STORY END -->
		
		<!-- scroll up - start -->
		<?php include("scrollup.php");?>
		<!-- scroll up -end -->
		
		<!-- footer start -->
		<?php include("includes/footer1.php");?>
		<?php include("includes/footer.php");?>
		<!-- footer end -->
		
		<!-- include all js files -->
		<?php include("includes/js.php");?>
		
	</body>
</html>