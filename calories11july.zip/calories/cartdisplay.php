<?php
if(!empty($_REQUEST['is_ajax'])){
session_start();
include_once("admin/config/constants.php");
include_once("config/db_connection.php");
include_once("includes/functions.php");
include_once("DBFns.php");
}

$sid=session_id();
$db = new DBFns();
if($_SESSION['sessionuser_id']=="")
{
	$cartItems = $db->get_cart_items($sid);
}else{
	$user_id=$_SESSION['sessionuser_id'];
	$cartItems = $db->get_user_cart_items($user_id);
}
/* echo "<pre>";
print_r($cartItems);
echo "</pre>"; */
 ?>
<div class="modal fade cart-display" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="container">
  <div class="shopping-cart">
  <?php
		if(!empty($cartItems)){
	?>
    <div class="shopping-cart-header">
   <!-- <button aria-label="Close" data-dismiss="modal" class="close" type="button"><span aria-hidden="true">×</span></button><br/>-->
      <i class="fa fa-shopping-cart cart-icon"></i><span class="badge"><?php echo count($cartItems)?></span>
      <div class="shopping-cart-total">
        <span class="lighter-text">Total:</span>
        <span class="main-color-text shopping_total"></span>
      </div>
    </div> <!--end shopping-cart-header -->

	<ul class="shopping-cart-items" style="width: 300px; height: 200px; overflow-y: auto;">
	<?php
	$total=0;
	$shipping=0;
	$numitems=0;
	    foreach ($cartItems as $ckey=>$items){
		$product=$items['product'][0];
		$product_images=$product['product_images'];
		$product_price=$product['product_prices'][0];
	    $sale_price=$product_price['sale_price'];
	    $qty=$items['qty'];
	    $tot_price=($qty*$sale_price);
	    $total+=$tot_price;
	    $numitems+=$qty;
		?>
      <li class="clearfix">
        <img src="<?php echo SITE_URL;?>prod_images/<?php echo $product_images['prodimage_original'];?>" alt="<?php echo $product[product_name];?>" class="cart-image" style="height:100px;width:100px;"/>
        <span class="item-name"><?php echo $product['product_name'];?></span>
        <span class="item-price">&#8360;<?php echo $tot_price;?></span>
        <span class="item-quantity">Quantity:&nbsp;<?php echo $qty;?></span>
        <span class="item-quantity">Size:&nbsp;<?php echo $product_price['size_name'];?></span>
      </li>   <?php }
?>
 <a href="cart.php" class="button"><b>Checkout</b></a>
<?php
		}else{
	 ?>
    <div class="shopping-cart-header">
      <!-- <i class="fa fa-shopping-cart cart-icon"></i> -->
      <!--<span class="badge"><?php //echo count($cartItems)?></span>-->
     <div class="minicart-actions clearfix">
	<span class="text">Your shopping bag is empty</span>
	<a class="button wc-forward gotoshoping" style="cursor:pointer;">GO TO SHOPING</a>
	<script type="text/javascript" >
$( document ).ready(function() {
$(".gotoshoping").on("click",function(){
	
	 window.location.href='index.php#menu';  
});
});
</script>
	
	</div>
      </div>
	    	<?php 
	    	
	    }
	    ?>
	<span class="total_amt" style="display: none;"><?php echo $total+$shipping;?></span>
   <span class="shipg_amt" style="display: none;"><?php echo $shipping;?></span>
   <span class="numitems" style="display: none;"><?php echo $numitems;?></span>
	
	</ul>
	
	
  </div> <!--end shopping-cart -->
</div> <!--end container -->	
</div>
<?php ?>
